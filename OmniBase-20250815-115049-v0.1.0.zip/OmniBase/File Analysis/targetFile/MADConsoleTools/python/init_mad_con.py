import os
from pathlib import Path
from data_console.desk import journal, cad

def list_python_scripts(base_dir):
    base_path = Path(base_dir)
    script_paths = []

    for root, _, files in os.walk(base_path):
        for file in files:
            if file.endswith('.py'):
                full_path = Path(root) / file
                relative_path = full_path.relative_to(base_path.parent)
                script_paths.append(relative_path)

    return script_paths

def main():
    print("""============== PYTHON CONSOLE ==============
    Options:
        - Type number to run script
        - 'j' = open journal
        - 'q' = quit
        - 'h' = help
    ============================================
    """)
    while True:
        base_dir = "data_console"
        scripts = list_python_scripts(base_dir)

        if not scripts:
            print("No Python scripts found.")
            return

        

        for idx, script in enumerate(scripts):
            print(f"[{idx}] {script}")

        choice = input("\nEnter your choice: ").strip().lower()

        if choice == 'q':
            print("Exiting...")
            break
        elif choice == 'j':
            journal.open_journal()
            continue
        elif choice.startswith('cad'):
            path_arg = None
            if ' ' in choice:
                path_arg = choice.split(' ', 1)[1].strip().strip('"')
            cad.load_doc(path_arg)

        elif choice == 'xport':
            try:
                # Dynamically construct relative path import
                tool_path = Path(__file__).resolve().parent / "data_console" / "export" / "xport_parts_bodies.py"
                if not tool_path.exists():
                    print(f"xport_parts_bodies.py not found at: {tool_path}")
                else:
                    import runpy
                    runpy.run_path(str(tool_path), run_name="__main__")
            except Exception as e:
                print(f"Failed to run xport script: {e}")
            continue

        elif choice == 'h':
            print("""
        === Beginner Help ===
        - Type number to run script
        - 'cad' = load FreeCAD file
        - 'xport' = export parts and bodies from selected .FCStd
        - 'j' = open journal
        - 'q' = quit
        - 'h' = help
        """)
            continue    

        try:
            index = int(choice)
            if 0 <= index < len(scripts):
                selected_script = scripts[index]
                print(f"\nYou selected: {selected_script}")
                import runpy
                selected_path = Path(scripts[index])
                module_globals = runpy.run_path(str(selected_path.resolve()))
                if "main_entry" in module_globals:
                    if "main_entry" in module_globals:
                        try:
                            module_globals["main_entry"]()
                        except Exception as e:
                            print(f"Error while running main_entry(): {e}")
                    else:
                        print("No main_entry() found in the selected script.")


            else:
                print("Invalid selection.")
        except ValueError:
            print("Please enter a valid number or command.")

if __name__ == "__main__":
    main()
