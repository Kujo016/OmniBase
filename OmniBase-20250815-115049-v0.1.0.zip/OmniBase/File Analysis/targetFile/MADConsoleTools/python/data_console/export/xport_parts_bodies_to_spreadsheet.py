import os
from pathlib import Path
from collections import defaultdict

# FreeCAD compatibility
try:
    import FreeCAD as App
    import FreeCADGui as Gui
    from FreeCAD import Units
except ImportError:
    App = None
    Gui = None


def format_volume_area(obj):
    """Returns (volume_cm3, area_cm2) rounded to 2 decimals."""
    vol = obj.Shape.Volume
    area = obj.Shape.Area
    vol_cm3 = Units.Quantity(f"{vol} mm^3").getValueAs("cm^3")
    area_cm2 = Units.Quantity(f"{area} mm^2").getValueAs("cm^2")
    return round(vol_cm3, 2), round(area_cm2, 2)


def export_parts_bodies_to_spreadsheet(doc, spreadsheet_name="Parts_List_Spreadsheet"):
    if not doc:
        print("No document loaded.")
        return

    # Create spreadsheet if needed
    if spreadsheet_name not in doc.Spreadsheets:
        sheet = doc.addObject("Spreadsheet::Sheet", spreadsheet_name)
        sheet.Label = spreadsheet_name
        print(f"Created spreadsheet: {spreadsheet_name}")
    else:
        sheet = doc.getObject(spreadsheet_name)
        print(f"📄 Spreadsheet already exists: {spreadsheet_name}")

    # Clear contents
    sheet.clearAll()

    # Group bodies under parts
    part_bodies = defaultdict(list)
    for obj in doc.Objects:
        if obj.TypeId == "Part::Feature" or obj.TypeId.startswith("PartDesign::"):
            parent = obj.getParentGroup()
            part_name = parent.Name if parent else "Ungrouped"
            part_bodies[part_name].append(obj)

    # ✍️ Write data
    row = 1
    for part, bodies in part_bodies.items():
        sheet.set(f"A{row}", part)
        row += 1
        for body in bodies:
            try:
                vol, area = format_volume_area(body)
                mat = getattr(body, "Material", {"Name": "N/A"})
                mat_name = mat["Name"] if isinstance(mat, dict) else str(mat)

                sheet.set(f"A{row}", f"  -{body.Name}")
                sheet.set(f"B{row}", f"{vol} cm³")
                sheet.set(f"C{row}", f"{area} cm²")
                sheet.set(f"D{row}", mat_name)
                row += 1
            except Exception as e:
                print(f"Skipped {body.Name}: {e}")

    doc.recompute()
    print("Done writing to spreadsheet.")


def main_entry():
    try:
        if App is not None and App.ActiveDocument:
            export_parts_bodies_to_spreadsheet(App.ActiveDocument)
        else:
            print("No document open. Please open a .FCStd file before running this script.")
    except NameError:
        print("Function 'export_parts_bodies_to_spreadsheet' is not defined in this module.")
    except Exception as e:
        print(f"Unexpected error in xport_parts_bodies_to_spreadsheet.py: {e}")

if __name__ == "__main__":
    main_entry()
