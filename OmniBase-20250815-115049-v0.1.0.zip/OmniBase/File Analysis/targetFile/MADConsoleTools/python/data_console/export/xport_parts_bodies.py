import os
from pathlib import Path
import sys

try:
    import FreeCAD as App
    import FreeCADGui as Gui
except ImportError:
    App = None
    Gui = None


def export_parts_and_bodies(doc, target_dir=None):
    if not doc:
        print("No document loaded.")
        return

    project_name = Path(doc.FileName).stem if hasattr(doc, "FileName") else "Untitled"
    output_dir = target_dir or Path(doc.FileName).parent if hasattr(doc, "FileName") else Path.cwd()
    output_file = output_dir / f"{project_name}_exported_parts_bodies_list.txt"

    try:
        parts = [obj for obj in doc.Objects if obj.TypeId == 'App::Part']

        with open(output_file, "w", encoding="utf-8") as f:
            for part in parts:
                f.write(f"={part.Label}\n")
                for child in part.Group:
                    if child.TypeId == 'PartDesign::Body':
                        f.write(f"-{child.Label}\n")

        print(f"Parts and bodies list written to: {output_file}")
    except Exception as e:
        print(f"Failed to write parts and bodies list: {e}")


def main_entry():
    try:
        if App is not None and App.ActiveDocument:
            export_parts_and_bodies(App.ActiveDocument)
        else:
            print("No document open. Please open a .FCStd file before running this script.")
    except NameError:
        print("Function 'export_parts_and_bodies' is not defined in this module.")
    except Exception as e:
        print(f"Unexpected error in xport_parts_bodies.py: {e}")

if __name__ == "__main__":
    main_entry()


