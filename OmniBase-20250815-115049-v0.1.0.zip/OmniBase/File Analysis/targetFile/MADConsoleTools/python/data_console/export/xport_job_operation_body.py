import os
from pathlib import Path

# Optional fallback if not run inside FreeCAD
try:
    import FreeCAD as App
    import FreeCADGui as Gui
except ImportError:
    App = None
    Gui = None


def export_cam_jobs(doc, target_dir=None):
    if not doc:
        print("No document loaded.")
        return

    project_name = Path(doc.FileName).stem if hasattr(doc, "FileName") else "Untitled"
    output_dir = target_dir or Path(doc.FileName).parent if hasattr(doc, "FileName") else Path.cwd()
    output_file = output_dir / f"{project_name}_exported_cam_jobs.txt"

    try:
        cam_jobs = [obj for obj in doc.Objects if obj.TypeId == 'Path::FeatureGroup']

        with open(output_file, "w", encoding="utf-8") as f:
            for job in cam_jobs:
                f.write(f"={job.Label}\n")
                for op in job.Group:
                    if op.TypeId.startswith("Path::") and hasattr(op, 'Base'):
                        f.write(f"-{op.Label}\n")

                        base = op.Base
                        if isinstance(base, list):
                            for ref in base:
                                if hasattr(ref, 'Label'):
                                    f.write(f"--{ref.Label}\n")
                        elif hasattr(base, 'Label'):
                            f.write(f"--{base.Label}\n")

        print(f"CAM job list written to: {output_file}")
    except Exception as e:
        print(f"Failed to write CAM job list: {e}")


def main_entry():
    try:
        if App is not None and App.ActiveDocument:
            export_cam_jobs(App.ActiveDocument)
        else:
            print("No document open. Please open a .FCStd file before running this script.")
    except NameError:
        print("Function 'export_cam_jobs' is not defined in this module.")
    except Exception as e:
        print(f"Unexpected error in xport_job_operation_body.py: {e}")

if __name__ == "__main__":
    main_entry()

