import FreeCAD as App, FreeCADGui as Gui

def get_shape(obj):
    shp = getattr(obj, "Shape", None)
    if shp and not shp.isNull():
        return shp
    # unwrap App::Link / Clone
    try:
        linked = obj.getLinkedObject(True)
        shp2 = getattr(linked, "Shape", None)
        if shp2 and not shp2.isNull():
            return shp2
    except Exception:
        pass
    return None

def faces_tuple(obj):
    shp = get_shape(obj)
    if not shp:
        return tuple()
    return tuple(f"Face{i+1}" for i in range(len(shp.Faces)))

def get_targets_from_selection():
    t = []
    for s in Gui.Selection.getSelection():
        # skip path ops
        try:
            if s.isDerivedFrom("Path::Feature"):
                continue
        except Exception:
            pass
        dobj = App.ActiveDocument.getObject(s.Name)
        if get_shape(dobj):
            t.append(dobj)
    return t

def get_active_path_op():
    # 1) op currently in edit
    try:
        obj, sub = Gui.ActiveDocument.getInEdit()
        if obj and obj.isDerivedFrom("Path::Feature"):
            return obj
    except Exception:
        pass
    # 2) task panel might expose an op handle
    try:
        panel = Gui.Control.activeDialog()
        for attr in ("obj","op","feature","operation"):
            op = getattr(panel, attr, None)
            if op and op.isDerivedFrom("Path::Feature"):
                return op
    except Exception:
        pass
    # 3) last resort: single path op in doc
    ops = [o for o in App.ActiveDocument.Objects
           if hasattr(o,"isDerivedFrom") and o.isDerivedFrom("Path::Feature")]
    if len(ops) == 1:
        return ops[0]
    return None

def try_assign(op, targets):
    bases = []
    for t in targets:
        faces = faces_tuple(t)
        if faces:
            bases.append((App.ActiveDocument.getObject(t.Name), faces))
    if not bases:
        return False, "no faces"

    # Try common APIs
    for prop in ("BaseGeometry","Base","Selection"):
        if hasattr(op, prop):
            try:
                setattr(op, prop, bases)
                return True, f"set {prop}"
            except Exception:
                pass
    if hasattr(op, "addBase"):
        try:
            for obj, faces in bases:
                op.addBase(obj, list(faces))
            return True, "addBase"
        except Exception:
            pass
    return False, "op api not recognized"

def select_all_faces_for_add(target):
    # Populate GUI selection so one click on "Add" fills the table
    shp = get_shape(target)
    if not shp:
        App.Console.PrintError("No shape on selected object.\n"); return
    Gui.Selection.clearSelection()
    for i in range(len(shp.Faces)):
        Gui.Selection.addSelection(App.ActiveDocument.Name, target.Name, f"Face{i+1}")
    App.Console.PrintMessage(f"✅ Selected {len(shp.Faces)} faces on {target.Label}. Now click 'Add'.\n")

def main():
    targets = get_targets_from_selection()
    if not targets:
        App.Console.PrintError("Select your gear/body/clone, then run.\n")
        return

    op = get_active_path_op()
    if op:
        ok, msg = try_assign(op, targets)
        if ok:
            App.ActiveDocument.recompute()
            App.Console.PrintMessage(f"✅ Geometry assigned to '{op.Label}' ({msg}).\n")
            return
        # fall through to selection method if assignment failed

    # If we couldn’t find an op or assignment failed, drive the task panel via selection
    select_all_faces_for_add(targets[0])

if __name__ == "__main__":
    main()
