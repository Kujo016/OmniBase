# cuda_py_commands.py
# One-stop console helpers for exporting two selected gears and running CUDA collision checks.
# Works with:
#   - MADConsoleTools/scripts/export_selected_gears_to_cuda_bin.py
#   - MADConsoleTools/scripts/gearcuda.py  (ctypes wrapper around bin/gearcuda.dll)

from __future__ import annotations
import struct, os, math, time

# FreeCAD-safe imports
try:
    import FreeCAD as App
    import FreeCADGui as Gui  # only used for selection; script still works headless for messaging
except Exception:
    class _Stub:
        class Console:
            @staticmethod
            def PrintMessage(m): print(m, end="")
            @staticmethod
            def PrintError(m): print(m, end="")
    App = _Stub()
    Gui = None

# Your existing tools
try:
    from MADConsoleTools.scripts.export_selected_gears_to_cuda_bin import export_selection_bin
    from MADConsoleTools.scripts import gearcuda as _gc
    check_mesh = getattr(_gc, "check_mesh", None)
    check_mesh_ratio = getattr(_gc, "check_mesh_ratio", None)

    if check_mesh is None:
        raise ImportError("MADConsoleTools.scripts.gearcuda is missing check_mesh(). Update gearcuda.py.")

    def _need_ratio():
        # Nice error when ratio path is missing
        raise RuntimeError(
            "[cuda] Your MADConsoleTools\\scripts\\gearcuda.py lacks check_mesh_ratio(...).\n"
            "Update it to the newer wrapper or run cuda_check_fast() for a smoke test."
        )
except Exception as e:
    App.Console.PrintError(f"[cuda] Import error: {e}\n")
    raise

# ---------- helpers ----------
def _doc_dir() -> str:
    doc = getattr(App, "ActiveDocument", None)
    if not doc or not getattr(doc, "FileName", ""):
        raise RuntimeError("Open and save your document first; no .FCStd file path available.")
    return os.path.dirname(doc.FileName)

def _out_bin_path() -> str:
    return os.path.join(_doc_dir(), "gears_cuda.bin")

def _sel_two_objects():
    if not Gui:
        raise RuntimeError("FreeCADGui is not available; selection cannot be read.")
    sel = Gui.Selection.getSelection()
    if len(sel) != 2:
        raise RuntimeError("Select exactly TWO gear bodies (Ctrl+click both) and try again.")
    return sel

def _ask_float(prompt: str, default: float) -> float:
    try:
        s = input(f"{prompt} [{default}]: ").strip()
        return float(s) if s else float(default)
    except Exception:
        App.Console.PrintMessage(f"Using default {default}\n")
        return float(default)

def _ask_int(prompt: str, default: int) -> int:
    try:
        s = input(f"{prompt} [{default}]: ").strip()
        return int(s) if s else int(default)
    except Exception:
        App.Console.PrintMessage(f"Using default {default}\n")
        return int(default)

def _ask_yesno(prompt: str, default_yes=True) -> bool:
    d = "Y/n" if default_yes else "y/N"
    s = input(f"{prompt} ({d}): ").strip().lower()
    if not s:
        return default_yes
    return s.startswith("y")

def _print_summary(hits, deg_step):
    total = len(hits)
    coll = int(sum(1 for h in hits if h))
    pct = 100.0 * coll / total if total else 0.0
    App.Console.PrintMessage(f"[cuda] Collisions: {coll}/{total} steps  ({pct:.1f}%)  step={deg_step}°\n")
    if coll:
        first = [i*deg_step for i,h in enumerate(hits) if h][:20]
        App.Console.PrintMessage(f"[cuda] First collisions @deg: {first}\n")

def _recommend_step(diag, limit=50_000_000):
    pairs = max(1, diag["pairs"])
    max_steps = max(1, limit // pairs)
    step = max(1.0, math.ceil(360.0 / max_steps))
    return float(step)


# ---------- core ops ----------
def cuda_export(deflection: float = 0.03) -> str:
    sel = _sel_two_objects()  # verifies selection
    try:
        labels = [getattr(s, "Label", getattr(s, "Name", str(s))) for s in sel]
        App.Console.PrintMessage(f"[cuda] Selected: #1={labels[0]}  #2={labels[1]}\n")
    except Exception:
        pass
    out_path = _out_bin_path()
    export_selection_bin(out_path, deflection=float(deflection))
    App.Console.PrintMessage(f"[cuda] Wrote: {out_path}\n")
    return out_path

def cuda_run_safe(out_path, run_fn, *, deg_step, teeth=None, phase=0.0,
                  deflection_used=None, log_dir=None):
    # Preflight
    d = cuda_bin_preflight(out_path, deg_step)
    if d["too_heavy"]:
        App.Console.PrintError("[cuda] Preflight: workload too heavy. Aborting.\n")
        return []

    # Try once at requested settings
    try:
        t0 = time.time()
        hits = (run_fn(out_path, deg_step) if teeth is None
                else run_fn(out_path, deg_step, teeth[0], teeth[1], phase))
        dt = time.time() - t0
        _cuda_log_repro(log_dir or os.path.dirname(out_path), out_path, deg_step, teeth, phase, deflection_used, d, dt, ok=True)
        return hits
    except Exception as e:
        App.Console.PrintError(f"[cuda] {e}\n")
        # Auto-degrade once: larger step
        safer_step = max(1.0, float(deg_step) * 2.0)
        App.Console.PrintMessage(f"[cuda] Retrying with degrees_step={safer_step}\n")
        try:
            hits = (run_fn(out_path, safer_step) if teeth is None
                    else run_fn(out_path, safer_step, teeth[0], teeth[1], phase))
            _cuda_log_repro(log_dir or os.path.dirname(out_path), out_path, safer_step, teeth, phase, deflection_used, d, -1, ok=True, downgraded=True)
            return hits
        except Exception as e2:
            App.Console.PrintError(f"[cuda] Retry failed: {e2}\n")
            _cuda_log_repro(log_dir or os.path.dirname(out_path), out_path, safer_step, teeth, phase, deflection_used, d, -1, ok=False)
            return []

def _cuda_log_repro(dirpath, out_path, deg_step, teeth, phase, defl, diag, dt, ok, downgraded=False):
    try:
        os.makedirs(dirpath, exist_ok=True)
        p = os.path.join(dirpath, "gearcuda_last_run.txt")
        with open(p, "w", encoding="utf-8") as f:
            f.write(f"bin={out_path}\nstep={deg_step}\nteeth={teeth}\nphase={phase}\n")
            f.write(f"deflection={defl}\ntri0={diag['triangles_0']}\ntri1={diag['triangles_1']}\n")
            f.write(f"steps={diag['steps']}\npairs={diag['pairs']}\n")
            f.write(f"ok={ok}\ndowngraded={downgraded}\nelapsed={dt:.3f}\n")
    except Exception:
        pass


def cuda_check_fast(degrees_step: float = 1.0, deflection: float = 0.03):
    out_path = cuda_export(deflection=deflection)
    diag = cuda_bin_preflight(out_path, degrees_step)
    if diag["too_heavy"]:
        rec = _recommend_step(diag)
        App.Console.PrintError(f"[cuda] Workload too heavy at {degrees_step}°. Try ≥ {rec}° or re-export coarser.\n")
        return []
    hits = cuda_run_safe(out_path, check_mesh, deg_step=float(degrees_step), deflection_used=deflection)
    _print_summary(hits, float(degrees_step if hits else degrees_step))
    return hits


def cuda_check_ratio(teeth0: int, teeth1: int, degrees_step: float = 0.5, phase1_deg: float = 0.0, deflection: float = 0.03):
    if check_mesh_ratio is None:
        return _need_ratio()
    out_path = cuda_export(deflection=deflection)
    diag = cuda_bin_preflight(out_path, degrees_step)
    if diag["too_heavy"]:
        rec = _recommend_step(diag)
        App.Console.PrintError(f"[cuda] Workload too heavy at {degrees_step}°. Try ≥ {rec}° or re-export coarser.\n")
        return []
    hits = cuda_run_safe(out_path, check_mesh_ratio, deg_step=float(degrees_step),
                         teeth=(int(teeth0), int(teeth1)), phase=float(phase1_deg),
                         deflection_used=deflection)
    _print_summary(hits, float(degrees_step if hits else degrees_step))
    return hits


def cuda_phase_sweep(teeth0: int, teeth1: int, sweep_step_deg: int = 5, degrees_step: float = 1.0, deflection: float = 0.03, topk: int = 5):
    if check_mesh_ratio is None:
        return _need_ratio()
    out_path = cuda_export(deflection=deflection)
    diag = cuda_bin_preflight(out_path, degrees_step)
    if diag["too_heavy"]:
        rec = _recommend_step(diag)
        App.Console.PrintError(f"[cuda] Sweep too heavy at {degrees_step}°. Try ≥ {rec}° or re-export coarser.\n")
        return []
    sweep_step_deg = max(1, int(sweep_step_deg))
    results = []
    for phase in range(0, 360, sweep_step_deg):
        hits = cuda_run_safe(out_path, check_mesh_ratio, deg_step=float(degrees_step),
                             teeth=(int(teeth0), int(teeth1)), phase=float(phase),
                             deflection_used=deflection)
        if not hits:
            App.Console.PrintError(f"[cuda] Phase {phase}° failed; aborting sweep.\n")
            break
        c = int(sum(1 for h in hits if h))
        results.append((c, phase))
    results.sort(key=lambda x: x[0])
    top = results[:max(1, int(topk))] if results else []
    if top:
        App.Console.PrintMessage("[cuda] Phase sweep (collisions, phase°): " + ", ".join(f"({c},{p})" for c,p in top) + "\n")
        App.Console.PrintMessage(f"[cuda] Best phase candidate: {top[0][1]}° (collisions={top[0][0]})\n")
    return top


# ---------- interactive “wizard” ----------


def cuda_bin_preflight(path, deg_step, max_pairs=50_000_000, max_steps=20000):
    """Return dict with counts and safety verdict; raise if file malformed."""
    with open(path, "rb") as f:
        blob = f.read()
    if len(blob) < 16:
        raise RuntimeError("bin too small")
    magic = blob[:8]
    version, num_gears = struct.unpack_from("<II", blob, 8)
    if num_gears != 2:
        raise RuntimeError(f"expected 2 gears, found {num_gears}")

    off = 16
    tri_counts = []
    for g in range(2):
        if len(blob) < off + 96: raise RuntimeError("header truncated")
        nv, nt = struct.unpack_from("<II", blob, off); off += 8
        off += 4*3 + 4*3 + 4*16
        need = nv * 12
        if len(blob) < off + need: raise RuntimeError("vertex block truncated")
        off += need
        need = nt * 12
        if len(blob) < off + need: raise RuntimeError("triangle block truncated")
        # Spot check first tri is within range (catches 1-based index bugs)
        a,b,c = struct.unpack_from("<III", blob, off)
        if max(a,b,c) >= nv:
            raise RuntimeError("triangle index out of range; exporter may be 1-based")
        off += need
        tri_counts.append((nv, nt))

    steps = int(math.ceil(360.0 / max(1e-6, float(deg_step))))
    pairs = tri_counts[0][1] * tri_counts[1][1]
    too_heavy = (pairs * steps) > max_pairs or steps > max_steps
    return {
        "triangles_0": tri_counts[0][1],
        "triangles_1": tri_counts[1][1],
        "steps": steps,
        "pairs": pairs,
        "too_heavy": too_heavy
    }


def cuda_wizard():
    """
    Step-through: verify selection, export, (optional) phase sweep, then ratio check.
    Prompts show defaults; press Enter to accept.
    """
    try:
        _sel_two_objects()
    except Exception as e:
        App.Console.PrintError(f"[cuda] {e}\n")
        return

    # Export
    defl = _ask_float("Mesh deflection (smaller = finer, slower)", 0.03)
    out_path = cuda_export(deflection=defl)

    # Ratio inputs
    App.Console.PrintMessage("[cuda] Enter tooth counts for the *first* and *second* selected gears.\n")
    T0 = _ask_int("Teeth (gear #1)", 60)
    T1 = _ask_int("Teeth (gear #2)", 20)

    # Optional phase sweep
    phase_best = 0.0
    if _ask_yesno("Run quick phase sweep to find a low-collision starting phase?", True):
        sweep_step = _ask_int("Phase sweep step (degrees)", 5)
        step_for_sweep = _ask_float("Degrees per simulation step during sweep", 1.0)
        top = cuda_phase_sweep(T0, T1, sweep_step_deg=sweep_step, degrees_step=step_for_sweep, deflection=defl, topk=5)
        if top:
            phase_best = float(top[0][1])
    
    ratio_ok = (check_mesh_ratio is not None)
    if not ratio_ok:
        App.Console.PrintError("[cuda] Ratio path unavailable; running FAST smoke test only.\n")
        return cuda_check_fast(
            degrees_step=_ask_float("Degrees per simulation step (fast)", 1.0),
            deflection=defl
        )
    
    # Final ratio check
    deg_step = _ask_float("Degrees per simulation step (final check)", 0.5)
    phase1 = _ask_float("Starting phase for gear #2 (degrees)", phase_best)
    hits = check_mesh_ratio(out_path,
                            degrees_step=float(deg_step),
                            teeth0=int(T0),
                            teeth1=int(T1),
                            phase1_deg=float(phase1))
    _print_summary(hits, float(deg_step))

    App.Console.PrintMessage("[cuda] Done. If collisions persist across *all* phases, your center distance or tooth form is off.\n")

# ---------- help ----------
def cuda_help():
    msg = """
[cuda] Commands:
  - cuda_wizard()                → Guided flow: export → (optional) phase sweep → ratio check
  - cuda_export(deflection=0.03) → Export two selected gear bodies to gears_cuda.bin
  - cuda_check_fast(degrees_step=1.0, deflection=0.03)
                                → Quick equal counter-rotation smoke test
  - cuda_check_ratio(teeth0, teeth1, degrees_step=0.5, phase1_deg=0.0, deflection=0.03)
                                → Realistic ratio/phase simulation
  - cuda_phase_sweep(teeth0, teeth1, sweep_step_deg=5, degrees_step=1.0, deflection=0.03, topk=5)
                                → Find low-collision starting phases

Workflow:
  1) In the Tree, Ctrl+click exactly two gear bodies that are already positioned.
  2) Run: cuda_wizard()
  3) Tweak deflection / step / phase based on summary.

Notes:
  • If FreeCAD can’t find cudart64_*.dll when loading bin/gearcuda.dll, add this to PATH and restart FreeCAD:
      C:\\Program Files\\NVIDIA GPU Computing Toolkit\\CUDA\\v12.8\\bin
  • gears_cuda.bin is written next to your .FCStd file.
"""
    App.Console.PrintMessage(msg + "\n")
