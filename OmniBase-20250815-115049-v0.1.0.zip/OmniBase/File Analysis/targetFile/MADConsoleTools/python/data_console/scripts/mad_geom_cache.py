# mad_geom_cache.py  (no task-panel guard)
import json, time
import FreeCAD as App, FreeCADGui as Gui

PARAM_ROOT = "User parameter:BaseApp/Preferences/MADCON"
PARAM_KEY  = "GeomCache"

def _pg():
    return App.ParamGet(PARAM_ROOT)

def _doc_key(doc=None):
    d = doc or App.ActiveDocument
    return (d.FileName or d.Name or "Untitled")

def _get_shape(obj):
    shp = getattr(obj, "Shape", None)
    if shp and not shp.isNull():
        return shp
    # unwrap Link/Clone
    try:
        linked = obj.getLinkedObject(True)
        shp2 = getattr(linked, "Shape", None)
        if shp2 and not shp2.isNull():
            return shp2
    except Exception:
        pass
    return None

def _faces_tuple(obj):
    shp = _get_shape(obj)
    if not shp:
        return ()
    return tuple(f"Face{i+1}" for i in range(len(shp.Faces)))

def store_from_selection():
    """Cache (object name, Face#...) for all selected solids/clones (skips Path ops)."""
    doc = App.ActiveDocument
    if not doc:
        App.Console.PrintError("No active document.\n"); return
    targets = []
    for s in Gui.Selection.getSelection():
        try:
            if s.isDerivedFrom("Path::Feature"):
                continue
        except Exception:
            pass
        if s.Document != doc:
            continue
        faces = _faces_tuple(s)
        if faces:
            targets.append((s.Name, faces))
    if not targets:
        App.Console.PrintError("Select at least one solid/clone with faces, then run.\n"); return

    payload = {
        "doc": _doc_key(doc),
        "ts": int(time.time()),
        "items": [{"name": n, "faces": list(fs)} for n, fs in targets],
    }
    _pg().SetString(PARAM_KEY, json.dumps(payload))
    App.Console.PrintMessage(f"✅ Cached geometry for {len(targets)} object(s).\n")

def _load_cache():
    raw = _pg().GetString(PARAM_KEY, "")
    if not raw:
        App.Console.PrintError("No cached geometry. Run store_from_selection() first.\n")
        return None
    try:
        return json.loads(raw)
    except Exception:
        App.Console.PrintError("Cached data corrupt.\n")
        return None

def recall_to_selection(strict_doc=True, clear_first=True):
    """
    Select all cached faces in the GUI. Then you can click 'Add' in any Path task panel.
    No guard: works regardless of which workbench/panel is open.
    """
    data = _load_cache()
    if not data:
        return
    if strict_doc and data.get("doc") != _doc_key():
        App.Console.PrintError("Cached geometry is from a different document. Set strict_doc=False to override.\n")
        return

    doc = App.ActiveDocument
    if clear_first:
        Gui.Selection.clearSelection()
    added = 0
    for item in data.get("items", []):
        obj = doc.getObject(item["name"])
        if not obj:
            App.Console.PrintMessage(f"⚠️ Missing object: {item['name']}\n"); continue
        for f in item["faces"]:
            Gui.Selection.addSelection(doc.Name, obj.Name, f)
            added += 1
    App.Console.PrintMessage(f"✅ Primed selection with {added} faces. Click 'Add' in the task panel when ready.\n")

def _get_active_path_op():
    # Try op in edit
    try:
        obj, sub = Gui.ActiveDocument.getInEdit()
        if obj and obj.isDerivedFrom("Path::Feature"):
            return obj
    except Exception:
        pass
    # Try active dialog fields
    try:
        panel = Gui.Control.activeDialog()
        for attr in ("obj","op","feature","operation"):
            op = getattr(panel, attr, None)
            if op and op.isDerivedFrom("Path::Feature"):
                return op
    except Exception:
        pass
    # Fallback: single Path op
    ops = [o for o in App.ActiveDocument.Objects
           if hasattr(o, "isDerivedFrom") and o.isDerivedFrom("Path::Feature")]
    if len(ops) == 1:
        return ops[0]
    return None

def recall_assign(strict_doc=True):
    """
    Try to assign cached faces directly to whatever Path op we can detect.
    Falls back to selection if assignment API fails.
    """
    data = _load_cache()
    if not data:
        return
    if strict_doc and data.get("doc") != _doc_key():
        App.Console.PrintError("Cached geometry is from a different document. Set strict_doc=False to override.\n")
        return

    doc = App.ActiveDocument
    op = _get_active_path_op()
    if not op:
        App.Console.PrintMessage("ℹ️ No Path op detected; selecting faces instead.\n")
        return recall_to_selection(strict_doc=strict_doc)

    bases = []
    for item in data.get("items", []):
        obj = doc.getObject(item["name"])
        if not obj:
            App.Console.PrintMessage(f"⚠️ Missing object: {item['name']}\n"); continue
        faces = tuple(item.get("faces", []))
        if faces:
            bases.append((obj, faces))
    if not bases:
        App.Console.PrintError("No faces in cache to assign.\n"); return

    # Try common APIs
    for prop in ("BaseGeometry","Base","Selection"):
        if hasattr(op, prop):
            try:
                setattr(op, prop, bases)
                App.ActiveDocument.recompute()
                App.Console.PrintMessage(f"✅ Assigned {sum(len(b[1]) for b in bases)} faces to '{op.Label}' via {prop}.\n")
                return
            except Exception:
                pass
    if hasattr(op, "addBase"):
        try:
            for obj, faces in bases:
                op.addBase(obj, list(faces))
            App.ActiveDocument.recompute()
            App.Console.PrintMessage(f"✅ Assigned {sum(len(b[1]) for b in bases)} faces to '{op.Label}' via addBase.\n")
            return
        except Exception:
            pass

    App.Console.PrintMessage("ℹ️ Op API not recognized; selecting faces instead. Click 'Add'.\n")
    recall_to_selection(strict_doc=strict_doc)

def clear_cache():
    _pg().RemString(PARAM_KEY)
    App.Console.PrintMessage("🧹 Cleared MADCON geom cache.\n")

# Short aliases
store  = store_from_selection
recall = recall_to_selection
assign = recall_assign
clear  = clear_cache
