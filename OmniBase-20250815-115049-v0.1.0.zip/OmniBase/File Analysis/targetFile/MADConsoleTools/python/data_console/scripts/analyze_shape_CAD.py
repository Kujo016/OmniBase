from pathlib import Path
import os

def scan_and_write_report(folder):
    categories = {
        'FreeCAD': [],
        'KiCAD': [],
        'bCNC': [],
        'STL/STEP/DXF': [],
        'Images': [],
        'Code': [],
        'AI/ML': [],
        'Books/Writing': [],
        'Text': [],
        'Other': []
    }

    for root, _, files in os.walk(folder):
        for file in files:
            path = Path(root) / file
            ext = path.suffix.lower()

            if ext in ['.fcstd']:
                categories['FreeCAD'].append(path)
            elif ext in ['.kicad_pcb', '.kicad_sch', '.kicad_pro', '.kicad_sym', '.kicad_mod', '.net', '.lib', '.dcm', '.cmp']:
                categories['KiCAD'].append(path)
            elif ext in ['.gcode', '.nc', '.ngc', '.bcnc']:
                categories['bCNC'].append(path)
            elif ext in ['.stl', '.step', '.stp', '.dxf']:
                categories['STL/STEP/DXF'].append(path)
            elif ext in ['.png', '.jpg', '.jpeg', '.bmp', '.webp']:
                categories['Images'].append(path)
            elif ext in ['.py', '.cpp', '.c', '.h', '.hpp', '.ino', '.bat', '.sh']:
                categories['Code'].append(path)
            elif ext in ['.pt', '.onnx', '.tflite', '.weights', '.pb', '.ckpt', '.yaml', '.cfg']:
                categories['AI/ML'].append(path)
            elif ext in ['.docx', '.odt', '.epub', '.rtf']:
                categories['Books/Writing'].append(path)
            elif ext in ['.txt', '.md', '.pdf', '.log']:
                categories['Text'].append(path)
            else:
                categories['Other'].append(path)

    # Safer: Write report in current working directory
    safe_name = Path(folder).name.replace(" ", "_")
    output_file = f"{safe_name}_shape.txt"
    output_path = Path.cwd() / output_file

    try:
        with open(output_path, 'w', encoding='utf-8') as f:
            for cat, files in categories.items():
                f.write(f"\n{cat} Files ({len(files)}):\n")
                for file_path in files:
                    f.write(f"  - {file_path}\n")
        print(f"\n✅ File report written to: {output_path}")
    except Exception as e:
        print(f"❌ Failed to write file report: {e}")


try:
    folder = __args__[0]
    scan_and_write_report(folder)
except (NameError, IndexError):
    print("❌ This script must be called from the MiniConsole with one folder path argument in __args__.")

