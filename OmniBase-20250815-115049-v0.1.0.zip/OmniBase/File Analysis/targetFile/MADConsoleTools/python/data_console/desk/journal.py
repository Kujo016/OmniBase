from datetime import datetime
import json
from pathlib import Path

log_path = Path(__file__).parent / "log.json"
export_path = Path.cwd() / "journal_export.txt"

def ensure_log_exists():
    if not log_path.exists():
        with open(log_path, 'w') as f:
            json.dump([], f)

def load_log():
    try:
        with open(log_path, 'r', encoding='utf-8') as f:
            content = f.read().strip()
            return json.loads(content) if content else []
    except json.JSONDecodeError:
        print("⚠️ Corrupt log. Resetting.")
        return []

def save_log(entries):
    with open(log_path, 'w', encoding='utf-8') as f:
        json.dump(entries, f, indent=2)

def convert_json_to_text():
    entries = load_log()
    if not entries:
        print("📭 No entries to export.")
        return

    with open(export_path, 'w', encoding='utf-8') as f:
        f.write("=== Mini CAD Console Journal Export ===\n\n")
        for entry in entries:
            timestamp = entry.get("timestamp", "unknown time")
            text = entry.get("entry", "")
            f.write(f"[{timestamp}]\n{text}\n\n")

    print(f"📤 Exported journal to: {export_path}")

def open_journal():
    ensure_log_exists()
    entries = load_log()
    print("✅ Loaded entries:", entries)
    print("🔢 Count:", len(entries))
    
    print("\n=== 🪵 Mini CAD Console: Journal ===")
    print("Type your journal entry and press [Enter] to save it.")
    print("Type 's' or 'stop' and press [Enter] to quit.")
    print("Type 'export' to convert journal to a .txt file.\n")

    while True:
        line = input(">>> ").strip()

        if line.lower() in {"s", "stop"}:
            print("🛑 Journal session ended.")
            break

        elif line.lower() == "export":
            convert_json_to_text()
            continue

        if line:
            entry = {
                "timestamp": datetime.now().isoformat(),
                "entry": line
            }
            entries.append(entry)
            save_log(entries)
            print("✅ Entry saved.")
