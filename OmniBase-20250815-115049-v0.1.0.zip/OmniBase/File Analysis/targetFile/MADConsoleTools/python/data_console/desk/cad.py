import sys
import os
from pathlib import Path

project_dir = Path(__file__).resolve().parent

# Path to FreeCAD's bin folder
FREECAD_BIN = r"C:\Program Files\FreeCAD 1.0\bin"
sys.path.append(FREECAD_BIN)

# Set environment so it finds DLLs
os.environ["PATH"] = FREECAD_BIN + os.pathsep + os.environ["PATH"]


def load_doc(start_path=None):
    try:
        import FreeCAD as App
        docs = list(App.listDocuments().values())
        for doc in docs:
            App.closeDocument(doc.Name)
        print("🧹 Closed all open FreeCAD documents.")
    except Exception as e:
        print(f"⚠️ Failed to close documents: {e}")
        return

    print("=== FreeCAD Script Loader ===")

    # Normalize path input
    if start_path:
        search_root = Path(start_path).expanduser().resolve()
    else:
        search_root = project_dir.parent.parent.resolve()

    if not search_root.exists():
        print(f"❌ Provided path does not exist: {search_root}")
        return

    print(f"Searching from: {search_root}")

    try:
        import FreeCAD as App
        if App.ActiveDocument is None:
            print("No document is currently open. Searching for .FCStd files...")

            fcstd_files = []
            for root, dirs, files in os.walk(search_root):
                if any(part.endswith("_console") for part in Path(root).parts):
                    continue
                for file in files:
                    if file.lower().endswith(".fcstd"):
                        fcstd_files.append(os.path.join(root, file))

            if not fcstd_files:
                print("❌ No .FCStd files found.")
                return

            print("\nFound the following .FCStd files:")
            for i, f in enumerate(fcstd_files):
                print(f"  [{i}] {Path(f).relative_to(search_root)}")

            while True:
                choice = input("\nEnter file number to open (Enter for [0]): ").strip()
                try:
                    index = int(choice) if choice else 0
                    if 0 <= index < len(fcstd_files):
                        doc = App.openDocument(fcstd_files[index])
                        App.setActiveDocument(doc.Name)
                        print(f"✅ Opened: {fcstd_files[index]}")
                        break
                    else:
                        print(f"❌ Invalid number (0–{len(fcstd_files) - 1})")
                except ValueError:
                    print("❌ Invalid input. Please enter a number.")
    except Exception as e:
        print(f"❌ Error loading documents: {e}")
