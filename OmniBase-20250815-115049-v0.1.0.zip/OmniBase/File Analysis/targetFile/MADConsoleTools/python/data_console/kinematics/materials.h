#pragma once
#include "circuit.h"


namespace material{
		
	struct length{
		double L;
	};
	
	struct area{
		double A;
	};
	
	struct temperature{
		double T; //Temperature
	};
	
	struct conductivity{	
		double k; //Thermal Conductivity
	};
	
	struct Pheat{
		double P;
	};
	
	// Database for material resistivities
    class MaterialDB {
    public:
        static const std::unordered_map<std::string, double>& getResistivityTable() {
            static const std::unordered_map<std::string, double> resistivity_table = {
                {"diamond", 1e-13},
                {"silver", 1.59e-8},
                {"copper", 1.68e-8},
                {"gold", 2.44e-8},
                {"aluminium", 2.82e-8},
                {"beryllia_ceramic", 1e12},
                {"molybdenum", 5.2e-8},
                {"brass", 7e-8},
                {"silicon", 6.4e2},
                {"platinium", 10.6e-8},
                {"tin", 1.09e-7},
                {"nickle", 6.99e-8},
                {"tin_solder", 1.3e-7},
                {"lead", 2.2e-7},
                {"indium", 8.37e-8},
                {"boron_nitride", 1e14},
                {"alumina_ceramic", 1e12},
                {"kovar", 4.9e-7},
                {"silicon_carbide", 1e3},
                {"steel300", 7.2e-7},
                {"nichrome", 1.1e-6},
                {"carbon", 3.5e-5},
                {"ferrite", 1e8},
                {"polyceram", 1e12},
                {"epoxyHC", 1e11},
                {"quartz", 1e16},
                {"glass774", 1e14},
                {"silicon_grease", 1e11},
                {"water", 1.8e5},
                {"mica", 1e12},
                {"polyethylene", 1e17},
                {"nylon", 1e12},
                {"silicon_rubber", 1e13},
                {"teflon", 1e18},
                {"ppo", 1e14},
                {"polystyrene", 1e15},
                {"mylar", 1e13},
                {"air", 2e16}
            };
            return resistivity_table;
        }
	
	
	struct black_box{
		circuit::resistance Resistance;
		area Area;
		length Length;
		temperature Temp;
		std::string material_name;
		conductivity Conductivity;
	};	
	
	
	
	inline circuit::power thermal_conductance(const black_box& box) {
		circuit::power P;
		P.W = box.Conductivity.k * (box.Area.A / box.Length.L);
		return P;
	}
	inline circuit::power heat_transfer(const black_box& box, double delta_T) {
		circuit::power P;
		double G = box.Conductivity.k * (box.Area.A / box.Length.L);
		P.W = G * delta_T;
		return P;
	}
	inline circuit::power thermal_resistance(const black_box& box) {
		circuit::power P;
		const auto& resistivity_table = MaterialDB::getResistivityTable();
		auto it = resistivity_table.find(box.material_name);
		if (it != resistivity_table.end()) {
			double rho = it->second;
			P.W = rho * (box.Length.L / box.Area.A);
		} else {
			P.W = -1.0;
		}
		return P;
	}
	inline circuit::resistance electrical_resistance(const black_box& box) {
		const auto& table = MaterialDB::getResistivityTable();
		auto it = table.find(box.material_name);
		if (it != table.end()) {
			double rho = it->second;
			return circuit::resistance{rho * (box.Length.L / box.Area.A)};
		}
		return circuit::resistance{-1.0}; // error
	}


	
	
	
};