#include "kinematics.h"

//Robot Build

struct Link{
	RigidBody link_body;
	float length, width, height;
};
struct Base {
	RigidBody base_body;
	float length, width, height;
};


enum class JointType{
	REVOLUTE,
	PRISMATIC,
	FIXED
};

struct Joint{
	JointType joint_type;
	int position; //theta or q
	float velocity; //dTheta/dt or dq/dt
	int min_position, max_position, max_zpeed, min_speed;
	
	Kinematics::S q;
	Kinematics::S w;
	float pitch;
};

struct EndEffector{
	RigidBody claw_body;
	float length_open, length_closed, width, height; 
	int max_speed, min_speed;
	S ClampTarget;
};
	
struct Robot{
	std::vector<Base> bases;
	std::vector<Joint> joints;
	std::vector<Link> links;
	std::vector<EndEffector> end_effectors;
	int default_speed;
};



class 6DOF_Bot{
	
	public:
		6DOF_Bot(){
			Robot robot;
			Base base;
			Link link_1;
			Link link_2;
			Link link_3;
			EndEffector end_effector;
			
			robot.default_speed = 1000;
			
			base.length = 26.0f;
			base.width =	12.0f;
			base.height = 11.5f;
			
			robot.bases.push_back(base);
			
			Joint joint1 {JointType::REVOLUTE, 90, 0, 0, 180, 900, 1200};
			Joint joint2 {JointType::REVOLUTE, 180, 0, 0, 180, 900, 1200};
			Joint joint3 {JointType::REVOLUTE, 0, 0, 0, 180, 900, 1200};
			Joint joint4 {JointType::REVOLUTE, 0, 0, 0, 180, 900, 1200};
			Joint joint5 {JointType::REVOLUTE, 90, 0, 0, 180, 900, 1200};
			Joint joint6 {JointType::REVOLUTE, 90, 0, 0, 180, 900, 1200};
			
			robot.joints.push_back(joint1);
			robot.joints.push_back(joint2);
			robot.joints.push_back(joint3);
			robot.joints.push_back(joint4);
			robot.joints.push_back(joint5);
			robot.joints.push_back(joint6);
			
			link_1.length = 8.5;
			link_1.width = 2.5;
			link_1.height = 2.5;
			
			link_2.length = 8.5;
			link_2.width = 2.5;
			link_2.height = 2.5;
			
			link_3.length = 8.5;
			link_3.width = 2.5;
			link_3.height = 2.5;
			
			robot.links.push_back(link_1);
			robot.links.push_back(link_2);
			robot.links.push_back(link_3);
			
			end_effector.length_open = 7.5f;
			end_effector.length_closed = 11.0f;
			end_effector.width = 6.0f;
			end_effector.height = 0.5f;
			
			robot.end_effectors.push_back(end_effector);
	private:
		
	protected:
	
};