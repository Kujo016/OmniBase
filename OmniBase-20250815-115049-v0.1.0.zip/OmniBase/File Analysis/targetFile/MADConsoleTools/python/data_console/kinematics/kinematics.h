#pragma once
#include <vector>
#include <cmath>
//Chapter 2
//Mathematics
//Single point in 2D space
namespace Kinematics{
	struct P{
		float x, y;
	};

	//A single point in 3D space
	struct S{
		float x, y, z;
	};

	//Object attached to another object or a 2D object
	struct PlanarObject{
		P origin;
		P x_axis;
		P y_axis;
	};

	//Free standing object, usually 3D space ojects
	struct SpatialObject{
		S origin; 
		S x_axis;
		S y_axis;
		S z_axis;
	};
	//Body of an object
	struct Body{
		PlanarObject frame;
		std::vector<P> points;
	};

	struct RigidBody{
		SpatialObject frame; //Robot pose
		std::vector<S> points; //Robot shape
		
	};
	//Configuration space
	struct Configuration{
		std::vector<float> q; //q = generalized coordinates
		int dof;
	};
	//Control Value
	struct ControlInput{
		std::vector<float> u;
	};
	//Constraint 
	struct Constraint{
		std::vector<float> coefficients; //A(q)
	};
	//Constraint vector/vector
	struct VelocityConstraint{
		std::vector<std::vector<float>> A; //A(q)q. = 0
	};


	//Chapter 3
	struct RotationMatrix{
		float T[3][3];  // 3x3 rotation matrix R ∈ SO(3)
	};

	struct Transform{
		float T[4][4]; // Homogeneous transformation matrix T ∈ SE(3)
	};

	struct Twist{
		float T[6]; // [ωx, ωy, ωz, vx, vy, vz]
	};

	struct Adjoint{
		float Ad[6][6];  // 6x6 matrix to transform twists or wrenches
	};

	struct Wrench{
		float wrench[6];// [nx, ny, nz, fx, fy, fz]
	};

	struct DHParam {
		float a;
		float alpha;
		float d;
		float theta;
		JointType type; // REVOLUTE or PRISMATIC
	};

	//Rotate x axis
	RotationMatrix RotationMatrix_x3x3(float angle_rad){
		RotationMatrix rot;
		float c = std::cos(angle_rad);
		float s = std::sin(angle_rad);
		
		rot.T[0][0] = 1; rot.T[0][1] = 0; rot.T[0][2] = 0;
		rot.T[1][0] = 0; rot.T[1][1] = c; rot.T[1][2] = -s;
		rot.T[2][0] = 0; rot.T[2][1] = s; rot.T[2][2] = c;
		
		return rot;
		
	};
	//Rotate y axis
	RotationMatrix RotationMatrix_y3x3(float angle_rad){
		RotationMatrix rot;
		float c = std::cos(angle_rad);
		float s = std::sin(angle_rad);
		
		rot.T[0][0] = c; rot.T[0][1] = 0; rot.T[0][2] = s;
		rot.T[1][0] = 0; rot.T[1][1] = 1; rot.T[1][2] = 0;
		rot.T[2][0] = -s; rot.T[2][1] = 0; rot.T[2][2] = c;
		
		return rot;
	};
	//Rotate z axis
	RotationMatrix RotationMatrix_z3x3(float angle_rad){
		RotationMatrix rot;
		float c = std::cos(angle_rad);
		float s = std::sin(angle_rad);
		
		rot.T[0][0] = c; rot.T[0][1] = -s; rot.T[0][2] = 0;
		rot.T[1][0] = s; rot.T[1][1] = c; rot.T[1][2] = 0;
		rot.T[2][0] = 0; rot.T[2][1] = 0; rot.T[2][2] = 1;
		
		return rot;
	};
	//Skew Rotation
	RotationMatrix SkewMatrix_3x3(S w){
		RotationMatrix rot;
		
		rot.T[0][0] = 0; rot.T[0][1] = -w.z; rot.T[0][2] = w.y;
		rot.T[1][0] = w.z; rot.T[1][1] = 0; rot.T[1][2] = -w.x;
		rot.T[2][0] = -w.y; rot.T[2][1] = w.x; rot.T[2][2] = 0;
		
		return rot;
	};

	//Matrix manipulation
	RotationMatrix MatrixSubtract(const RotationMatrix& A, const RotationMatrix& B);
	RotationMatrix MatrixTranspose(const RotationMatrix& R);
	RotationMatrix MatrixMultiply(const RotationMatrix& A, const RotationMatrix& B);
	S SkewToVector(const RotationMatrix& skew);
	S GetAngularVelocity_SpaceFrame(RotationMatrix R, RotationMatrix R_next, float dt); 
	S GetAngularVelocity_BodyFrame(RotationMatrix R, RotationMatrix R_next, float dt);

	//Transform Matrix
	Transform CreateTransform(const RotationMatrix& R, const S& pos);
	Transform MultiplyTransform(const Transform& A, const Transform& B);
	Transform InverseTransform(const Transform& T);

	//Rotate Matrix
	S NormalizeVector(S v);
	//SO(3)
	 RotationMatrix MatrixExp3(S w, float theta);
	S MatrixVectorMultiply(const RotationMatrix& M, const S& v);
	
	//SE(3)
	Transform MatrixExp6(Twist V, float theta);
	
	Adjoint AdjointFromTransform(const Transform& T);
	
	Twist ScrewToTwist(const S& w, const S& q, float h);
	Wrench CreateWrench(const S& torque, const S& force);


	//Kinematics
	std::vector<float> GetJointPositions(const Robot& robot);
	Transform PoE_ForwardKinematics(const std::vector<Twist>& twists, const std::vector<float>& thetas, const Transform& M);
	Transform ConstructDHTransform(float theta, float d, float a, flaoth alpha);
	Transform D_H_ForwardKinematics(const std::vector<float>& joint_vars, const std::vector<DHParam>& dh_table)std::vector<Twist> SpaceJacobian(const std::vector<Twist>& S_list, const std::vector<float>& theta_list);
	Twist MultiplyAdjointTwist(const Adjoint& Ad, const Twist& V);

};
