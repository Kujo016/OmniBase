#include <iostream>
#include "kinematics.h"

using namespace Kinematics;

S SkewToVector(const RotationMatrix& skew){
	return{
		skew.T[2][1],
		skew.T[0][2],
		skew.T[1][0]
	};
}

RotationMatrix MatrixSubtract(const RotationMatrix& A, const RotationMatrix& B){
	RotationMatrix C;
	for (int i = 0; i < 3; ++i){
		for (int j = 0;  j < 3; ++j){
			C.T[i][j] = A.T[i][j] - B.T[i][j];
		}
	}
	return C;
}

RotationMatrix MatrixTranspose(const RotationMatrix& R){
	RotationMatrix Rt;
	for (int i = 0; i < 3; ++i){
		for (int j = 0; j < 3; ++j){
			Rt.T[i][j] = R.T[j][i];
		}
	}
	return Rt;
}

RotationMatrix MatrixMultiply(const RotationMatrix& A, const RotationMatrix& B){
	RotationMatrix C;
	//Initialize
	for(int i = 0; i < 3; ++i){
		for(int j = 0; j < 3; ++j){
			C.T[i][j]= 0.0f;
		}
	}
	
	for (int i = 0; i < 3; ++i){
		for(int j = 0; j < 3; ++j){
			for (int k = 0; k < 3; ++k){
				C.T[i][j] += A.T[i][k] * B.T[k][j];
			}
		}
	}
	return C;
}




S GetAngularVelocity_SpaceFrame(RotationMatrix R, RotationMatrix R_next, float dt){
	RotationMatrix R_dot = MatrixSubtract(R_next, R);
	for (int i = 0; i < 3; ++i){
		for (int j = 0; j < 3; j++){
			R_dot.T[i][j] /= dt;
		}
	}
	RotationMatrix R_inv = MatrixTranspose(R);
	RotationMatrix skew = MatrixMultiply(R_dot, R_inv);
	return SkewToVector(skew);
}


S GetAngularVelocity_BodyFrame(RotationMatrix R, RotationMatrix R_next, float dt){
	RotationMatrix R_dot = MatrixSubtract(R_next, R);
	for (int i = 0; i < 3; ++i){
		for (int j = 0; j < 3; j++){
			R_dot.T[i][j] /= dt;
		}
	}
	RotationMatrix R_inv = MatrixTranspose(R);
	RotationMatrix skew = MatrixMultiply(R_inv, R_dot);
	return SkewToVector(skew);
	
}




Transform CreateTransform(const RotationMatrix& R, const S& pos){
	Transform C;
	
	//First set algorithmically
	for (int i = 0; i < 3; ++i){
		for (int j = 0; j < 3; ++j){
			C.T[i][j] = R.T[i][j];
		}
	}
	
	//Set Posistion manually
	C.T[0][3] = pos.x;
	C.T[1][3] = pos.y;
	C.T[2][3] = pos.z;
	
	//Set Bottom row
	C.T[3][0] = 0.0f;
	C.T[3][1] = 0.0f;
	C.T[3][2] = 0.0f;
	C.T[3][3] = 1.0f;
	
	return C;
}
Transform MultiplyTransform(const Transform& A, const Transform& B){
	Transform M;
	
	//Initialize
	for(int i = 0; i < 4; ++i){
		for(int j = 0; j < 4; ++j){
			M.T[i][j]= 0.0f;
		}
	}
	
	
	for (int i = 0; i < 4; ++i){
		for (int j = 0; j < 4; ++j){
			for(int k = 0; k < 4; ++k){
				M.T[i][j] += A.T[i][k] * B.T[k][j];
			}
		}
	}
	
	return M;
}
	
Transform InverseTransform(const Transform& T){
	Transform I;
	//Transpose the rotation part (top left 3x3)
	for(int i = 0; i < 3; ++i){
		for(int j = 0; j < 3; ++j){
			I.T[i][j] = T.T[j][i];
		}
	}
	//Compute new translation part: -R^T * p
	for(int i = 0; i < 3; ++i){
		I.T[i][3] = 0.0f;
		for(int j = 0; j < 3; ++j){
			I.T[i][3] -= T.T[j][i] * T.T[j][3];
		}
	}
	
	//Set the bottom row
	I.T[3][0] = 0.0f;
	I.T[3][1] = 0.0f;
	I.T[3][2] = 0.0f;
	I.T[3][3] = 1.0f;
		
	
	return I;
	
}

S NormalizeVector(S v) {
    float length = std::sqrt(v.x * v.x + v.y * v.y + v.z * v.z);
    if (length == 0) return {0, 0, 0};  // handle zero vector case
    return {v.x / length, v.y / length, v.z / length};
}


RotationMatrix MatrixExp3(S w, float theta){
	//R=I+sin(θ)[w]+(1−cos(θ))[w]^2 
	w = NormalizeVector(w);
	RotationMatrix R;
	RotationMatrix I;
	RotationMatrix w_skew = SkewMatrix_3x3(w);
	RotationMatrix w_skew_squared = MatrixMultiply(w_skew, w_skew);
	
	for(int i = 0; i < 3; ++i){
		for(int j = 0; j < 3; ++j){
			I.T[i][j] = (i==j) ? 1.0f : 0.0f;
		}
	}
	
	for(int  i = 0; i < 3; i++){
		for(int j = 0; j < 3; ++j){
			R.T[i][j] = I.T[i][j]
				+ std::sin(theta) * w_skew.T[i][j]
				+ (1- std::cos(theta)) * w_skew_squared.T[i][j];
		}
	}
	
	return R;
}
//Helper function:Transform MatrixExp6()
S MatrixVectorMultiply(const RotationMatrix& M, const S& v) {
    return {
        M.T[0][0]*v.x + M.T[0][1]*v.y + M.T[0][2]*v.z,
        M.T[1][0]*v.x + M.T[1][1]*v.y + M.T[1][2]*v.z,
        M.T[2][0]*v.x + M.T[2][1]*v.y + M.T[2][2]*v.z
    };
}


Transform MatrixExp6(Twist V, float theta){
	Transform T
	RotationMatrix R;
	RotationMatrix I;
	
	for (int i = 0; i < 3; ++i){
		for (int j = 0; j < 3; ++j){
			I.T[i][j] = (i == j) ? 1.0f : 0.0f;
		}
	}
	
	S w = {
		V.T[0],
		V.T[1],
		V.T[2]
	};
	
	S v = {
		V.T[3],
		V.T[4],
		V.T[5]
	};
	w = NormalizeVector(w);

	
	RotationMatrix w_skew = SkewMatrix_3x3(w);
	RotationMatrix w_skew_squared = MatrixMultiply(w_skew, w_skew);
	
	if(w.x == 0 && w.y == 0 && w.z == 0){
		T.T[0][3] = v.x * theta;
		T.T[1][3] = v.y * theta;
		T.T[2][3] = v.z * theta;
	}
	else{
		R = MatrixExp3(w, theta);
		S term1 = {v.x * theta, v.y * theta, v.z * theta};
		S term2 = MatrixVectorMultiply(w_skew, v);
		S term3 = MatrixVectorMultiply(w_skew_squared,v);
		
		float c1 = 1 - std::cos(theta);
		float c2 = theta - std::sin(theta);
		
		term2 = {term2.x * c1, term2.y * c1, term2.z * c1};
		term3 = {term3.x * c2, term3.y * c2, term3.z * c2};
		
		S p = {
			term1.x + term2.x + term3.x,
			term1.y + term2.y + term3.y,
			term1.z + term2.z + term3.z
		};
		
		for(int i = 0; i < 3; ++i){
			for(int j = 0; j < 3; ++j){
				T.T[i][j] = R.T[i][j];
			}
		}
		
		T.T[0][3] = p.x;
		T.T[1][3] = p.y;
		T.T[2][3] = p.z;
		
	}		
	
	T.T[3][0] = 0.0f;
	T.T[3][1] = 0.0f;
	T.T[3][2] = 0.0f;
	T.T[3][3] = 1.0f;
	
	return T;

}

Adjoint AdjointFromTransform(const Transform& T) {
    Adjoint Ad;

    RotationMatrix R;
    S p;

    // Extract R and p from T
    for (int i = 0; i < 3; ++i) {
        p.x = T.T[0][3];
        p.y = T.T[1][3];
        p.z = T.T[2][3];
        for (int j = 0; j < 3; ++j) {
            R.T[i][j] = T.T[i][j];
        }
    }

    // Compute skew(p) * R
    RotationMatrix p_skew = SkewMatrix_3x3(p);
    RotationMatrix pr = MatrixMultiply(p_skew, R);

    // Fill Adjoint matrix
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            Ad.Ad[i][j]     = R.T[i][j];   // Top-left block
            Ad.Ad[i][j+3]   = 0.0f;        // Top-right block
            Ad.Ad[i+3][j]   = pr.T[i][j];  // Bottom-left block
            Ad.Ad[i+3][j+3] = R.T[i][j];   // Bottom-right block
        }
    }

    return Ad;
}

Twist ScrewToTwist(const S& w, const S& q, float h) {
    w = NormalizeVector(w);
	Twist V;

    // Compute v = -w × q
    S v;
    v.x = - (w.y * q.z - w.z * q.y);
    v.y = - (w.z * q.x - w.x * q.z);
    v.z = - (w.x * q.y - w.y * q.x);

    // Add pitch term: v += h * w
    v.x += h * w.x;
    v.y += h * w.y;
    v.z += h * w.z;

    // Fill twist vector: [w; v]
    V.T[0] = w.x;
    V.T[1] = w.y;
    V.T[2] = w.z;
    V.T[3] = v.x;
    V.T[4] = v.y;
    V.T[5] = v.z;

    return V;
}

Wrench CreateWrench(const S& torque, const S& force) {
    Wrench W;
    W.wrench[0] = torque.x;
    W.wrench[1] = torque.y;
    W.wrench[2] = torque.z;
    W.wrench[3] = force.x;
    W.wrench[4] = force.y;
    W.wrench[5] = force.z;
    return W;
}

//Helper Function::Return current thetas. NOTE:call before PoE
std::vector<float> GetJointPositions(const Robot& robot) {
	std::vector<float> thetas;
	for (const auto& joint : robot.joints) {
		thetas.push_back(static_cast<float>(joint.position));
	}
	return thetas;
}

//ForwardK with known end effector and base to return transform for 
Transform PoE_ForwardKinematics(const std::vector<Twist>& twists, const std::vector<float>& thetas, const Transform& M){
	Transform T;
	
	//Init the identity matrix
	for (int i = 0; i < 4; ++i){
		for(int j = 0; j < 4; ++j){
			T.T[i][j] = (i == j) ? 1.0f : 0.0f;
		}
	}
	
	//Multiply the exponentials in order
	for(size_t i = 0; i < twists.size(); ++i){
		Transform exp = MatrixExp6(twists[i], theta[i]));
		T = MultiplyTransform(T, exp);
	}
	
	T = MultiplyTransform(T, M);
	
	return T;
}

//Helper Function:Denavit-Hartenberg
Transform ConstructDHTransform(float theta, float d, float a, flaoth alpha){
	Transform T;
	
	float ct = std::cos(theta);
	float st = std::sin(theta);
	float ca = std::cos(alpha);
	float sa = std::sin(alpha);
	
	T.T[0][0] = ct; 	T.T[0][1] = -st * ca; 	T.T[0][2] = st * sa; 	T.T[0][3] = a * ct; 
	T.T[1][0] = st; 	T.T[1][1] = ct * ca; 	T.T[1][2] = -ct * sa; 	T.T[1][3] = a * st;
	T.T[2][0] = 0.0f; 	T.T[2][1] = sa; 		T.T[2][2] = ca; 		T.T[2][3] = d;
	T.T[3][0] = 0.0f; 	T.T[3][1] = 0.0f; 		T.T[3][2] = 0.0f; 		T.T[3][3] = 1.0f ;
	
	return T;
}



//ForwardK Denavit-Hartenberg (linear) 
Transform D_H_ForwardKinematics(const std::vector<float>& joint_vars, const std::vector<DHParam>& dh_table){
	Transform T;
	
	//Init the identity matrix
	for (int i = 0; i < 4; ++i){
		for(int j = 0; j < 4; ++j){
			T.T[i][j] = (i == j) ? 1.0f : 0.0f;
		}
	}
	
	//Multiply the exponentials in order
	for(size_t i = 0; i < dh_table.size(); ++i){
		float theta = dh_table.[i].theta;
		float d 	= dh_table[i].d;
		
		//Replace variable according to joint type
		if (dh_table.type == JointType::REVOLUTE){
			theta = joint_vars[i];
		}
		else if (dh_table[i].type == JointType::PRISMATIC){
			d = joint_vars[i];
		}
		
		float a = dh_table[i].a;
		float alpha = dh_table[i].alpha;
		
		//Build SERTM here
		Transform A_i = ConstructDHTransform(theta, d, a, alpha);
		T = MultiplyTransform(T, A_i);
		
	}
		
	
	return T;
}

//Helper Function: Space Jacobian
Twist MultiplyAdjointTwist(const Adjoint& Ad, const Twist& V) {
    Twist result;
    for (int i = 0; i < 6; ++i) {
        result.T[i] = 0.0f;
        for (int j = 0; j < 6; ++j) {
            result.T[i] += Ad.Ad[i][j] * V.T[j];
        }
    }
    return result;
}

//Determine twist for end effector
std::vector<Twist> SpaceJacobian(const std::vector<Twist>& S_list, const std::vector<float>& theta_list){
	std::vector<Twist> J_s;
	Transform T;
	
	J_s.push_back(S_list[0]);

	
	for (int i = 0; i < 4; ++i){
		for (int j = 0; j < 4; ++j){
			T.T[i][j] = (i == j) ? 1.0f : 0.0f;
		}
	}
	for(int i = 1; i < S_list.size(); ++i){
		//Get exponential map of the last screw and angle
		Transform T_i = MatrixExp6(S_list[i-1], theta_list[i-1]);
		
		//Chain it to the previous transform
		T = MultiplyTransform(T, T_i);
		
		//Get the adjoint from the transform
		Adjoint Ad_T = AdjointFromTransform(T);
		
		//Multiply adjoint by current screw axis
		Twist new_S = MultiplyAdjointTwist(Ad_T, S_list[i]);
		
		//Add to Jacobian
		J_s.push_back(new_S);
	}
	
	return J_s;	
	
}