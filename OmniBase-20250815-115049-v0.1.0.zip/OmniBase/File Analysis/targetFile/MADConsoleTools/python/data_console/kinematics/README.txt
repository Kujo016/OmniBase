ROBONEURONICS 
README
by Joshua (Kujo) Kujawa

Roboneuronics is a collection of formulas and functions from Practical Electronics for Inventors, Modern Robotics: Mechanics, Planning, and Control converted to C++.

The object of the system and architecture is to provide a full diagnostic account of the robot (speed, temperature, location, device status, etc...) to an AI in simulation. This will allow the robot to be debugged further, as well as provide a sense to an AI. This allows further manipulation with a base to build from. If the AI has no idea how fast the robot's arm is travelling then the AI cannot track motion smoothly.

The code is designed to be integrated into other robotics systems using C++, Python etc... via the proper bindings. For integration of PCB circuit, start at circuit.cpp. For Robot build start at robot. DOF6.cpp is an example based off of the Yahboom DOF6 with 2D Camera.

The function of the library is to be somewhat of a monitoring system where the parts of the pcb can be modeled. The simulation will reflect the running state of the machine, where as a main is written along side a esp32/arduino/stm32 with real values coming from the machine. The values can be written to the servos and logged in the pcb circuitry where the system will eventually out put a monitoring system in opengl, where the robot is model in 3d and mocks the actual robot movement. This will allow for full simulation testing, before the robot is even deployed