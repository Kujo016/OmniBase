#pragma once
#include <vector>
#include <cmath>


namespace circuit{
	//-------------------------
	//Formula Variables:
	struct voltage{
		double V;
	};
	struct amperage{
		double I;
	};
	struct resistance{
		double R;
	};
	struct capacitance{
		double C;
	};
	struct inductance{
		double L;
	};
	struct power{
		double W;
	};
	//-------------------------
	//Symbols:
	struct ground{
		double g;
	};
	struct volt_terminals{
		double p;
		double n;
	};
	struct battery{
		volt_terminals batt_terminal;
		voltage batt_volts;
		amperage batt_amps;
		power batt_watts;
		ground batt_ground;
	};
	struct module{
		voltage volt_load;
		amperage amp_load;
		resistance resistance_load;
		power power_load;
		volt_terminals mod_terminal;
		ground mod_ground;
	};
	struct capacitor{
		capacitance capacity;
		volt_terminals cap_v_terminal;
		voltage volt_load;
		amperage amp_load;
		resistance resistance_load;
		power power_load;
		ground cap_ground;
	};
	struct resistor{
		resistance resistance;
		volt_terminals res_terminal;
		voltage volt_load;
		amperage amp_load;
		resistance resistance_load;
		power power_load;
		ground res_ground;
		
	};
	struct inductor{
		inductance inductance;
		volt_terminals ind_terminal;
		voltage volt_load;
		amperage amp_load;
		resistance resistance_load;
		power power_load;
		ground ind_ground;
	};
	
	struct node{
		resistance node_resistance;
		capacitance node_capacity;
		inductance node_inductance;
		voltage volt_load;
		volt_terminals node_terminal;
		voltage node_volt_load;
		amperage node_amp_load;
		resistance resistance_load;
		power node_power_load;
		ground node_ground;
	};
	
	//Vectors for circuit
	struct resistors{std::vector<resistor> resistor_vector;};
	struct capacitors{std::vector<capacitor> capacitor_veector;};
	struct inductors{std::vector<inductor> inductor_vector;};
	
	
	//-------------------------
	//Operator Overloads:
	//* Ohm's Law V = I * R
	inline voltage operator*(const amperage& amp, const resistance& ohm){return voltage{amp.I * ohm.R};}
	inline resistance operator/(const amperage& amp, const voltage& volt){return resistance{volt.V / amp.I};}
	inline amperage operator/(const voltage& volt, const resistance& ohm){return amperage{volt.V / ohm.R};}
	//* Generalised Power Law P = V * I 
	inline power operator*(const voltage& volt, const amperage& amp){return power{vol.V * amp.I};}
	inline voltage operator/(const power& watt, const amperage& amp){return voltage{watt.W/amp.I};}
	inline amperage operator/(const power& watt, const voltage& volt){return amperage{watt.W/volt.V};}
	/*//* Generalized power law refined. Resistors only (heat law applies to power converted to heat 
		only or 100% ohmic) P = I^2 * R*/
	inline resistance operator/(const power& watt, const amperage& amp){return resistance{watt.W/ std::pow(amp.I, 2)};}
	inline power operator*(const resistance& ohm, const amperage& amp){return power{std::pow(amp.I, 2) * ohm.R };}
	inline power operator/(const voltage& volt, const resistance& ohm){return power{std::pow(volt.V, 2) / ohm.R};}
	//-------------------------
	//Operator Inline Functions:
	//* Ohms Law 	V = I * R
	inline voltage OhmsLaw_Voltage(const amperage& amp, const resistance& ohm) { return amp * ohm; }
	inline resistance OhmsLaw_Resistance(const amperage& amp, const voltage& volt) { return volt / amp; }
	inline amperage OhmsLaw_Amperage(const voltage& volt, const resistance& ohm) { return volt / ohm; }
	
	//* Generalized Power Law P = V * I
	inline power General_PowerLaw_Power(const voltage& volt, const amperage& amp){return volt*amp;}
	inline voltage General_PowerLaw_Voltage(const power& watt, const amperage& amp){return watt/amp;}
	inline amperage General_PowerLaw_Amperage(const voltage& volt, const power& watt){return watt/volt;}
	
	//* Power Loss to Heating
	//-Generalized Power Law P = V * I
	inline resistance  HeatLaw_ResistanceSquared(const power& watt, const amperage& amp){return watt/amp;}
	inline voltage HeatLaw_ByAmps(const power& watt, const amperage& amp){return watt/amp;}
	inline amperage HeatLaw_ByVolts(const voltage& volt, const power& watt){return watt/volt;}
	
	//-------------------------
	//Components:
	//* Batttery
	//-Battery Pack
	struct battery_pack{std::vector<battery> charged;};
	//-Series 
	inline power getBatteryPower_Series(battery_pack& battery)
		{power total{0.0}; for (const auto& b : battery.charged){total.W += b.batt_watts.W;} return total;}
	inline voltage getBatteryVoltage_Series(battery_pack& battery)
		{voltage total{0.0}; for (const auto& b : battery.charged){total.V += b.batt_volts.V;} return total;}
	inline amperage getBatteryAmperage_Series(battery_pack& battery)
		{return battery.charged.empty() ? amperage{ 0.0 } : battery.charged.front().batt_amps;}
	//-Parallel
	inline power getBatteryPower_Parallel(battery_pack& battery)
		{power total{0.0}; for (const auto& b : battery.charged){total.W += b.batt_watts.W;} return total;}
	inline voltage getBatteryVoltage_Parallel(battery_pack& battery)
		{return battery.charged.empty() ? voltage{0.0} : battery.charged.front().batt_volts;}
	inline amperage getBatteryAmperage_Parallel(battery_pack& battery)
		{amperage total{0.0}; for (const auto& b : battery.charged){total.I += b.batt_amps.I;} return total;}
	//-Battery Power
	inline battery_pack Drain_Battery(battery_pack battery, module mod)
		{for(auto& b : battery.charged){b.batt_watts.W -= mod.power_load.W; b.batt_amps.I -= mod.amp_load.I;}return battery;}
	inline battery_pack Charge_Battery(battery_pack battery, module mod)
		{for(auto& b : battery.charged){b.batt_watts.W += mod.power_load.W; b.batt_amps.I += mod.amp_load.I;}return battery;}
	
	//----------------------------------------------//
	//Resistors
	//-Parallel
	inline resistance Total_Resistance_Parallel(const resistors& resistor_group){resistance R_tot; double reciprocal_sum = 0.0; 
		for(const auto& r: resistor_group.resistor_vector){	if(r.resistance.R != 0){reciprocal_sum +=1.0/r.resistance.R;}} 
		R_tot.R = (reciprocal_sum != 0.0) ? (1.0/reciprocal_sum):0.0; return R_tot;}
	inline resistance R1-R2_Resistance_Parallel(const resistor& res1, const resistor& res2){ resistance R_tot; 
		double R1 = res1.resistance.R; double R2 = res2.resistance.R; if ((R1 + R2) != 0.0) {
        R_tot.R = (R1 * R2) / (R1 + R2);} else {R_tot.R = 0.0;}return R_tot;}
	//-Series
	inline resistance Total_Resistance_Series(const resistors& resistor_group){resistance R_tot{0.0}; 
		for (const auto& r : resistor_group.resistor_vector){R_tot.R += r.resistance.R;}return R_tot;}
	//----------------------------------------------//
	//Capacitors
	//-Parallel
	inline capacitance Total_Capacitance_Parallel(const capacitors& group){capacitance C_tot{0.0}; 
		for(const auto& c : group.capacitor_vector) {C_tot.C += c.capacity.C;}return C_tot;}
	//-Series
	inline capacitance Total_Capacitance_Series(const capacitors& group){double reciprocal_sum = 0.0; 
		for(const auto& c : group.capacitor_vector){if(c.capacity.C != 0.0) reciprocal_sum += 1.0 / c.capacity.C;}
		return capacitance{reciprocal_sum != 0.0 ? 1.0 / reciprocal_sum : 0.0};}
	//----------------------------------------------//
	//Inductors 
	//-Parallel
	inline inductance Total_Inductance_Parallel(const inductors& group){double reciprocal_sum = 0.0;
		for(const auto& l : group.inductor_vector) {if(l.inductance.L != 0.0) reciprocal_sum += 1.0 / l.inductance.L;}
		return inductance{reciprocal_sum != 0.0 ? 1.0 / reciprocal_sum : 0.0};
	}
	//-Series
	inline inductance Total_Inductance_Series(const inductors& group){inductance L_tot{0.0}; 
		for(const auto& l : group.inductor_vector) {L_tot.L += l.inductance.L;	}return L_tot;}
	//----------------------------------------------//
	
	//-------------------------
	//Grid:
	struct grid{
		std::vector<battery_pack> batteries;
		std::vector<resistors> resistors;
		std::vector<capacitors> capacitors;
		std::vector<inductors> inductors;
		std::vector<node> nodes;
	};
};