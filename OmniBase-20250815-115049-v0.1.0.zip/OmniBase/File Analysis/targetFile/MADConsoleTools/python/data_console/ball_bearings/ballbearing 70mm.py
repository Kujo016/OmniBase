import FreeCAD as App
import Part
import math

doc = App.newDocument("CustomBallBearing")

# === Parameters ===
inner_diameter = 10.0        # shaft diameter (fixed)
outer_diameter = 70.0        # new outer diameter (scaled)
width = 12.0                 # thickness of bearing stack
num_balls = 14               # more balls for bigger outer diameter

# === Proportional Scaling ===
ring_gap_ratio = 0.1         # % of total width used for clearance
race_thickness = 0.08 * outer_diameter
ball_diameter = (outer_diameter - inner_diameter - 2 * race_thickness) / 4
ball_radius = ball_diameter / 2
race_clearance = ring_gap_ratio * width

# === Outer Race ===
outer_race = Part.makeCylinder(outer_diameter / 2, width)
outer_race_inner = Part.makeCylinder((outer_diameter / 2) - race_thickness, width)
outer_race = outer_race.cut(outer_race_inner)

# === Inner Race ===
inner_race = Part.makeCylinder(inner_diameter / 2 + race_thickness, width)
inner_race_hole = Part.makeCylinder(inner_diameter / 2, width)
inner_race = inner_race.cut(inner_race_hole)

# === Balls ===
balls = []
angle_step = 360 / num_balls
ring_radius = (outer_diameter + inner_diameter) / 4  # middle between OD and ID

for i in range(num_balls):
    angle = math.radians(i * angle_step)
    x = ring_radius * math.cos(angle)
    y = ring_radius * math.sin(angle)
    ball = Part.makeSphere(ball_radius, App.Vector(x, y, width / 2))
    balls.append(ball)

balls_union = balls[0]
for b in balls[1:]:
    balls_union = balls_union.fuse(b)

# === Seals ===
seal_thickness = 0.5
seal_outer = Part.makeCylinder(outer_diameter / 2, seal_thickness)
seal_inner = Part.makeCylinder(inner_diameter / 2, seal_thickness)
seal_face = seal_outer.cut(seal_inner)

front_seal = seal_face.copy()
back_seal = seal_face.copy()
back_seal.translate(App.Vector(0, 0, width - seal_thickness))

# === Assemble Bearing ===
bearing = outer_race.fuse(inner_race)
bearing = bearing.fuse(balls_union)
bearing = bearing.fuse(front_seal)
bearing = bearing.fuse(back_seal)

Part.show(bearing)
doc.recompute()
