import FreeCAD as App
import Part
import math

doc = App.newDocument("BallBearing")

# === Parameters for 6mm OD Ball Bearing ===
outer_diameter = 6.0       # mm
inner_diameter = 2.0       # mm (ideal for very small escape gear axle)
width = 2.5                # mm (compact profile)
ball_diameter = 1.0        # mm (smallest reasonable at this scale)
num_balls = 6              # good compromise between spacing and function




# Derived
race_thickness = 2.0   # how thick the outer and inner rings are
ball_radius = ball_diameter / 2
race_clearance = 0.3   # gap between ball and races

# === Outer Race ===
outer_race = Part.makeCylinder(outer_diameter / 2, width)
outer_race_inner = Part.makeCylinder((outer_diameter / 2) - race_thickness, width)
outer_race = outer_race.cut(outer_race_inner)

# === Inner Race ===
inner_race = Part.makeCylinder(inner_diameter / 2 + race_thickness, width)
inner_race_hole = Part.makeCylinder(inner_diameter / 2, width)
inner_race = inner_race.cut(inner_race_hole)

# === Balls ===
balls = []
angle_step = 360 / num_balls
ring_radius = (outer_diameter + inner_diameter) / 4  # center of ball ring

for i in range(num_balls):
    angle = math.radians(i * angle_step)
    x = ring_radius * math.cos(angle)
    y = ring_radius * math.sin(angle)
    ball = Part.makeSphere(ball_radius, App.Vector(x, y, width / 2))
    balls.append(ball)

# Union all balls into one shape
balls_union = balls[0]
for b in balls[1:]:
    balls_union = balls_union.fuse(b)

# === Seals === (Front and back thin faces)
seal_thickness = 0.5
seal_outer = Part.makeCylinder(outer_diameter / 2, seal_thickness)
seal_inner = Part.makeCylinder(inner_diameter / 2, seal_thickness)
seal_face = seal_outer.cut(seal_inner)

front_seal = seal_face.copy()
back_seal = seal_face.copy()
back_seal.translate(App.Vector(0, 0, width - seal_thickness))

# === Final Assembly ===
bearing = outer_race.fuse(inner_race)
bearing = bearing.fuse(balls_union)
bearing = bearing.fuse(front_seal)
bearing = bearing.fuse(back_seal)

# Show in FreeCAD
Part.show(bearing)
doc.recompute()
