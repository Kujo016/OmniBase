# material_mass_calculator.py

# Approximate densities in kg/m³
density_table = {
    "steel": 7850,
    "wrought_iron": 7700,
    "cast_iron": 7200,
    "aluminum": 2700,
    "brass": 8500,
    "copper": 8960,
    "bronze": 8800,
    "wood": 600,          # Maple
    "oak": 750,
    "cedar": 380,
    "leather": 860,       # Average density
    "bone": 1900,
    "ebony": 1200,
    "horn": 1300,
    "ivory": 1800,
}

def calculate_mass(material: str, volume_m3: float) -> float:
    """
    Calculate the mass of a material given its volume.
    :param material: Name of the material (must match keys in density_table).
    :param volume_m3: Volume in cubic meters.
    :return: Mass in kilograms.
    """
    material = material.lower()
    if material not in density_table:
        raise ValueError(f"Material '{material}' not found in density table.")
    density = density_table[material]
    return density * volume_m3

def main():
    print("Available materials:")
    for mat in density_table:
        print(f" - {mat}")
    material = input("Enter the material: ").strip().lower()
    try:
        volume = float(input("Enter volume in cubic meters (m³): "))
        mass = calculate_mass(material, volume)
        print(f"\nEstimated mass of {volume} m³ of {material}: {mass:.5f} kg")
    except ValueError as e:
        print("Error:", e)

if __name__ == "__main__":
    main()
