"""
Gear Train Calculator
---------------------

This script implements the gear‑train sizing method described in the
user‑provided book passage.  It guides the user through setting up
a multi‑stage (compound) gear train for a clock with a configurable
number of axles.  The program asks how many dials (e.g. seconds,
minutes, hours, days) the clock has and the number of ticks per
revolution on each dial.  From these inputs it computes the overall
reduction ratio required to drive the slowest dial from the fastest.

The algorithm then distributes the reduction across a specified
number of axles.  It computes an approximate large “end gear” size
from the ratio and the number of axles using the heuristic from the
book:

    End_Gear = (Total_Ratio / (Axle_Count**2)) / 2

The final follower gear (e) is constrained by a user‑supplied
constant `rf` via the relation e = End_Gear / rf.  Intermediate
driven gears are initially estimated by repeatedly halving the
preceding driven gear.  The program prompts the user to supply the
pinion tooth counts for all axles except the first and last (the
first pinion and the final driver).  The first pinion (call it x) and
the second‑to‑last driven gear are treated as unknowns which must
satisfy the exact reduction ratio.  Given a candidate value of x,
the program solves for the penultimate driven gear using the derived
formula

    gear[n-2] = ratio * x * pinion[n-2] / (gear[0] * K1)

where K1 is the product of all known gear‑over‑pinion ratios except
for the first and the unknown penultimate stage.  The solver scans a
range of reasonable pinion counts (typically 8–12 teeth) for x and
reports solutions where the computed driven gear is an integer.

Once a viable combination is found, the program prints the gear train
in the form `(N_driven_end/N_driver_end) * ... = Total_Ratio` and
displays the tooth counts for each gear and pinion.  The user can
iterate through multiple x values to explore alternative designs.

Note: This script assumes spur gears with integer tooth counts and
uses a simplified heuristic for sizing intermediate driven gears.  In
practice, designers may need to adjust tooth counts to meet physical
constraints such as centre distances or to avoid fractional teeth.
"""

from __future__ import annotations

import math
from typing import List, Tuple


def get_int(prompt: str, default: int | None = None, minimum: int | None = None) -> int:
    """Prompt the user for an integer with optional default and minimum value.

    If the user enters nothing and a default is provided, the default
    is returned.  If a minimum is provided, the input must be at least
    that value.
    """
    while True:
        if default is not None:
            inp = input(f"{prompt} [default {default}]: ").strip()
            if not inp:
                return default
        else:
            inp = input(f"{prompt}: ").strip()

        try:
            val = int(inp)
        except ValueError:
            print("Please enter a valid integer.")
            continue
        if minimum is not None and val < minimum:
            print(f"Value must be at least {minimum}.")
            continue
        return val


def get_float(prompt: str, default: float | None = None, minimum: float | None = None) -> float:
    """Prompt the user for a floating‑point number with optional default and minimum value."""
    while True:
        if default is not None:
            inp = input(f"{prompt} [default {default}]: ").strip()
            if not inp:
                return default
        else:
            inp = input(f"{prompt}: ").strip()

        try:
            val = float(inp)
        except ValueError:
            print("Please enter a valid number.")
            continue
        if minimum is not None and val < minimum:
            print(f"Value must be at least {minimum}.")
            continue
        return val


def collect_ticks(num_dials: int) -> List[int]:
    """Collect the number of ticks per dial from the user."""
    ticks: List[int] = []
    for i in range(num_dials):
        t = get_int(f"Enter the number of ticks for dial {i+1}", minimum=1)
        ticks.append(t)
    return ticks


def calculate_total_ratio(ticks: List[int]) -> int:
    """Compute total gear reduction from fastest to slowest dial.

    If 2 dials: just divide ticks[1] / ticks[0]
    If more: chain multiply ticks[1:] and divide by ticks[0]
    """
    if len(ticks) < 2:
        raise ValueError("At least two dials are required to compute a ratio.")
    if len(ticks) == 2:
        return ticks[1] // ticks[0]
    # For 3 or more, chain as before
    product = 1
    for t in ticks[1:]:
        product *= t
    return product // ticks[0]



def compute_end_gear(total_ratio: int, axles: int) -> float:
    """Compute end gear with hybrid fallback: quadratic if axles ≥ 3, linear if fewer."""
    if axles >= 3:
        end_gear = total_ratio / (2 * axles ** 2)
    else:
        end_gear = total_ratio / (3 * axles)
    return max(end_gear, 60)  # Enforce a reasonable minimum size



def compute_intermediate_gears(end_gear: float, stages: int) -> List[float]:
    """Generate a list of driven gear estimates by halving.

    This helper constructs a list of length ``stages`` containing
    approximate sizes for the driven gears before the final follower.
    The first entry is the largest driven gear (``end_gear``) and
    successive entries are its halves.  The last entry is a duplicate
    placeholder for the final follower which will be replaced by
    ``e`` in the calling code.  For example, with ``end_gear = 360``
    and ``stages = 4``, the function returns ``[360, 180, 90, 360]``.
    The caller replaces the last entry with the final follower size.
    """
    gears: List[float] = []
    # For n stages, generate n-1 halved gears plus the end gear as the last placeholder.
    for i in range(stages - 1):
        gears.append(end_gear / (2 ** i))
    # Append the end_gear again for the placeholder; this will be replaced with e later
    gears.append(end_gear)
    return gears


def build_formula_string(gear_sizes: List[int], pinions: List[int], ratio: float) -> str:
    """Return a human‑readable formula representing the gear train.

    The formula has the form:

        (gear[0]/pinion[0]) * (gear[1]/pinion[1]) * ... = ratio

    The inputs must have the same length.  The gear_sizes include the
    driven gears for each axle; pinions are the corresponding drivers.
    """
    terms = []
    for g, p in zip(gear_sizes, pinions):
        terms.append(f"({g}/{p})")
    return " * ".join(terms) + f" = {ratio}"


def find_candidate_gears(
    ratio: int,
    end_gear: float,
    e_constant: float,
    axle_count: int,
    user_pinions: List[int],
    driver_main: int,
    x_range: Tuple[int, int] = (8, 20),
) -> List[Tuple[int, int, List[int], List[int]]]:
    """Search for integer gear combinations matching the desired ratio.

    Parameters
    ----------
    ratio : int
        The total reduction ratio required (e.g. 11520).
    end_gear : float
        The initial estimate of the largest driven gear.
    e_constant : float
        Constant used to compute the final follower gear (e = end_gear / e_constant).
    axle_count : int
        Number of axles in the gear train.
    user_pinions : list of int
        The tooth counts for intermediate pinions (excluding the first pinion and last driver).
        Length must be axle_count - 2.
    driver_main : int
        Tooth count of the final (fastest) driver pinion.
    x_range : tuple of int
        Inclusive range of values to try for the first pinion tooth count (x).

    Returns
    -------
    list of tuples
        Each tuple contains (x, gear_n2_int, gear_sizes_int, pinion_sizes).
        gear_sizes_int is the list of integer gear sizes (driven) from first to last.
    """
    # Determine number of gear stages: there will be one driven gear per axle
    stages = axle_count
    # Compute final follower gear "e" using the user‑specified constant
    e = end_gear / e_constant
    # Compute preliminary intermediate driven gears by halving
    # There are axle_count gear sizes total, last one is e, first is end_gear.
    # Compute gears for indices 0..axle_count-3 by halving; leave gear[n-2] to solve later.
    # Example for n=4: gear_indices: 0:end_gear, 1:(end_gear/2), 2:unknown, 3:e
    intermediate_gears = compute_intermediate_gears(end_gear, stages)
    # Replace the last gear with e
    intermediate_gears[-1] = e
    results: List[Tuple[int, int, List[int], List[int]]] = []
    # Build pinion array template: length equals axle_count
    # pinion[0]=x (to be determined), pinion[1..n-2]=user_pinions, pinion[n-1]=driver_main
    pinion_template = [None] + user_pinions + [driver_main]
    for x in range(x_range[0], x_range[1] + 1):
        # Copy gear list so we can modify it
        gears = intermediate_gears.copy()
        # Assign candidate first pinion
        pinions = pinion_template.copy()
        pinions[0] = x
        # Compute K1: product of gear[i]/pinion[i] for i from 1 to n-3 and for last gear (n-1)
        K1 = 1.0
        # For i = 1 .. n-3
        for i in range(1, stages - 2):
            g = gears[i]
            p = pinions[i]
            K1 *= (g / p)
        # Multiply by last stage (n-1)
        g_last = gears[-1]
        p_last = pinions[-1]
        K1 *= (g_last / p_last)
        # Solve for gear[n-2] (penultimate driven gear)
        # ratio = (gear[0]/x) * K1 * (gear[n-2]/pinion[n-2])
        # => gear[n-2] = ratio * x * pinion[n-2] / (gear[0] * K1)
        p_penult = pinions[-2]
        gear0 = gears[0]
        gear_n2 = ratio * x * p_penult / (gear0 * K1)
        # Check if gear_n2 is close to integer and greater than zero
        gear_n2_int = int(round(gear_n2))
        if gear_n2_int <= 0:
            continue
        # Verify that the computed value is close to an integer within tolerance
        if abs(gear_n2 - gear_n2_int) > 1e-6:
            continue
        # Accept solution; update gears list
        gears[-2] = float(gear_n2_int)
        # Convert gear sizes to ints for final reporting
        gear_sizes_int = [int(round(g)) for g in gears]
        # Ensure no gear is smaller than its corresponding pinion
        valid = True
        for g, p in zip(gear_sizes_int, pinions):
            if g <= p:
                valid = False
                break
        if not valid:
            continue
        results.append((x, gear_n2_int, gear_sizes_int, pinions.copy()))
    return results

def frange(start: float, stop: float, step: float) -> List[float]:
    """Generate a list of floats from start to stop with step size."""
    values = []
    while start <= stop:
        values.append(start)
        start += step
    return values


def main() -> None:
    print("\n=== Gear Train Calculator ===\n")
    # Step 1: ask for number of axles
    axle_count = get_int("Enter the number of axles", minimum=2)
    # Step 2: ask for number of dials and ticks per dial
    dial_count = get_int("Enter the number of dials (e.g. seconds, minutes, hours)", minimum=2)
    ticks = collect_ticks(dial_count)
    # Compute total gear reduction (ratio)
    total_ratio = calculate_total_ratio(ticks)
    print(f"Total reduction ratio required: {total_ratio}:1")
    # Step 3: ask for main driver pinion tooth count
    driver_main = get_int("Enter the tooth count of the final driver pinion", minimum=1)
    # Step 4: ask for the constant used for the final follower gear
    e_const_min = get_float("Enter minimum e constant", default=4.0, minimum=0.1)
    e_const_max = get_float("Enter maximum e constant", default=6.0, minimum=e_const_min)

    # Step 5: compute end gear
    end_gear = compute_end_gear(total_ratio, axle_count)
    print(f"Initial estimate for largest driven gear (End_Gear): {end_gear:.3f} teeth")
    # Step 6: ask user for intermediate pinion counts
    if axle_count > 2:
        user_pinions: List[int] = []
        for i in range(1, axle_count - 1):
            p = get_int(f"Enter tooth count for pinion on axle {i+1} (intermediate driver)", minimum=1)
            user_pinions.append(p)
    else:
        user_pinions = []
    # Step 7: ask for range of candidate x values
    print("\nNow searching for valid gear combinations for the first pinion.")
    solutions = []
    while not solutions:
        x_min = get_int("Enter minimum number of teeth to try for the first pinion", default=8, minimum=1)
        x_max = get_int("Enter maximum number of teeth to try for the first pinion", default=20, minimum=x_min)
        for e_const in [round(ec, 2) for ec in list(frange(e_const_min, e_const_max, 0.1))]:
            found = find_candidate_gears(
                total_ratio,
                end_gear,
                e_const,
                axle_count,
                user_pinions,
                driver_main,
                (x_min, x_max)
            )
            if found:
                print(f"\n✅ Solutions for e_constant = {e_const}")
                solutions.extend(found)

    if not solutions:
        print("No valid gear combinations found. Try another range.\n")

    # Display solutions
    for idx, (x, gear_n2, gear_sizes, pinions) in enumerate(solutions, start=1):
        print(f"\nSolution {idx}:")
        print(f"  First pinion (x): {x} teeth")
        print(f"  Penultimate driven gear: {gear_n2} teeth")
        print(f"  Final driven gear (e): {gear_sizes[-1]} teeth")
        # Full gear train formula
        formula_str = build_formula_string(gear_sizes, pinions, total_ratio)
        print(f"  Gear train: {formula_str}")



if __name__ == "__main__":
    main()