# shaft_diameter_calculator.py

import math

E_table = {
    "steel": 200e9,             # Modern mild steel (~200 GPa)
    "wrought_iron": 190e9,      # Typical for 1800s structural iron
    "cast_iron": 100e9,         # Brittle, less elastic
    "aluminum": 69e9,
    "brass": 100e9,
    "copper": 110e9,            # Annealed copper
    "bronze": 110e9,            # Tin-bronze alloys
    "wood": 11e9,               # Maple
    "oak": 12e9,                # White oak
    "cedar": 6e9,               # Western red
    "leather": 0.01e9,          # Soft, very flexible
    "bone": 13e9,               # Dense bone (used in some fine clocks)
    "ebony": 15e9,              # Dense hardwood, often decorative
    "horn": 3e9,                # Used in inlays or laminated parts
    "ivory": 10e9               # High-quality clock faces or pivots
}

def min_diameter_to_limit_bending(mass_kg, shaft_length_mm, max_deflection_mm, material="steel"):
    g = 9.81  # gravity (m/s^2)
    E = E_table.get(material.lower(), None)
    if E is None:
        raise ValueError(f"Material '{material}' not found in E_table.")
    
    F = mass_kg * g
    L = shaft_length_mm / 1000
    delta = max_deflection_mm / 1000

    numerator = 64 * F * (L**3)
    denominator = 3 * E * delta
    d_min = (numerator / denominator)**(1/4)

    return d_min * 1000  # Return in mm

def main():
    print("Available materials:")
    for mat in E_table:
        print(f" - {mat}")

    material = input("Enter the material: ").strip().lower()

    try:
        mass = float(input("Enter the mass applied at shaft tip (kg): "))
        length = float(input("Enter the shaft length (mm): "))
        deflection = float(input("Enter max allowed deflection at tip (mm): "))
        
        diameter = min_diameter_to_limit_bending(mass, length, deflection, material)
        print(f"\nMinimum required shaft diameter: {diameter:.2f} mm")
    except ValueError as e:
        print("Error:", e)

if __name__ == "__main__":
    main()
