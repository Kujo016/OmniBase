# gear_volume_calculator.py

import math

def calculate_gear_volume(radius_mm: float, thickness_mm: float) -> float:
    """
    Calculate the volume of a gear approximated as a solid cylinder.
    :param radius_mm: Radius in millimeters.
    :param thickness_mm: Thickness in millimeters.
    :return: Volume in cubic meters (m^3).
    """
    radius_m = radius_mm / 1000
    thickness_m = thickness_mm / 1000
    volume_m3 = math.pi * (radius_m ** 2) * thickness_m
    return volume_m3

def main():
    print("Gear Volume Calculator (solid cylinder approximation)")

    try:
        radius_mm = float(input("Enter gear radius in millimeters (mm): "))
        thickness_mm = float(input("Enter gear thickness in millimeters (mm): "))
        
        if radius_mm <= 0 or thickness_mm <= 0:
            raise ValueError("Radius and thickness must be positive numbers.")

        volume_m3 = calculate_gear_volume(radius_mm, thickness_mm)
        print(f"\nEstimated volume of the gear:")
        print(f" - {volume_m3:.6f} m^3")
        print(f" - {volume_m3 * 1_000_000:.2f} mm^3")
        print(f" - {volume_m3 * 1_000:.2f} liters (L)")

    except ValueError as e:
        print("Error:", e)

if __name__ == "__main__":
    main()
