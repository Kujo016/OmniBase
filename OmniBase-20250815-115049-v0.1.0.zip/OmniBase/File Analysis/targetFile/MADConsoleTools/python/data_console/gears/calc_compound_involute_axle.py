# streamlined_gear_calculator.py

import math

# --- Density Table (kg/m^3) ---
density_table = {
    "steel": 7850,
    "wrought_iron": 7700,
    "cast_iron": 7200,
    "aluminum": 2700,
    "brass": 8500,
    "copper": 8960,
    "bronze": 8800,
    "wood": 600,
    "oak": 750,
    "cedar": 380,
    "leather": 860,
    "bone": 1900,
    "ebony": 1200,
    "horn": 1300,
    "ivory": 1800,
}

# --- Young's Modulus Table (Pa) ---
E_table = {
    "steel": 200e9,
    "wrought_iron": 190e9,
    "cast_iron": 100e9,
    "aluminum": 69e9,
    "brass": 100e9,
    "copper": 110e9,
    "bronze": 110e9,
    "wood": 11e9,
    "oak": 12e9,
    "cedar": 6e9,
    "leather": 0.01e9,
    "bone": 13e9,
    "ebony": 15e9,
    "horn": 3e9,
    "ivory": 10e9
}

# --- Volume ---
def calculate_gear_volume(radius_mm: float, thickness_mm: float) -> float:
    radius_m = radius_mm / 1000
    thickness_m = thickness_mm / 1000
    return math.pi * (radius_m ** 2) * thickness_m  # m^3

# --- Mass ---
def calculate_mass(material: str, volume_m3: float) -> float:
    material = material.lower()
    if material not in density_table:
        raise ValueError(f"Material '{material}' not found.")
    return density_table[material] * volume_m3  # kg

# --- Shaft Diameter ---
def min_diameter_to_limit_bending(mass_kg, shaft_length_mm, max_deflection_mm, material="steel") -> float:
    g = 9.81
    E = E_table.get(material.lower())
    if E is None:
        raise ValueError(f"Material '{material}' not found.")
    F = mass_kg * g
    L = shaft_length_mm / 1000
    delta = max_deflection_mm / 1000
    d_min = ((64 * F * (L**3)) / (3 * E * delta))**0.25
    return d_min * 1000  # mm

# --- Main ---
def main():
    print("=== Compound Gear Axle Calculator ===")

    # Input for Gear 1
    print("\n--- Gear 1 ---")
    radius1 = float(input("Enter radius of gear 1 (mm): "))
    thickness1 = float(input("Enter thickness of gear 1 (mm): "))

    # Input for Gear 2
    print("\n--- Gear 2 ---")
    radius2 = float(input("Enter radius of gear 2 (mm): "))
    thickness2 = float(input("Enter thickness of gear 2 (mm): "))

    if radius1 <= 0 or thickness1 <= 0 or radius2 <= 0 or thickness2 <= 0:
        print("Error: All dimensions must be positive.")
        return

    # Input material
    print("\nAvailable materials:")
    for mat in density_table:
        print(f" - {mat}")
    material = input("Enter material for both gears: ").strip().lower()

    if material not in density_table or material not in E_table:
        print("Error: Material not found in both tables.")
        return

    # Calculate volumes and total volume
    vol1 = calculate_gear_volume(radius1, thickness1)
    vol2 = calculate_gear_volume(radius2, thickness2)
    total_vol = vol1 + vol2

    # Calculate total mass
    total_mass = calculate_mass(material, total_vol)

    # Output
    print(f"\nTotal Volume:")
    print(f" - {total_vol:.6f} m^3")
    print(f" - {total_vol * 1_000_000:.2f} mm^3")
    print(f" - {total_vol * 1000:.2f} liters")

    print(f"\nEstimated total mass of both gears:")
    print(f" - {total_mass:.3f} kg")

    # Shaft inputs
    shaft_length_mm = float(input("\nEnter shaft length (mm): "))
    max_deflection_mm = float(input("Enter max deflection at tip (mm): "))

    # Shaft size calculation
    shaft_dia = min_diameter_to_limit_bending(
        total_mass, shaft_length_mm, max_deflection_mm, material
    )
    print(f"\nRecommended minimum shaft diameter to limit bending: {shaft_dia:.2f} mm")


if __name__ == "__main__":
    main()
