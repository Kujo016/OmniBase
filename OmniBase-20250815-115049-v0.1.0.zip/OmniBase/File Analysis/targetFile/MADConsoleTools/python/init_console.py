import sys
import os
from pathlib import Path
import FreeCAD as App
import FreeCADGui as Gui

try:
    # Normal script execution
    current_file = Path(__file__).resolve()
except NameError:
    # Inside exec() or FreeCAD; __file__ is not defined
    import inspect
    current_file = Path(inspect.stack()[0].filename).resolve()

tools_dir = current_file.parent
if str(tools_dir) not in sys.path:
    sys.path.insert(0, str(tools_dir))

print(f"[DEBUG] tools_dir = {tools_dir}")
print(f"[DEBUG] sys.path = {sys.path}")

from data_console.desk import journal, cad


EXCLUDED_DIRS = {"__pycache__", "data_console.desk"}
EXCLUDED_FILES = {"__init__.py"}

def list_python_scripts(base_dir: str):
    base_path = Path(base_dir)
    script_paths = []

    for root, dirs, files in os.walk(base_path):
        # Modify dirs in-place to skip excluded directories
        dirs[:] = [d for d in dirs if d not in EXCLUDED_DIRS]

        for file in files:
            if file.endswith(".py") and file not in EXCLUDED_FILES:
                full_path = Path(root) / file
                script_paths.append(full_path.resolve())

    return script_paths



def main():
    print("""============== PYTHON CONSOLE ==============
    Options:
        - Type number to run script
        - 'j' = open journal
        - 'q' = quit
        - 'h' = help
    ============================================
    """)
    while True:
        base_dir = tools_dir / "data_console"
        scripts = list_python_scripts(tools_dir / "data_console")


        if not scripts:
            print("No Python scripts found.")
            return

        

        for idx, script in enumerate(scripts):
            print(f"[{idx}] {script}")

        choice = input("\nEnter your choice: ").strip().lower()

        if choice == 'q':
            print("Exiting...")
            break
        elif choice == 'j':
            journal.open_journal()
            continue
        elif choice.startswith('cad'):
            path_arg = None
            if ' ' in choice:
                path_arg = choice.split(' ', 1)[1].strip().strip('"')
            cad.load_doc(path_arg)
        elif choice == 'xport':
            try:
                # Dynamically construct relative path import
                tool_path = Path(__file__).resolve().parent / "data_console" / "export" / "xport_parts_bodies.py"
                if not tool_path.exists():
                    print(f"xport_parts_bodies.py not found at: {tool_path}")
                else:
                    import runpy
                    runpy.run_path(str(tool_path), run_name="__main__")
            except Exception as e:
                print(f"Failed to run xport script: {e}")
            continue

        elif choice == 'h':
            print("""
        === Beginner Help ===
        - Type number to run script
        - 'cad' = load FreeCAD file
        - 'xport' = export parts and bodies from active project
        - 'j' = open journal
        - 'q' = quit
        - 'h' = help
        """)
            continue    

        try:
            index = int(choice)
            if 0 <= index < len(scripts):
                selected_script = scripts[index]
                print(f"\nYou selected: {selected_script}")
                try:
                    import runpy
                    module_globals = runpy.run_path(str(selected_script))
                    if "main_entry" in module_globals:
                        module_globals["main_entry"]()
                except Exception as e:
                    print(f"Error running script: {e}")
            else:
                print("Invalid selection.")
        except ValueError:
            print("Please enter a valid number or command.")

# run_madcon_console.py
import subprocess
import os
from pathlib import Path
import __Init__

def launch_console():
    path = Path(__Init__.__file__).parent / "Tools" / "init_console.py"
    if not path.exists():
        print(f"Console script not found: {path}")
        return

    subprocess.Popen(["python", str(path)], creationflags=subprocess.CREATE_NEW_CONSOLE if os.name == "nt" else 0)


if __name__ == "__main__":
    main()
