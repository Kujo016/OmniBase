# reports_index.py
from __future__ import annotations
from pathlib import Path
import json, re
from typing import List, Dict, Any, Optional

# ---------- loaders (your idea, tightened a hair) ----------
def load_directory_structure(txt_path: Path) -> List[Dict[str, Any]]:
    """
    Parse 'directory_structure_full.txt' into a flat list of files with pseudo-paths
    reconstructed from indentation. Each record: {"path","size_bytes"}.
    """
    lines = txt_path.read_text(encoding="utf-8", errors="ignore").splitlines()
    stack, records = [], []
    indent_re = re.compile(r"^(?P<indent>\s*)(?P<name>.+?)(?: - (?P<size>\d+)\s*bytes)?$")

    for raw in lines:
        m = indent_re.match(raw)
        if not m:
            continue
        indent = len(m.group("indent"))
        name   = m.group("name").rstrip("/").strip()
        size   = int(m.group("size")) if m.group("size") else None

        level = indent // 4
        if level > len(stack):
            level = len(stack)
        stack = stack[:level]
        stack.append(name)

        if size is not None:  # treat as file
            records.append({"path": "/".join(stack), "size_bytes": size})

    return records

def load_code_summary(json_path: Path) -> Dict[str, Dict[str, Any]]:
    """
    Parse 'code_summary_results.json' into a dict:
      key -> {text: ..., meta: {...}}
    Survives list/dict shapes and picks common fields.
    """
    data = json.loads(json_path.read_text(encoding="utf-8", errors="ignore"))
    out: Dict[str, Dict[str, Any]] = {}

    if isinstance(data, dict):
        iterable = data.items()
    elif isinstance(data, list):
        iterable = enumerate(data)
    else:
        return out

    TEXT_FIELDS = ("summary","description","content","text","notes")
    NAME_FIELDS = ("path","file","name","key","id")

    for k, v in iterable:
        if isinstance(v, dict):
            # text
            text = None
            for f in TEXT_FIELDS:
                t = v.get(f)
                if isinstance(t, str) and t.strip():
                    text = t.strip()
                    break
            if text is None:
                text = json.dumps(v, ensure_ascii=False)[:20000]
            # key
            key = None
            for f in NAME_FIELDS:
                s = v.get(f)
                if isinstance(s, str) and s.strip():
                    key = s.strip()
                    break
            if key is None:
                key = str(k)
            # meta = everything else
            meta = {kk: vv for kk, vv in v.items() if kk not in TEXT_FIELDS}
            out[key] = {"text": text, "meta": meta}
        else:
            out[str(k)] = {"text": json.dumps(v, ensure_ascii=False), "meta": {}}

    return out

def load_reports(base_dir: Path):
    """
    Returns:
      files_index: list of {"path","size_bytes"}
      code_index : dict key -> {"text","meta"}
    Looks in <base_dir>/reports/.
    """
    reports = Path(base_dir) / "reports"
    txt  = reports / "directory_structure_full.txt"
    jsn  = reports / "code_summary_results.json"
    files_index = load_directory_structure(txt) if txt.exists() else []
    code_index  = load_code_summary(jsn) if jsn.exists() else {}
    return files_index, code_index

# ---------- context builder ----------
def _default_project_dir() -> Optional[Path]:
    # Prefer active FreeCAD project folder
    try:
        import FreeCAD as App
        doc = getattr(App, "ActiveDocument", None) or App.activeDocument()
        fpath = getattr(doc, "FileName", "") or ""
        if fpath:
            return Path(fpath).resolve().parent
    except Exception:
        pass
    # Then env
    env = Path((__import__("os").environ.get("PROJECT_DIR") or "")).expanduser()
    if f"{env}".strip() and env.exists():
        return env
    # Finally CWD
    return Path.cwd()

def _shorten(s: str, limit: int) -> str:
    if len(s) <= limit:
        return s
    head = s[: limit - 120].rstrip()
    return f"{head}\n\n… [truncated, {len(s) - len(head)} more chars]"

def build_llm_messages(
    project_dir: Optional[Path] = None,
    query_tags: Optional[List[str]] = None,
    *,
    max_json_chars: int = 8000,
    max_txt_chars: int  = 8000,
    max_items_per_tag: int = 8
) -> List[Dict[str, str]]:
    """
    Turn the reports into chat messages (llama.cpp-style):
      [{"role":"system","content":...}, {"role":"system","content":...}, ...]
    - Filters code summaries by query_tags when present (case-insensitive substring match).
    - Always includes a compact file inventory.
    """
    pdir = Path(project_dir) if project_dir else _default_project_dir()
    files_index, code_index = load_reports(pdir)

    # 1) Inventory (small + deterministic)
    inv_lines = []
    total_bytes = 0
    for rec in files_index[:4000]:  # cap just in case
        total_bytes += int(rec.get("size_bytes") or 0)
        inv_lines.append(f"{rec['path']}  ({rec.get('size_bytes','?')} bytes)")
    inventory = "\n".join(inv_lines)
    inv_msg = {
        "role": "system",
        "content": _shorten(
            f"[project]\nroot: {pdir}\nfiles_in_reports_index: {len(files_index)}\ntotal_bytes_indexed: {total_bytes}\n\n[inventory excerpt]\n{inventory}",
            max_txt_chars,
        )
    }

    # 2) Code summaries, optionally filtered by tags
    tags = [t.lower() for t in (query_tags or []) if t and t.strip()]
    picked = []

    if tags:
        for k, v in code_index.items():
            blob = (v.get("text") or "")[:20000]
            hay = (k + " " + blob).lower()
            score = sum(hay.count(t) for t in tags)
            if score:
                picked.append((score, k, blob))
        picked.sort(key=lambda x: x[0], reverse=True)
    else:
        for k, v in code_index.items():
            picked.append((1, k, (v.get("text") or "")[:20000]))

    # squash into a single message (keeps llama-cpp fast) but keep headings
    lines = []
    for _, k, blob in picked[:max_items_per_tag]:
        lines.append(f"--- {k} ---\n{_shorten(blob, max_json_chars)}\n")
    code_msg = {
        "role": "system",
        "content": _shorten(
            "[reports: code_summary_results]\n" + ("\n".join(lines) if lines else "(no matching items)"),
            max_json_chars + 1024
        )
    }

    # 3) directory_structure_full excerpt (raw text is often useful for path hints)
    try:
        txt = (Path(pdir)/"reports"/"directory_structure_full.txt").read_text(encoding="utf-8", errors="ignore")
    except Exception:
        txt = ""
    txt_msg = {
        "role": "system",
        "content": _shorten("[reports: directory_structure_full]\n" + txt, max_txt_chars)
    }

    return [inv_msg, code_msg, txt_msg]
