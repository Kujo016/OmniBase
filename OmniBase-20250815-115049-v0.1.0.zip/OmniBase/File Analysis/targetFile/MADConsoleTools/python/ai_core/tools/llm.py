# ai_core/tools/llm.py
import os
from pathlib import Path
from typing import Dict, Any, List, Optional
import json
import time

from .reports_index import build_llm_messages

#Constants
# General performance knobs
N_THREADS     = int(os.environ.get("N_THREADS", str(os.cpu_count() or 6)))
N_BATCH       = int(os.environ.get("N_BATCH", "256"))   # safe for 7B on modest VRAM
MAIN_GPU      = int(os.environ.get("MAIN_GPU", "0"))
TENSOR_SPLIT  = os.environ.get("TENSOR_SPLIT", "")      # e.g. "0.7,0.3" for multi-GPU

# Per-model GPU layer overrides (set via env if you want exact control)
NGPU_TINY     = os.environ.get("NGPU_TINY")      # e.g. "999" or "0"
NGPU_WRITER   = os.environ.get("NGPU_WRITER")    # for mistral7b
NGPU_CODE     = os.environ.get("NGPU_CODE")      # for codellama
NGPU_EXPERT   = os.environ.get("NGPU_EXPERT")    # for expert13b


CHAT_FMT_TINY = os.environ.get("CHAT_FMT_TINY", "")         # "", "llama-3", "chatml", "llama-2", "mistral-instruct", ...
CHAT_FMT_MISTRAL = os.environ.get("CHAT_FMT_MISTRAL", "")
CHAT_FMT_CODE = os.environ.get("CHAT_FMT_CODE", "")
CHAT_FMT_EXPERT = os.environ.get("CHAT_FMT_EXPERT", "")

N_CTX_TINY = int(os.environ.get("N_CTX_TINY", "2048"))      # match train ctx for tiny


#Helpers
import re
def _looks_like_freecad_python(src: str) -> bool:
    return bool(re.search(r"\bimport\s+FreeCAD\b|\bApp\.newDocument\b|\baddObject\(", src))

def _freecad_doc_name():
    try:
        import FreeCAD as App
        doc = getattr(App, "ActiveDocument", None) or App.activeDocument()
        if doc and getattr(doc, "Label", ""):
            return str(doc.Label)
    except Exception:
        pass
    return ""



def _gather_evidence(cognition: Dict[str, Any]) -> Dict[str, Any]:
    hints = set(cognition.get("tool_hints") or [])
    evidence: Dict[str, Any] = {}

    # CAD evidence (existing)
    if ("cad.context" in hints) or ("cad_snapshot" in hints):
        try:
            from ai_core.tools.cad_context import cad_snapshot
            evidence["cad.snapshot"] = cad_snapshot("")
        except Exception as e:
            evidence["cad.snapshot"] = {"ok": False, "error": str(e)}

    if "cad.selection" in hints:
        try:
            from ai_core.tools.cad_context import cad_selection
            evidence["cad.selection"] = cad_selection("")
        except Exception as e:
            evidence["cad.selection"] = {"ok": False, "error": str(e)}

            
    if "scan.project" in hints:
        pdir = cognition.get("scan_project_dir")
        try:
            p = Path(pdir) if pdir else (_extract_scan_dir(cognition.get("summary","")) or Path.cwd())
            evidence["scan.project"] = scan_project(p)
            name_from_fc = _freecad_doc_name()
            if name_from_fc:
                evidence["project_name"] = name_from_fc
            elif "project_name" not in evidence:
                # fall back to folder name from the scan
                evidence["project_name"] = evidence.get("scan.project", {}).get("project_name", "")
        except Exception as e:
            evidence["scan.project"] = {"ok": False, "error": str(e), "project_dir": pdir or ""}
    

    return evidence

def _infer_project_name(evidence: Dict[str, Any]) -> str:
    scan = evidence.get("scan.project") or {}
    # prefer explicit parse result
    if scan.get("first_fcstd"):
        return str(scan["first_fcstd"])
    # then any JSON-extracted name
    try:
        js = scan.get("code_summary_json")
        if isinstance(js, str) and '"project_name"' in js:
            import re as _re
            m = _re.search(r'"project_name"\s*:\s*"([^"]+)"', js)
            if m:
                return m.group(1).strip()
    except Exception:
        pass
    pdir = scan.get("project_dir")
    return Path(pdir).name if pdir else ""


def _freecad_project_dir():
    """
    Returns Path to the folder containing the active FreeCAD document (.FCStd).
    If no active/saved document, returns None.
    """
    try:
        import FreeCAD as App  # FreeCAD Python API
    except Exception:
        return None

    try:
        doc = getattr(App, "ActiveDocument", None) or App.activeDocument()
    except Exception:
        doc = None

    if not doc:
        return None

    # FileName is empty for unsaved documents
    fpath = getattr(doc, "FileName", "") or ""
    if not fpath:
        return None

    try:
        p = Path(fpath).resolve()
        return p.parent
    except Exception:
        return None


# --- Context/command helpers -------------------------------------------------
from collections import Counter

# Accept many variants: "scan project", "scan my file(s)", "scan folder/dir/directory"
_SCAN_RE = re.compile(
    r"\bscan\b\s+(?:project|files?|file\s*tree|folder|dir(?:ectory)?|this\s+(?:folder|dir(?:ectory)?))"
    r"(?:\s+[\"']?(?P<path>[^\"']+)[\"']?)?",
    re.IGNORECASE
)




def _extract_scan_dir(user_text: str) -> Optional[Path]:
    m = _SCAN_RE.search(user_text or "")
    if not m:
        return None  # <-- important: no command → no path here

    raw = (m.group("path") or "").strip()
    if raw:
        return Path(raw).expanduser().resolve()

    # No explicit path in the command: prefer the active FreeCAD doc folder
    fc_dir = _freecad_project_dir()
    if fc_dir:
        return fc_dir

    env = os.environ.get("PROJECT_DIR")
    if env:
        return Path(env).expanduser().resolve()

    # Final fallback if user explicitly said "scan ..." but nothing else available
    return Path.cwd()


def _read_text_head_tail(p: Path, head_lines=40, tail_lines=40, max_chars=4000) -> str:
    try:
        with p.open("r", encoding="utf-8", errors="ignore") as f:
            lines = f.readlines()
        head = "".join(lines[:head_lines])
        tail = "".join(lines[-tail_lines:]) if len(lines) > head_lines else ""
        clip = (head + ("\n...\n" if tail else "") + tail)
        return clip[:max_chars]
    except Exception as e:
        return f"[scan] Failed to read {p}: {e}"

def _read_json_summary(p: Path, max_keys=50, max_chars=4000) -> str:
    try:
        with p.open("r", encoding="utf-8", errors="ignore") as f:
            data = json.load(f)
        # shallow summary (keys + simple counts)
        if isinstance(data, dict):
            keys = list(data.keys())[:max_keys]
            meta = {"type": "dict", "n_keys": len(data), "sample_keys": keys}
            s = json.dumps(meta, ensure_ascii=False, indent=2)
        elif isinstance(data, list):
            meta = {"type": "list", "n_items": len(data)}
            s = json.dumps(meta, ensure_ascii=False, indent=2)
        else:
            s = json.dumps({"type": type(data).__name__}, ensure_ascii=False, indent=2)
        return s[:max_chars]
    except Exception as e:
        return f"[scan] Failed to parse {p}: {e}"

def scan_project(project_dir: Path) -> Dict[str, Any]:
    project_dir = Path(project_dir)
    reports = project_dir / "reports"

    js = reports / "code_summary_results.json"
    tx = reports / "directory_structure_full.txt"

    js_sum = _read_json_summary(js) if js.exists() else f"[scan] Missing {js}"
    tx_sum = _read_text_head_tail(tx) if tx.exists() else f"[scan] Missing {tx}"

    stats = {}
    first_fcstd_stem = None
    try:
        if tx.exists():
            exts = Counter()
            files = 0
            for raw in tx.open("r", encoding="utf-8", errors="ignore"):
                line = raw.strip()
                # crude "file-looking" heuristic
                if "." in line and not line.endswith("."):
                    files += 1
                    # detect extensions and first FCStd
                    low = line.lower()
                    if ".fcstd" in low and first_fcstd_stem is None:
                        # pull the actual filename portion, then stem
                        fname = line.split("/")[-1].split("\\")[-1].strip()
                        if fname.lower().endswith(".fcstd"):
                            first_fcstd_stem = Path(fname).stem
                    ext = ("." + line.split(".")[-1].lower()).strip()
                    if len(ext) <= 8:
                        exts[ext] += 1
            stats = {"estimated_files": files, "top_exts": exts.most_common(10)}
    except Exception:
        pass

    # prefer the first FCStd; fallback to folder name
    project_name = first_fcstd_stem or project_dir.name

    return {
        "ok": True,
        "project_dir": str(project_dir),
        "reports_dir": str(reports),
        "code_summary_json": js_sum,
        "directory_tree_excerpt": tx_sum,
        "stats": stats,
        "project_name": project_name,
        "first_fcstd": first_fcstd_stem or "",
    }





# ----------------------------
# Back-compat single-model bits
# ----------------------------
_llm = None
_model_path_str = None

def _resolve_model_path() -> Path:
    base_dir = Path(__file__).resolve().parent
    # Use the real TinyLlama chat model in RAG/tinyllama
    default = (base_dir / ".." / ".." / ".." / "RAG" / "tinyllama" / "tinyllama-1.1b-chat-v1.0.Q4_K_M.gguf").resolve()
    env = os.environ.get("ANGLER_GGUF") or os.environ.get("TINY_GGUF")
    path = Path(env).resolve() if env else default
    if not path.exists():
        raise FileNotFoundError(f"GGUF not found: {path}")
    return path

def _load_model(context):
    global _llm, _model_path_str
    if _llm is not None:
        return _llm

    _model_path_str = str(_resolve_model_path())
    try:
        from llama_cpp import Llama, llama_cuda_supported  # llama_cpp>=0.2.80 exposes this helper
    except Exception as e:
        raise RuntimeError("llama-cpp-python is not importable or too old. Install a cuBLAS build.") from e

    # Decide GPU automatically, allow override via context or env
    env_force_cpu = os.environ.get("LLM_FORCE_CPU", "").lower() in ("1","true","yes")
    gpu_available = (getattr(context, "gpu_available", False) or llama_cuda_supported()) and not env_force_cpu
    n_gpu_layers  = int(os.environ.get("N_GPU_LAYERS", "999" if gpu_available else "0"))

    n_ctx = int(os.environ.get("N_CTX_TINY", "4096"))  # give the model room; your reports can be big
    chat_fmt = (CHAT_FMT_TINY or "").strip()

    print(f"[LLM] Loading: {_model_path_str} | GPU={gpu_available} n_gpu_layers={n_gpu_layers} n_ctx={n_ctx}")

    _llm = Llama(
        model_path=_model_path_str,
        n_ctx=n_ctx,
        n_gpu_layers=n_gpu_layers,
        n_threads=N_THREADS,
        n_batch=N_BATCH,
        main_gpu=MAIN_GPU,
        tensor_split=TENSOR_SPLIT or None,
        logits_all=False,
        embedding=False,
        verbose=False,
        # nice-to-haves:
        use_mmap=True,
        use_mlock=False,
    )
    if chat_fmt:
        try:
            _llm.set_chat_format(chat_fmt)  # supported in newer builds
        except Exception:
            pass
    return _llm



def _chat_fallback_prompt(system: str, user: str) -> str:
    # Generic template that works with raw completion (no special tokens)
    return f"SYSTEM:\n{system}\n\nUSER:\n{user}\n\nASSISTANT:"

def _scan_direct(user_text: str) -> Optional[Dict[str, Any]]:
    """
    If the user asked to scan (project/files/dir), perform a direct scan and
    return a concise result dict. Returns None if no scan command was found.
    """
    p = _extract_scan_dir(user_text or "")
    if p is None:
        return None
    try:
        out = scan_project(p)
        # Compact textual summary for legacy callers
        stats = out.get("stats", {})
        top_exts = ", ".join(f"{k}:{v}" for k, v in (stats.get("top_exts") or [])[:6])
        summary = (
            f"[SCAN]\n"
            f"project_dir: {out.get('project_dir','')}\n"
            f"reports_dir: {out.get('reports_dir','')}\n"
            f"estimated_files: {stats.get('estimated_files','?')}\n"
            f"top_exts: {top_exts or '(none)'}\n"
            f"code_summary_json: {out.get('code_summary_json','')[:300]}\n"
            f"directory_tree_excerpt:\n{out.get('directory_tree_excerpt','')[:800]}\n"
        )
        return {"text": summary}
    except Exception as e:
        return {"text": f"[SCAN] Failed: {e}"}

# --- inside llm.py ---

def _project_context_messages(prompt: str, context) -> list:
    """
    Opportunistically pull reports context for the model.
    Uses reports_index.build_llm_messages() if available.
    """
    # fast exit: no need to bloat context for “hello”
    must = bool(re.search(r"\b(freecad|kicad|cuda|dll|export|workbench|project)\b", prompt, re.I))
    if not must:
        return []

    tags = []
    for t in ("freecad","kicad","cuda","export","dll","workbench"):
        if re.search(fr"\b{re.escape(t)}\b", prompt, re.I):
            tags.append(t)

    try:
        from reports_index import build_llm_messages
        return build_llm_messages(project_dir=None, query_tags=tags or None)
    except Exception as e:
        # non-fatal
        print(f"[LLM] reports_index skipped: {type(e).__name__}: {e}")
        return []

def _complete(prompt: str, max_tokens: int = 256, temperature: float = 0.3, context=None) -> Dict[str, Any]:
    # scan fast-path still first
    if _SCAN_RE.search(prompt or ""):
        direct = _scan_direct(prompt)
        if direct is not None:
            return direct

    # self-reply path for 'project' (unchanged)
    if re.search(r"\bproject\b", prompt or "", re.IGNORECASE):
        result = _self_reply(prompt, max_rounds=2, context=context)
        return {"text": result.get("final", "").strip() or "[no output]"}

    # ---- NEW: assemble chat messages with reports context ----
    llm = _load_model(context)
    sys_msg = {"role": "system", "content":
        "You are a precise engineering assistant. Be concise; prefer code and commands over prose."}

    ctx_msgs = _project_context_messages(prompt, context)  # <- from reports_index
    user_msg = {"role": "user", "content": prompt}

    chat = [sys_msg] + ctx_msgs + [user_msg]

    try:
        # prefer chat-completions API when available
        out = llm.create_chat_completion(
            messages=chat,
            temperature=temperature,
            max_tokens=max_tokens,
        )
        text = out["choices"][0]["message"]["content"]
        return {"text": text}
    except Exception:
        # fallback to raw completion for older llama-cpp
        full_prompt = _chat_fallback_prompt(sys_msg["content"], "\n\n".join(m["content"] for m in (ctx_msgs+[user_msg])))
        out = llm(full_prompt, max_tokens=max_tokens, temperature=temperature)
        return {"text": out["choices"][0]["text"]}


# ----------------------------------------------------
# New: multi-model registry + staged “self-reply” pipe
# ----------------------------------------------------

# Resolving paths for additional models; override via env:
#   TINY_GGUF, MISTRAL_GGUF, CODE_GGUF, EXPERT13_GGUF
def _resolve_env_or_default(env_key: str, relative_default: Path) -> Path:
    base_dir = Path(__file__).resolve().parent
    default = (base_dir / relative_default).resolve()
    env = os.environ.get(env_key)
    p = Path(env).resolve() if env else default
    if not p.exists():
        raise FileNotFoundError(f"{env_key} GGUF not found: {p}")
    return p

def _load_llama(model_path: Path, context, *, n_ctx=8192, chat_format: Optional[str]=None, prefer_gpu_layers: Optional[int]=999, model_key: str = "GEN"):
    from llama_cpp import Llama
    gpu_ok = bool(getattr(context, "gpu_available", False))

    # Respect per-model env override first
    override = {
        "TINY": NGPU_TINY, "WRITER": NGPU_WRITER, "CODE": NGPU_CODE, "EXPERT": NGPU_EXPERT
    }.get(model_key)
    if override is not None:
        candidates = [int(override)]
    else:
        if not gpu_ok:
            candidates = [0]
        else:
            # Try full offload, then step down to avoid OOM/driver stalls
            candidates = [prefer_gpu_layers, 32, 28, 24, 20, 16, 8, 0]

    chat_fmt = (chat_format or os.environ.get({
        "TINY":"CHAT_FMT_TINY", "WRITER":"CHAT_FMT_MISTRAL", "CODE":"CHAT_FMT_CODE", "EXPERT":"CHAT_FMT_EXPERT"
    }.get(model_key, ""), ""))

    last_err = None
    for layers in candidates:
        try:
            print(f"[LLM] Loading {model_path.name} | key={model_key} GPU={gpu_ok} n_gpu_layers={layers} n_ctx={n_ctx} n_threads={N_THREADS} n_batch={N_BATCH} chat_fmt={chat_fmt or 'auto'}")
            kwargs = dict(
                model_path=str(model_path),
                n_ctx=n_ctx,
                n_gpu_layers=layers,
                n_threads=N_THREADS,
                n_batch=N_BATCH,
                main_gpu=MAIN_GPU,
                logits_all=False,
                embedding=False,
                verbose=False,
            )
            if chat_fmt:
                kwargs["chat_format"] = chat_fmt
            if TENSOR_SPLIT:
                kwargs["tensor_split"] = TENSOR_SPLIT
            return Llama(**kwargs)
        except Exception as e:
            last_err = e
            print(f"[LLM] Retry with fewer GPU layers (was {layers}) due to: {e}")
            continue
    raise last_err


# --- MODEL REGISTRY: update default_rel paths to match RAG/ ---
_MODELS: Dict[str, Any] = {
    "tiny": {
        "inst": None,
        "path_key": "TINY_GGUF",
        "default_rel": Path("..") / ".." / ".." / "RAG" / "tinyllama" / "tinyllama-1.1b-chat-v1.0.Q4_K_M.gguf",
        "n_ctx": N_CTX_TINY,
        "chat_format": (CHAT_FMT_TINY or None),
    },
    "mistral7b": {
        "inst": None,
        "path_key": "MISTRAL_GGUF",
        "default_rel": Path("..") / ".." / ".." / "RAG" / "mistral-7b" / "mistral-7b-instruct-v0.1.Q4_K_M.gguf",
        "n_ctx": 8192,
        "chat_format": (CHAT_FMT_MISTRAL or None),
    },
    "codellama": {
        "inst": None,
        "path_key": "CODE_GGUF",
        "default_rel": Path("..") / ".." / ".." / "RAG" / "codellama-7b" / "codellama-7b-instruct.Q4_K_M.gguf",
        "n_ctx": 8192,
        "chat_format": (CHAT_FMT_CODE or None),
    },
    "expert13b": {
        "inst": None,
        "path_key": "EXPERT13_GGUF",
        "default_rel": Path("..") / ".." / ".." / "RAG" / "codellama-13b" / "codellama-13b-instruct.Q4_K_M.gguf",
        "n_ctx": 8192,
        "chat_format": (CHAT_FMT_EXPERT or None),
    },
    # Optional extra expert you can route to by name
    "noushermes7b": {
        "inst": None,
        "path_key": "NOUSHERMES_GGUF",
        "default_rel": Path("..") / ".." / ".." / "RAG" / "nous-hermes" / "Nous-Hermes-2-Mistral-7B-DPO.Q4_K_M.gguf",
        "n_ctx": 8192,
        "chat_format": (CHAT_FMT_MISTRAL or None),
    },
}

def _get_model(name: str, context):
    spec = _MODELS[name]
    if spec["inst"] is None:
        if name == "tiny" and os.environ.get("ANGLER_GGUF"):
            path = Path(os.environ["ANGLER_GGUF"]).resolve()
            if not path.exists():
                raise FileNotFoundError(f"ANGLER_GGUF not found: {path}")
        else:
            path = _resolve_env_or_default(spec["path_key"], spec["default_rel"])

        # NEW: per-model prefer_gpu_layers + model_key for logging/overrides
        if name == "tiny":
            spec["inst"] = _load_llama(path, context,
                                       n_ctx=spec["n_ctx"],
                                       chat_format=spec["chat_format"],
                                       prefer_gpu_layers=64,
                                       model_key="TINY")
        elif name == "mistral7b":
            spec["inst"] = _load_llama(path, context,
                                       n_ctx=spec["n_ctx"],
                                       chat_format=spec["chat_format"],
                                       prefer_gpu_layers=999,
                                       model_key="WRITER")
        elif name == "codellama":
            spec["inst"] = _load_llama(path, context,
                                       n_ctx=spec["n_ctx"],
                                       chat_format=spec["chat_format"],
                                       prefer_gpu_layers=999,
                                       model_key="CODE")
        else:  # expert13b, noushermes7b, etc.
            spec["inst"] = _load_llama(path, context,
                                       n_ctx=spec["n_ctx"],
                                       chat_format=spec["chat_format"],
                                       prefer_gpu_layers=999,
                                       model_key="EXPERT")
    return spec["inst"]


def _chat_call(llm, messages: List[Dict[str, str]], max_tokens=512, temperature=0.3) -> str:
    chat_fmt = getattr(llm, "chat_format", None)
    if hasattr(llm, "create_chat_completion") and chat_fmt:
        out = llm.create_chat_completion(messages=messages, temperature=temperature, max_tokens=max_tokens)
        return out["choices"][0]["message"]["content"]

    # Fallback: flatten messages to a generic prompt
    sys_text, usr_text = [], []
    for m in messages:
        if m["role"] == "system":
            sys_text.append(m["content"])
        elif m["role"] == "user":
            usr_text.append(m["content"])
    prompt = _chat_fallback_prompt("\n".join(sys_text).strip(), "\n".join(usr_text).strip())
    out = llm(
        prompt=prompt,
        temperature=temperature,
        max_tokens=max_tokens,
        stop=["\nUSER:", "\nSYSTEM:", "\nASSISTANT:"],
    )
    return out["choices"][0]["text"]


# Prompts (tight and minimal)
_PLANNER_SYS = (
    "You are a fast planner. Return STRICT JSON only with keys: "
    "summary, intent, plan, constraints, risks, code_needed (bool), tool_hints (list of strings). "
    "No markdown. No commentary. JSON only."
)
_WRITER_SYS = (
    "You are a careful writer. Use the user's text and the Cognition JSON to produce the best answer. "
    "If code is required, insert a single placeholder tag like: "
    "<CODE_REQUEST language='python' purpose='X' spec='Y'/>"
    "<CODE_REQUEST language='python' tool='freecad' purpose='X' spec='Y'/>"
    "\nIf information is insufficient and a project scan would help, output exactly one self-hint line:"
    "\n<HINT action='scan.project'/>"
    "\nRules: Prefer concrete facts from EVIDENCE(JSON). If the answer is unknown, say so plainly—do not guess."
)


_CODE_SYS = (
    "You are a coding specialist. The user will provide a <CODE_REQUEST .../> tag and context. "
    "Output ONLY the final code block; no prose."
    
)
_CRITIC_SYS = (
    "You are a strict reviewer. Given the draft, return STRICT JSON: "
    "{\"ok\": true/false, \"notes\": \"one-line fix if not ok\"}"
)

def _json_only_guard(s: str) -> Optional[dict]:
    try:
        i = s.find("{"); j = s.rfind("}")
        return json.loads(s[i:j+1]) if (i >= 0 and j >= 0) else None
    except Exception:
        return None

# Stage functions
def _plan(text: str, context=None) -> Dict[str, Any]:
    tiny = _get_model("tiny", context)

    scan_dir = _extract_scan_dir(text)
    seed_hints = []
    seed = {}
    if scan_dir is not None:
        seed_hints.append("scan.project")
        seed["scan_project_dir"] = str(scan_dir)
    # inside _plan, after computing scan_dir...
    else:
        if re.search(r"\bproject\b", text, re.IGNORECASE):
            seed_hints.append("scan.project")
            seed["scan_project_dir"] = str(
                _freecad_project_dir() or Path(os.environ.get("PROJECT_DIR", os.getcwd())).resolve()
            )

    msg = [
        {"role": "system", "content": _PLANNER_SYS},
        {"role": "user", "content": text.strip()},
    ]
    
    raw = _chat_call(tiny, msg, max_tokens=256, temperature=0.2)
    parsed = _json_only_guard(raw)
    if not parsed:
        msg.append({"role": "system", "content": "Return valid JSON ONLY."})
        raw = _chat_call(tiny, msg, max_tokens=200, temperature=0.1)
        parsed = _json_only_guard(raw) or {
            "summary": text[:160],
            "intent": "fallback",
            "plan": ["answer directly"],
            "constraints": [],
            "risks": [],
            "code_needed": False,
            "tool_hints": []
        }

    # Merge in our pre-parsed command hints (dedup)
    hints = list({*(parsed.get("tool_hints") or []), *seed_hints})
    parsed["tool_hints"] = hints
    parsed.update(seed)
    return parsed

def _write(text: str, cognition: Dict[str, Any], evidence: Dict[str, Any] = None, context=None) -> str:
    writer = _get_model("mistral7b", context)
    # Human-friendly summary for writer:
    proj_name = (evidence or {}).get("project_name") or ""
    scan = (evidence or {}).get("scan.project") or {}
    scan_brief = ""
    if scan:
        scan_brief = (
            f"[SCAN] project_dir={scan.get('project_dir','')}\n"
            f"[SCAN] project_name={scan.get('project_name','')}\n"
            f"[SCAN] stats={json.dumps(scan.get('stats',{}), ensure_ascii=False)}\n"
        )

    payload = (
        f"USER_TEXT:\n{text}\n\n"
        f"COGNITION(JSON):\n{json.dumps(cognition, ensure_ascii=False)}\n\n"
        f"EVIDENCE(JSON):\n{json.dumps(evidence or {}, ensure_ascii=False)}\n\n"
        f"EVIDENCE(BRIEF):\n{scan_brief}"
    )
    msg = [
        {"role": "system", "content": _WRITER_SYS},
        {"role": "user", "content": payload},
    ]
    return _chat_call(writer, msg, max_tokens=1024, temperature=0.4)



def _maybe_code(text: str, cognition: Dict[str, Any], draft: str, context=None) -> str:
    need = bool(cognition.get("code_needed")) or ("<CODE_REQUEST" in draft)
    if not need:
        return draft
    start = draft.find("<CODE_REQUEST")
    end = draft.find("/>", start)
    if start == -1 or end == -1:
        return draft
    tag = draft[start:end+2]
    coder = _get_model("codellama", context)
    ctx = f"{text}\n\nCOGNITION:\n{json.dumps(cognition)}\n\nREQUEST:\n{tag}\n"
    msg = [
        {"role": "system", "content": _CODE_SYS},
        {"role": "user", "content": ctx},
    ]
    
    code_out = _chat_call(coder, msg, max_tokens=1024, temperature=0.1)

    # Require real FreeCAD Python if requested
    if "tool='freecad'" in tag.lower():
        if not _looks_like_freecad_python(code_out):
            # one corrective retry
            retry_msg = [
                {"role": "system", "content": _CODE_SYS},
                {"role": "user", "content": ctx + "\n\nSTRICT: Return valid Python for FreeCAD scripting. "
                                             "Start with 'import FreeCAD as App' or call App.newDocument(). No prose."},
            ]
            code_out = _chat_call(coder, retry_msg, max_tokens=1024, temperature=0.1)


    return draft.replace(tag, code_out)

def _critic(draft: str, context=None) -> Dict[str, Any]:
    tiny = _get_model("tiny", context)
    msg = [
        {"role": "system", "content": _CRITIC_SYS},
        {"role": "user", "content": draft},
    ]
    out = _chat_call(tiny, msg, max_tokens=128, temperature=0.0)
    return _json_only_guard(out) or {"ok": True, "notes": ""}

def _refine_if_needed(text: str, cognition: Dict[str, Any], draft: str, context=None) -> str:
    review = _critic(draft, context)
    if review.get("ok", True):
        return draft
    writer = _get_model("mistral7b", context)
    fix_msg = [
        {"role": "system", "content": _WRITER_SYS},
        {"role": "user", "content":
            f"{text}\n\nCOGNITION(JSON):\n{json.dumps(cognition)}\n\nCRITIC_NOTE:\n{review.get('notes','')}\n\nDRAFT:\n{draft}\n\nRevise to address the critic note."
        }
    ]
    return _chat_call(writer, fix_msg, max_tokens=1024, temperature=0.3)

def _self_reply(text: str, max_rounds: int = 2, context=None) -> Dict[str, Any]:
    t0 = time.time()
    rounds = 0
    cognition = _plan(text, context)
    evidence = _gather_evidence(cognition)

    while True:
        rounds += 1
        draft = _write(text, cognition, evidence, context)
        draft = _maybe_code(text, cognition, draft, context)
        draft = _refine_if_needed(text, cognition, draft, context)

        # If writer hinted to scan AND we haven't scanned yet, do one scan and loop once more
        need_scan = ("scan.project" in (cognition.get("tool_hints") or [])) or ("<HINT action='scan.project'/>" in draft)
        already_scanned = "scan.project" in evidence
        can_continue = (rounds < max_rounds)

        if need_scan and not already_scanned and can_continue:
            # ensure we have a directory
            pdir = cognition.get("scan_project_dir") or os.environ.get("PROJECT_DIR") or os.getcwd()
            try:
                evidence["scan.project"] = scan_project(Path(pdir))
            except Exception as e:
                evidence["scan.project"] = {"ok": False, "error": str(e), "project_dir": pdir}
            # Re-plan lightly with the realization we now have scan data
            # (the planner may add/remove hints based on the original text)
            cognition = _plan(text, context)
            continue

        break

    t1 = time.time()
    return {
        "final": draft,
        "cognition": cognition,
        "evidence": evidence,   # exposed for debugging
        "latency_sec": round(t1 - t0, 2),
        "models": f"tiny→mistral7b→(code?)→tiny x{rounds}",
    }



# Public method registry
METHODS = {
    "llm.complete": _complete,       # legacy single-shot
    "llm.plan": _plan,               # returns cognition JSON
    "llm.write": _write,             # consumes cognition -> draft
    "llm.self_reply": _self_reply,   # full staged pipeline
}
