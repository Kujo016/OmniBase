# ai_core/tools/cad_context.py
from typing import Dict, Any, List

try:
    import FreeCAD as App
except Exception:
    App = None
    # Module can still import; endpoints will return ok=False if FreeCAD not present.

def _active_doc():
    return getattr(App, "ActiveDocument", None) if App else None

def _shape_info(obj) -> Dict[str, Any]:
    d: Dict[str, Any] = {"name": obj.Name, "label": obj.Label, "type": obj.TypeId}
    try:
        sh = obj.Shape
    except Exception:
        sh = None
    if sh:
        bb = sh.BoundBox
        d["bbox"] = [bb.XMin, bb.YMin, bb.ZMin, bb.XMax, bb.YMax, bb.ZMax]
        # Not all objects are solids; area/volume may be absent/zero
        try:
            d["area"] = float(getattr(sh, "Area", 0.0))
        except Exception:
            pass
        try:
            d["volume"] = float(getattr(sh, "Volume", 0.0))
        except Exception:
            pass
        d["counts"] = {
            "faces": len(getattr(sh, "Faces", [])),
            "edges": len(getattr(sh, "Edges", [])),
            "vertices": len(getattr(sh, "Vertexes", [])),
        }
        try:
            com = sh.CenterOfMass  # only for solids
            d["centerOfMass"] = [float(com.x), float(com.y), float(com.z)]
        except Exception:
            pass
    return d

def cad_snapshot(_: str = "", **kwargs) -> Dict[str, Any]:
    doc = _active_doc()
    if App is None or doc is None:
        return {"ok": False, "error": "No FreeCAD context or no active document."}
    objs: List[Dict[str, Any]] = []
    for o in doc.Objects:
        if hasattr(o, "Shape"):
            objs.append(_shape_info(o))
    return {"ok": True, "doc": doc.Name, "units": App.ParamGet("User parameter:BaseApp/Preferences/Units").GetInt("UserSchema"), "objects": objs}

def cad_selection(_: str = "", **kwargs) -> Dict[str, Any]:
    doc = _active_doc()
    if App is None or doc is None:
        return {"ok": False, "error": "No FreeCAD context or no active document."}
    try:
        import FreeCADGui as Gui
        selected_names = {s.ObjectName for s in Gui.Selection.getSelectionEx()}
    except Exception:
        selected_names = set()
    objs: List[Dict[str, Any]] = []
    for o in doc.Objects:
        if o.Name in selected_names and hasattr(o, "Shape"):
            objs.append(_shape_info(o))
    return {"ok": True, "doc": doc.Name, "selected": objs}

METHODS = {
    "cad.snapshot": cad_snapshot,
    "cad.selection": cad_selection,
}
