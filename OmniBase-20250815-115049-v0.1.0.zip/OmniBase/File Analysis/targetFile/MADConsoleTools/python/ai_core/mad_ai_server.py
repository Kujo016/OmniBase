#!/usr/bin/env python3
"""
MAD AI Core — JSON-RPC-ish daemon for CAD helpers.
- Transport: newline-delimited JSON over TCP (localhost only by default)
- Methods: built-ins (ping, health, shutdown) + plugins in ai_core/tools/*
- Concurrency: per-connection task, per-line request
- Safety: clamps message size; localhost bind; structured logging
"""

import argparse
import asyncio
import importlib
import inspect
import json
import logging
import os
import pkgutil
import signal
import sys
import time
from dataclasses import dataclass
from typing import Any, Callable, Dict, Optional

# ---------- Config & State ----------

@dataclass
class Config:
    host: str = "127.0.0.1"
    port: int = 9876
    model_preset: str = "STANDARD"   # MINIMAL|STANDARD|FULL
    gpu_mode: str = "auto"           # auto|on|off
    max_msg_bytes: int = 2_000_000   # 2 MB per line
    tools_package: str = "tools"     # relative to this file's dir
    log_level: str = "INFO"


@dataclass
class State:
    cfg: Config
    start_ts: float
    gpu_available: bool
    shutting_down: bool = False
    methods: Dict[str, Callable[..., Any]] = None


# ---------- Utilities ----------

def _script_dir() -> str:
    return os.path.dirname(os.path.abspath(__file__))

def _detect_gpu_for_mode(mode: str) -> bool:
    """Quick-and-dirty: 'on' -> True, 'off' -> False, 'auto' -> nvidia-smi present."""
    if mode.lower() == "on":
        return True
    if mode.lower() == "off":
        return False
    # auto
    from shutil import which
    return which("nvidia-smi") is not None

def _configure_logging(level: str):
    lvl = getattr(logging, level.upper(), logging.INFO)
    logging.basicConfig(
        level=lvl,
        format="%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%H:%M:%S",
    )

def _json_error(err: Exception) -> str:
    return f"{type(err).__name__}: {err}"

# ---------- Plugin loader ----------

def load_tool_methods(cfg: Config) -> Dict[str, Callable[..., Any]]:
    """
    Import ai_core/tools/* modules and collect methods.
    Each tool module may either:
      - expose a dict named METHODS = {"namespace.name": callable, ...}
      - or expose a function register(config) -> dict
    """
    base = _script_dir()
    sys.path.insert(0, base)  # ensure ai_core import path
    tools_path = os.path.join(base, cfg.tools_package)
    methods: Dict[str, Callable[..., Any]] = {}

    if not os.path.isdir(tools_path):
        logging.info("No tools directory found at %s (skipping plugin load).", tools_path)
        return methods

    pkg_name = cfg.tools_package
    for modinfo in pkgutil.iter_modules([tools_path]):
        if modinfo.name.startswith("_"):
            continue
        fullname = f"{pkg_name}.{modinfo.name}"
        try:
            mod = importlib.import_module(fullname)
            added = 0
            if hasattr(mod, "METHODS") and isinstance(mod.METHODS, dict):
                for k, v in mod.METHODS.items():
                    if not callable(v):
                        continue
                    methods[k] = v
                    added += 1
            if hasattr(mod, "register") and callable(mod.register):
                reg = mod.register(cfg)
                if isinstance(reg, dict):
                    for k, v in reg.items():
                        if callable(v):
                            methods[k] = v
                            added += 1
            if added:
                logging.info("Loaded %d method(s) from %s", added, fullname)
        except Exception as e:
            logging.warning("Failed to load tool module %s: %s", fullname, _json_error(e))

    return methods

# ---------- Built-in methods ----------

def _builtin_methods(state: State) -> Dict[str, Callable[..., Any]]:
    def ping() -> Dict[str, Any]:
        return {"ok": True, "t": time.time()}

    def health() -> Dict[str, Any]:
        up = time.time() - state.start_ts
        return {
            "ok": True,
            "uptime_sec": round(up, 3),
            "preset": state.cfg.model_preset,
            "gpu_mode": state.cfg.gpu_mode,
            "gpu_available": state.gpu_available,
            "methods": sorted(list(state.methods.keys())),
        }

    def shutdown(delay_ms: int = 0) -> Dict[str, Any]:
        state.shutting_down = True
        async def _later():
            await asyncio.sleep(delay_ms / 1000.0)
            # Stop the loop gracefully.
            for task in asyncio.all_tasks():
                if task.get_name() != "server":
                    continue
            loop = asyncio.get_running_loop()
            loop.stop()
        asyncio.create_task(_later())
        return {"ok": True, "msg": f"server exiting in {delay_ms} ms"}

    return {
        "ping": ping,
        "health": health,
        "shutdown": shutdown,
    }

# ---------- Request handling ----------

def _invoke(method: Callable, params: Optional[dict], state: State) -> Any:
    """Call method with params; inject 'context' if accepted."""
    if params is None:
        params = {}
    sig = inspect.signature(method)
    if "context" in sig.parameters:
        params = dict(params)
        params["context"] = state
    return method(**params)

async def handle_client(reader: asyncio.StreamReader,
                        writer: asyncio.StreamWriter,
                        state: State):
    peer = writer.get_extra_info("peername")
    logging.debug("Client connected: %s", peer)
    try:
        while not reader.at_eof():
            line = await reader.readline()
            if not line:
                break
            if len(line) > state.cfg.max_msg_bytes:
                logging.warning("Dropping oversized message from %s (%d bytes)", peer, len(line))
                continue

            try:
                req = json.loads(line.decode("utf-8", errors="replace"))
            except json.JSONDecodeError as e:
                logging.warning("Bad JSON from %s: %s", peer, e)
                continue

            req_id = req.get("id")
            method_name = req.get("method")
            params = req.get("params", {})

            if not isinstance(method_name, str):
                out = {"id": req_id, "result": None, "error": "Invalid 'method'."}
            else:
                func = state.methods.get(method_name)
                if func is None:
                    out = {"id": req_id, "result": None, "error": f"Unknown method '{method_name}'."}
                else:
                    try:
                        result = await maybe_async(_invoke, func, params, state)
                        out = {"id": req_id, "result": result, "error": None}
                    except Exception as e:
                        logging.exception("Method %s failed", method_name)
                        out = {"id": req_id, "result": None, "error": _json_error(e)}

            writer.write((json.dumps(out, separators=(",", ":")) + "\n").encode("utf-8"))
            await writer.drain()

            if state.shutting_down:
                break
    finally:
        try:
            writer.close()
            await writer.wait_closed()
        except Exception:
            pass
        logging.debug("Client disconnected: %s", peer)

async def maybe_async(fn: Callable, func: Callable, params: dict, state: State):
    """Run possibly-blocking work off the event loop."""
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, fn, func, params, state)

async def run_server(state: State):
    server = await asyncio.start_server(
        lambda r, w: handle_client(r, w, state),
        host=state.cfg.host,
        port=state.cfg.port,
        reuse_port=False,
        start_serving=True,
    )
    sockets = ", ".join(str(s.getsockname()) for s in server.sockets or [])
    logging.info("Math Analysis & Design AI server listening on %s", sockets)

    # Allow Ctrl+C / SIGTERM to stop gracefully
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, lambda s=sig: setattr(state, "shutting_down", True))
        except NotImplementedError:
            # Windows adds limited signal support; it's fine.
            pass

    async with server:
        # Keep a named task so external code can identify it (optional).
        asyncio.current_task().set_name("server")
        while not state.shutting_down:
            await asyncio.sleep(0.1)

    logging.info("Server shutting down…")

# ---------- Main ----------

def parse_args(argv=None) -> Config:
    ap = argparse.ArgumentParser(description="Angle AI Core (CAD helper daemon)")
    ap.add_argument("--host", default="127.0.0.1", help="Bind host (default 127.0.0.1)")
    ap.add_argument("--port", type=int, default=9876, help="Bind port (default 9876)")
    ap.add_argument("--preset", choices=["MINIMAL", "STANDARD", "FULL"], default="STANDARD",
                    help="Model preset hint for plugins")
    ap.add_argument("--gpu", choices=["auto", "on", "off"], default="auto",
                    help="GPU mode hint for plugins")
    ap.add_argument("--log-level", default="INFO", help="Logging level (DEBUG, INFO, WARN, ERROR)")
    args = ap.parse_args(argv)
    return Config(
        host=args.host,
        port=args.port,
        model_preset=args.preset,
        gpu_mode=args.gpu,
        log_level=args.log_level,
    )

def main(argv=None):
    cfg = parse_args(argv)
    _configure_logging(cfg.log_level)
    gpu_avail = _detect_gpu_for_mode(cfg.gpu_mode)
    state = State(cfg=cfg, start_ts=time.time(), gpu_available=gpu_avail, methods={})

    # Built-ins first
    state.methods.update(_builtin_methods(state))

    # Plugins from ai_core/tools/*
    state.methods.update(load_tool_methods(cfg))

    # Example: if no geometry tool provided, add a simple one.
    if "geometry.center_distance" not in state.methods:
        def _cd(T: float, P: float, m: float) -> float:
            """Center distance for spur gears (teeth T,P; module m)."""
            return m * (T + P) / 2.0
        state.methods["geometry.center_distance"] = _cd
        logging.info("Injected fallback method geometry.center_distance")

    logging.info("GPU available: %s (mode=%s)", state.gpu_available, cfg.gpu_mode)
    logging.info("Preset: %s | Methods: %d", cfg.model_preset, len(state.methods))

    try:
        asyncio.run(run_server(state))
    except KeyboardInterrupt:
        pass
    except Exception as e:
        logging.exception("Fatal error: %s", _json_error(e))
        return 1
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
