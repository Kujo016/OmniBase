#!/usr/bin/env python3
# init_ai.py — dual-frontend AI I/O (Qt in FreeCAD, wx in KiCad, smart fallback)
# Location: .../FreeCAD 1.0/Mod/MADConsoleTools/python/init_ai.py

import os, sys, json, socket, time, threading, subprocess

HOST, PORT = "127.0.0.1", 9876
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
BIN_DIR  = os.path.normpath(os.path.join(BASE_DIR, ".", "bin"))
DAEMON_BAT = os.path.join(BIN_DIR, "MAD_AI_DAEMON.bat")

def rpc(method: str, params=None, timeout=2.0):
    params = params or {}
    req = {"id": 1, "method": method, "params": params}
    data = (json.dumps(req) + "\n").encode("utf-8")
    with socket.create_connection((HOST, PORT), timeout=timeout) as s:
        s.sendall(data)
        s.shutdown(socket.SHUT_WR)
        buf = s.recv(1 << 20)
    try:
        return json.loads(buf.decode("utf-8", errors="replace"))
    except Exception as e:
        return {"id": None, "result": None, "error": f"Bad JSON: {type(e).__name__}: {e}"}

def server_alive(timeout=0.3) -> bool:
    try:
        res = rpc("ping", {}, timeout=timeout)
        return (res.get("error") is None)
    except OSError:
        return False

def try_start_daemon_and_wait(max_wait_sec=6.0) -> bool:
    if not os.path.exists(DAEMON_BAT):
        return False
    try:
        creationflags = 0x08000000  # CREATE_NO_WINDOW
        subprocess.Popen(["cmd", "/c", DAEMON_BAT], cwd=BIN_DIR, creationflags=creationflags)
    except Exception:
        subprocess.Popen(["cmd", "/c", DAEMON_BAT], cwd=BIN_DIR)
    t0 = time.time()
    while time.time() - t0 < max_wait_sec:
        if server_alive(timeout=0.25):
            return True
        time.sleep(0.15)
    return False

class AIClient:
    def send_async(self, method, params, cb):
        def _run():
            ok, result, error = False, None, None
            try:
                res = rpc(method, params or {})
                error = res.get("error")
                result = res.get("result")
                ok = (error is None)
            except Exception as e:
                error = f"{type(e).__name__}: {e}"
            cb({"ok": ok, "method": method, "result": result, "error": error})
        threading.Thread(target=_run, daemon=True).start()

# --- environment detection ---
IN_FREECAD = "FreeCAD" in sys.modules or os.environ.get("FREECAD_PYTHON")
IN_KICAD   = "pcbnew" in sys.modules or os.environ.get("KICAD_RUN_FROM")

# =========================
# Qt front-end (FreeCAD / external)
# =========================
def run_qt():
    # Always use PySide2 inside FreeCAD; fall back to a floating window outside.
    IN_FREECAD = False
    try:
        import FreeCADGui
        IN_FREECAD = True
    except Exception:
        IN_FREECAD = False

    # ---- Qt imports (prefer PySide2 in FreeCAD) ----
    if IN_FREECAD:
        try:
            from PySide2.QtWidgets import QApplication, QWidget, QVBoxLayout, QTextEdit, QLineEdit, QDockWidget
            from PySide2.QtCore import Qt, Signal, QObject
        except Exception:
            return False
    else:
        # Outside FreeCAD: try modern bindings then PySide2
        qt = None
        try:
            from PySide6.QtWidgets import QApplication, QWidget, QVBoxLayout, QTextEdit, QLineEdit, QDockWidget
            from PySide6.QtCore import Qt, Signal, QObject
            qt = True
        except Exception:
            try:
                from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QTextEdit, QLineEdit, QDockWidget
                from PyQt6.QtCore import Qt, pyqtSignal as Signal, QObject
                qt = True
            except Exception:
                try:
                    from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QTextEdit, QLineEdit, QDockWidget
                    from PyQt5.QtCore import Qt, pyqtSignal as Signal, QObject
                    qt = True
                except Exception:
                    try:
                        from PySide2.QtWidgets import QApplication, QWidget, QVBoxLayout, QTextEdit, QLineEdit, QDockWidget
                        from PySide2.QtCore import Qt, Signal, QObject
                        qt = True
                    except Exception:
                        return False

    # ---- Minimal RPC bridge (keep your existing AIClient helpers) ----
    class RpcWorker(QObject):
        # PySide2 is happiest with object-typed signals
        reply = Signal(object)
        def send(self, method, params=None):
            AIClient().send_async(method, params or {}, lambda p: self.reply.emit(p))

    class AiQt(QWidget):
        def __init__(self, parent=None):
            super().__init__(parent)
            self.setObjectName("MadAiPanelBody")
            self.display = QTextEdit(self); self.display.setReadOnly(True)
            self.entry = QLineEdit(self); self.entry.setPlaceholderText("Type and press Enter…")
            self.entry.returnPressed.connect(self.on_send)
            lay = QVBoxLayout(self); lay.addWidget(self.display, 1); lay.addWidget(self.entry, 0)
            self.setLayout(lay)
            self.worker = RpcWorker(); self.worker.reply.connect(self.on_reply)
            self._boot()

        def _esc(self, s): return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")
        def _sys(self, t): self.display.append(f"<b>System:</b> {self._esc(t)}")
        def _ai(self, t):  self.display.append(f"<b>AI:</b> {self._esc(t)}")
        def _you(self, t): self.display.append(f"<b>You:</b> {self._esc(t)}")
        def _err(self, t): self.display.append(f"<span style='color:#c00'><b>Error:</b> {self._esc(t)}</span>")

        def _boot(self):
            self._sys(f"Checking AI server {HOST}:{PORT} …")
            if server_alive():
                self._sys("Connected."); self.worker.send("health")
            else:
                self._sys("Not running. Starting MAD_AI_DAEMON.bat …")
                if try_start_daemon_and_wait():
                    self._sys("Daemon started."); self.worker.send("health")
                else:
                    self._err("Could not start AI daemon.")

        def on_send(self):
            msg = self.entry.text().strip()
            if not msg: return
            self.entry.clear(); self._you(msg)
            if not server_alive() and not try_start_daemon_and_wait():
                self._err("Server not available."); return
            self.worker.send("llm.complete", {"prompt": msg})

        def on_reply(self, p):
            if isinstance(p, dict) and p.get("ok"):
                m = p.get("method")
                if m == "health": self._sys(str(p.get("result")))
                elif m == "llm.complete":
                    r = p.get("result"); self._ai(r.get("text") if isinstance(r, dict) and "text" in r else str(r))
                else:
                    self._ai(str(p.get("result")))
            else:
                err = p.get("error","Request failed.") if isinstance(p, dict) else str(p)
                if isinstance(p, dict) and p.get("method") == "llm.complete" and err.startswith("Unknown method"):
                    self._sys("llm.complete not implemented; pinging …"); self.worker.send("ping")
                else:
                    self._err(err)

    app = QApplication.instance()
    if IN_FREECAD and app is None:
        # In FreeCAD there must already be an app
        return False
    owned = False
    if app is None:
        app = QApplication(sys.argv); owned = True

    if IN_FREECAD:
        mw = FreeCADGui.getMainWindow()
        # Reuse existing dock if present
        dock = mw.findChild(QDockWidget, "MadAiDock")
        if dock is None:
            dock = QDockWidget("MAD AI I/O", mw)
            dock.setObjectName("MadAiDock")  # keep stable for persistence & reuse
            dock.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea | Qt.BottomDockWidgetArea | Qt.TopDockWidgetArea)
            dock.setFeatures(QDockWidget.DockWidgetClosable | QDockWidget.DockWidgetMovable | QDockWidget.DockWidgetFloatable)
            panel = AiQt(dock)
            dock.setWidget(panel)
            mw.addDockWidget(Qt.RightDockWidgetArea, dock)
        else:
            panel = dock.widget()
        dock.show(); dock.raise_(); mw.raise_()
        try:
            panel.entry.setFocus()
        except Exception:
            pass
        return True
    else:
        # Not in FreeCAD: show as normal window
        w = AiQt()
        w.setWindowTitle("MAD AI I/O")
        w.show()
        try: w.raise_(); w.activateWindow()
        except Exception: pass
        if owned: sys.exit(app.exec())
        return True



# =========================
# wx front-end (KiCad)
# =========================
def run_wx():
    try:
        import wx
    except Exception:
        return False

    class WxAiFrame(wx.Frame):
        def __init__(self, parent=None):
            super().__init__(parent, title="MAD AI I/O (wx)", size=(720, 420))
            panel = wx.Panel(self)
            vbox = wx.BoxSizer(wx.VERTICAL)
            self.display = wx.TextCtrl(panel, style=wx.TE_MULTILINE|wx.TE_READONLY)
            self.entry = wx.TextCtrl(panel, style=wx.TE_PROCESS_ENTER)
            self.entry.Bind(wx.EVT_TEXT_ENTER, self.on_send)
            vbox.Add(self.display, 1, wx.EXPAND|wx.ALL, 8)
            vbox.Add(self.entry, 0, wx.EXPAND|wx.LEFT|wx.RIGHT|wx.BOTTOM, 8)
            panel.SetSizer(vbox)
            self.client = AIClient()
            self._boot()

        def _append(self, prefix, text): self.display.AppendText(f"{prefix} {text}\n")
        def _sys(self, t): self._append("System:", t)
        def _ai(self, t): self._append("AI:", t)
        def _you(self, t): self._append("You:", t)
        def _err(self, t): self._append("Error:", t)

        def _boot(self):
            self._sys(f"Checking AI server {HOST}:{PORT} …")
            if server_alive():
                self._sys("Connected."); self.client.send_async("health", {}, self.on_reply)
            else:
                self._sys("Not running. Starting MAD_AI_DAEMON.bat …")
                if try_start_daemon_and_wait():
                    self._sys("Daemon started."); self.client.send_async("health", {}, self.on_reply)
                else:
                    self._err("Could not start AI daemon.")

        def on_send(self, evt):
            msg = self.entry.GetValue().strip()
            if not msg: return
            self.entry.SetValue(""); self._you(msg)
            if not server_alive() and not try_start_daemon_and_wait():
                self._err("Server not available."); return
            self.client.send_async("llm.complete", {"prompt": msg}, self.on_reply)

        def on_reply(self, p: dict):
            def _ui():
                if p.get("ok"):
                    m = p.get("method")
                    if m == "health": self._sys(str(p.get("result")))
                    elif m == "llm.complete":
                        r = p.get("result")
                        self._ai(r.get("text") if isinstance(r, dict) and "text" in r else str(r))
                    else:
                        self._ai(str(p.get("result")))
                else:
                    if p.get("method") == "llm.complete" and p.get("error","").startswith("Unknown method"):
                        self._sys("llm.complete not implemented; pinging …")
                        self.client.send_async("ping", {}, self.on_reply)
                    else:
                        self._err(p.get("error","Request failed."))
            wx.CallAfter(_ui)

    app = wx.App.Get() or wx.App(False)
    frame = WxAiFrame(None); frame.Show()
    if wx.App.Get() is None:
        app.MainLoop()
    return True

# =========================
# main
# =========================
def main():
    # Prefer Qt in FreeCAD, wx in KiCad, otherwise try both.
    if IN_FREECAD:
        if run_qt(): return
        raise RuntimeError("FreeCAD detected but no Qt binding available.")
    if IN_KICAD:
        if run_wx(): return
        # If wx not available (unlikely inside KiCad), try Qt fallback:
        if run_qt(): return
        raise RuntimeError("KiCad detected but no wx/Qt binding available.")
    # External: try Qt, then wx
    if run_qt(): return
    if run_wx(): return
    raise RuntimeError("No GUI toolkit available (need PySide6 / PyQt6 / PyQt5 / wxPython).")

if __name__ == "__main__":
    main()
