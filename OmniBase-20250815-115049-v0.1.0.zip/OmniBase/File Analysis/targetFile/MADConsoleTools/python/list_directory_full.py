import os
import sys

def list_directory_contents(path):
    output = []
    total_size = 0
    for root, dirs, files in os.walk(path):
        level = root.replace(path, "").count(os.sep)
        indent = " " * 4 * level
        output.append(f"{indent}{os.path.basename(root)}/")
        sub_indent = " " * 4 * (level + 1)
        for file in files:
            file_path = os.path.join(root, file)
            file_size = os.path.getsize(file_path)
            total_size += file_size
            output.append(f"{sub_indent}{file} - {file_size} bytes")

    output.append(f"\nTotal size of directory: {total_size} bytes ({total_size / (1024 * 1024):.2f} MB)")
    return "\n".join(output)

if __name__ == "__main__":
    # Locate the project root (parent of the script's directory)
    if len(sys.argv) > 1:
        project_root = os.path.abspath(sys.argv[1])
    else:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        project_root = os.path.abspath(os.path.join(script_dir, ".."))

    # Use the 'reports' directory inside the project root
    reports_dir = os.path.join(project_root, "reports")
    if not os.path.exists(reports_dir):
        print(f"Error: {reports_dir} does not exist. Rerun analysis.")

    # You can change this to whatever subfolder you want to inspect
    directory_to_list = project_root

    print(f"Listing contents of project directory: {directory_to_list}\n")

    if not os.path.exists(directory_to_list):
        print(f"Error: Directory '{directory_to_list}' does not exist.")
    else:
        structure = list_directory_contents(directory_to_list)

        # Save to reports directory
        output_file = os.path.join(reports_dir, "directory_structure_full.txt")
        with open(output_file, "w", encoding="utf-8") as file:
            file.write(f"Directory structure of: {directory_to_list}\n\n")
            file.write(structure)
            file.write(f"\n\nSystem path of main directory: {directory_to_list}")

        print(f"\nDirectory structure has been saved to: {output_file}")
