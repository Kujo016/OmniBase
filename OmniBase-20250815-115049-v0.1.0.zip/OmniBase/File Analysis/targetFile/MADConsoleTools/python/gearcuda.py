# gearcuda.py - Python wrapper for gearcuda.dll
import os, ctypes

def _dll_path():
    here = os.path.dirname(__file__)                 # ...\MADConsoleTools\scripts
    pkg_root = os.path.abspath(os.path.join(here, os.pardir))  # ...\MADConsoleTools
    dll = os.path.join(pkg_root, "bin", "gearcuda.dll")
    # Optional: secondary fallback if your import path ever comes from data_console\scripts
    if not os.path.exists(dll):
        alt = os.path.abspath(os.path.join(here, os.pardir, os.pardir, "bin", "gearcuda.dll"))
        if os.path.exists(alt):
            dll = alt
    return dll


# Put CUDA bin on the DLL search path
try:
    cuda_base = os.environ.get("CUDA_PATH_V12_8", r"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12.8")
    cuda_bin  = os.path.join(cuda_base, "bin")
    if os.path.isdir(cuda_bin) and hasattr(os, "add_dll_directory"):
        os.add_dll_directory(cuda_bin)
except Exception:
    pass

_dll = ctypes.CDLL(_dll_path())

# ---- prototypes -------------------------------------------------------------
_check = _dll.check_collisions_bin
_check.argtypes = [
    ctypes.c_char_p,  # bin path
    ctypes.c_float,   # degrees_step
    ctypes.POINTER(ctypes.POINTER(ctypes.c_ubyte)),  # out_hits**
    ctypes.POINTER(ctypes.c_int)  # out_len*
]
_check.restype = ctypes.c_int

# ratio entry (present in your DLL)
_ratio = getattr(_dll, "check_collisions_bin_ratio", None)
if _ratio is not None:
    _ratio.argtypes = [
        ctypes.c_char_p,  # bin path
        ctypes.c_float,   # degrees_step
        ctypes.c_float,   # teeth0   (DLL currently expects float)
        ctypes.c_float,   # teeth1   (DLL currently expects float)
        ctypes.c_float,   # phase1_degrees
        ctypes.POINTER(ctypes.POINTER(ctypes.c_ubyte)),
        ctypes.POINTER(ctypes.c_int)
    ]
    _ratio.restype = ctypes.c_int

_free = getattr(_dll, "free_buffer", None)
if _free:
    _free.argtypes = [ctypes.c_void_p]
    _free.restype = None

_last_err = getattr(_dll, "gears_last_error", None)
if _last_err:
    _last_err.argtypes = []
    _last_err.restype = ctypes.c_char_p

def _err_or(code: int) -> str:
    if _last_err:
        msg_b = _last_err()
        if msg_b:
            try:
                return msg_b.decode("utf-8", "ignore")
            except Exception:
                pass
    return f"errcode={code}"

# ---- public API -------------------------------------------------------------
def check_mesh(bin_path: str, degrees_step: float = 1.0):
    """Returns [0/1]*K where K ≈ 360/degrees_step. 1 = collision at that step."""
    if degrees_step <= 0:
        raise ValueError("degrees_step must be > 0")
    bin_path_b = os.fsencode(bin_path)
    out_ptr = ctypes.POINTER(ctypes.c_ubyte)()
    out_len = ctypes.c_int(0)
    rc = _check(bin_path_b, float(degrees_step), ctypes.byref(out_ptr), ctypes.byref(out_len))
    if rc != 0:
        raise RuntimeError(f"gearcuda: {_err_or(rc)}")
    try:
        n = int(out_len.value)
        if not bool(out_ptr) or n <= 0:
            return []
        data = ctypes.string_at(out_ptr, n)  # copy bytes
        return [1 if b else 0 for b in data]
    finally:
        if _free and bool(out_ptr):
            _free(out_ptr)

def check_mesh_ratio(bin_path: str,
                     degrees_step: float,
                     teeth0: int,
                     teeth1: int,
                     phase1_deg: float = 0.0):
    """Ratio-aware sweep (ω1/ω0 = -teeth0/teeth1) starting with gear #2 at phase1_deg."""
    if _ratio is None:
        raise NotImplementedError("DLL lacks check_collisions_bin_ratio export.")
    if degrees_step <= 0:
        raise ValueError("degrees_step must be > 0")

    bin_path_b = os.fsencode(bin_path)
    out_ptr = ctypes.POINTER(ctypes.c_ubyte)()
    out_len = ctypes.c_int(0)

    rc = _ratio(bin_path_b,
                float(degrees_step),
                float(int(teeth0)),  # pass ints, cast to float to match DLL
                float(int(teeth1)),
                float(phase1_deg),
                ctypes.byref(out_ptr),
                ctypes.byref(out_len))
    if rc != 0:
        raise RuntimeError(f"gearcuda: {_err_or(rc)}")
    try:
        n = int(out_len.value)
        if not bool(out_ptr) or n <= 0:
            return []
        data = ctypes.string_at(out_ptr, n)
        return [1 if b else 0 for b in data]
    finally:
        if _free and bool(out_ptr):
            _free(out_ptr)

_clear = _dll.check_collisions_bin_ratio_clear
_clear.argtypes = [
    ctypes.c_char_p, ctypes.c_float, ctypes.c_float, ctypes.c_float, ctypes.c_float,
    ctypes.POINTER(ctypes.POINTER(ctypes.c_ubyte)),   # out_hits**
    ctypes.POINTER(ctypes.POINTER(ctypes.c_float)),   # out_clear**
    ctypes.POINTER(ctypes.c_int)                      # out_len*
]
_clear.restype = ctypes.c_int

def check_mesh_ratio_clear(bin_path: str, degrees_step: float,
                           teeth0: float, teeth1: float, phase1_deg: float = 0.0):
    bin_path_b = os.fsencode(bin_path)
    out_hits = ctypes.POINTER(ctypes.c_ubyte)()
    out_clear = ctypes.POINTER(ctypes.c_float)()
    out_len = ctypes.c_int(0)
    rc = _clear(bin_path_b, float(degrees_step), float(teeth0), float(teeth1), float(phase1_deg),
                ctypes.byref(out_hits), ctypes.byref(out_clear), ctypes.byref(out_len))
    if rc != 0:
        msg = _last_err().decode('utf-8', 'ignore') if _last_err() else f"errcode={rc}"
        raise RuntimeError(msg)
    try:
        n = out_len.value
        hits = bytes(ctypes.string_at(out_hits, n))
        clear = ctypes.cast(out_clear, ctypes.POINTER(ctypes.c_float * n)).contents[:]
        return [bool(b) for b in hits], list(clear)
    finally:
        _free(out_hits); _free(out_clear)
