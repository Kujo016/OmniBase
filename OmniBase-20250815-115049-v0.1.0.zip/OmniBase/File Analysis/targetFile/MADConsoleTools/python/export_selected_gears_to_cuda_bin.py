# export_selected_gears_to_cuda_bin.py
import struct, math, os
import FreeCAD as App, FreeCADGui as Gui

MAGIC = b'GEARBIN'  # 7 bytes; we’ll pad to 8

def _get_shape(obj):
    shp = getattr(obj, "Shape", None)
    if shp and not shp.isNull():
        return shp
    try:
        linked = obj.getLinkedObject(True)
        shp2 = getattr(linked, "Shape", None)
        if shp2 and not shp2.isNull():
            return shp2
    except Exception:
        pass
    return None

def _tessellate_world(obj, deflection=0.05):
    """Return (points_world:list[Vector], tris:list[tuple[int,int,int]])"""
    shp = _get_shape(obj)
    if not shp:
        raise ValueError(f"{obj.Label}: no shape")
    # Shape-local tessellation
    pts, tris = shp.tessellate(deflection)
    # Some FreeCAD builds give 1-based tri indices; normalize to 0-based
    max_idx = max(max(t) for t in tris) if tris else -1
    if max_idx >= len(pts):  # likely 1-based
        tris = [(a-1, b-1, c-1) for (a,b,c) in tris]

    # Apply object Placement to bring into world coordinates
    M = obj.Placement
    pts_w = [M.multVec(p) for p in pts]
    return pts_w, tris

def _placement_matrix4x4_rowmajor(p):
    """FreeCAD Placement → row-major 4x4 float32"""
    m = p.toMatrix()  # 4x4 FreeCAD Matrix
    # FreeCAD Matrix is row-major accessible: m.A11 ... m.A44
    return [
        m.A11, m.A12, m.A13, m.A14,
        m.A21, m.A22, m.A23, m.A24,
        m.A31, m.A32, m.A33, m.A34,
        m.A41, m.A42, m.A43, m.A44,
    ]

def _axle_from_placement(p):
    """Use local Z as axle axis; origin at Placement.Base (world)."""
    origin = p.Base
    axis = p.Rotation.multVec(App.Vector(0,0,1))
    return origin, axis

def _pack_vec3(v):
    return struct.pack('<3f', float(v.x), float(v.y), float(v.z))

def _pack_mat4_rowmajor(m16):
    return struct.pack('<16f', *[float(x) for x in m16])

def export_selection_bin(path, deflection=0.05):
    sel = [o for o in Gui.Selection.getSelection() if _get_shape(o)]
    if len(sel) < 1:
        raise RuntimeError("Select at least one solid/clone/link with a valid Shape.")
    if len(sel) > 2:
        # Keep you focused: export the first two only (you can extend later).
        sel = sel[:2]

    # Build records
    records = []
    for obj in sel:
        pts, tris = _tessellate_world(obj, deflection=deflection)
        origin, axis = _axle_from_placement(obj.Placement)
        M0 = _placement_matrix4x4_rowmajor(obj.Placement)

        records.append({
            "name": obj.Name,
            "pts": pts,
            "tris": tris,
            "origin": origin,
            "axis": axis,
            "M0": M0
        })

    # Write binary
    with open(path, 'wb') as f:
        # File header
        f.write(MAGIC + b'\x00')         # pad to 8 bytes total
        f.write(struct.pack('<I', 1))    # version
        f.write(struct.pack('<I', len(records)))  # num_gears

        for rec in records:
            nv = len(rec["pts"])
            nt = len(rec["tris"])
            f.write(struct.pack('<II', nv, nt))
            # Axle + M0
            f.write(_pack_vec3(rec["origin"]))
            f.write(_pack_vec3(rec["axis"]))
            f.write(_pack_mat4_rowmajor(rec["M0"]))
            # Vertices (float32 xyz)
            for p in rec["pts"]:
                f.write(_pack_vec3(p))
            # Triangles (uint32 i j k)
            for (i,j,k) in rec["tris"]:
                f.write(struct.pack('<III', i, j, k))

    App.Console.PrintMessage(
        f"✅ Exported {len(records)} gear(s) to {path} with deflection={deflection}\n"
    )

def main():
    # Default to document folder if possible
    doc = App.ActiveDocument
    base_dir = os.path.dirname(doc.FileName) if (doc and doc.FileName) else os.path.expanduser("~")
    out_path = os.path.join(base_dir, "gears_cuda.bin")
    export_selection_bin(out_path, deflection=0.03)  # tighten tessellation a bit

if __name__ == "__main__":
    main()
