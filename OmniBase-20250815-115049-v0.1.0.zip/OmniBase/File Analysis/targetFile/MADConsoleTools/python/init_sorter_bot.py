import os, ctypes


def _fc_print(msg, error=False):
    try:
        import FreeCAD
        if error:
            FreeCAD.Console.PrintError(msg + "\n")
        else:
            FreeCAD.Console.PrintMessage(msg + "\n")
    except Exception:
        print(msg)

def run_sorter_from_button():
    """Entry point for the FreeCAD button/menu."""
    try:
        # 1. Get the active FreeCAD project path
        import FreeCAD
        fc_doc = FreeCAD.ActiveDocument
        if not fc_doc or not fc_doc.FileName:
            raise RuntimeError("No active FreeCAD project file is open or saved.")

        project_dir = os.path.dirname(fc_doc.FileName)

        # 2. Target dir = the FreeCAD project dir
        target_dir = project_dir

        # 3. Ensure reports/ exists in the project dir
        reports_dir = os.path.join(project_dir, "reports")
        os.makedirs(reports_dir, exist_ok=True)

        _fc_print(f"[InitSorter] Project dir: {project_dir}")
        _fc_print(f"[InitSorter] Reports dir: {reports_dir}")

        # 4. Temporarily patch run_cpp_function to use this target_dir
        
        import ctypes

        # We'll re-call the DLL directly so we can swap the directory argument
        script_dir = os.path.dirname(os.path.abspath(__file__))
        dll_path = os.path.normpath(os.path.join(script_dir, "..", "bin", "mylib_cud.dll"))
        if not os.path.exists(dll_path):
            raise FileNotFoundError(f"DLL file not found: {dll_path}")

        for p in [
            r"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12.8\bin",
            r"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12.8\lib\x64",
            r"C:\vcpkg\installed\x64-windows\lib",
            r"C:\vcpkg\installed\x64-windows\bin",
        ]:
            if os.path.isdir(p):
                os.add_dll_directory(p)

        mylib = ctypes.WinDLL(dll_path)
        if not hasattr(mylib, "run"):
            raise AttributeError("Function 'run' not found in the DLL.")

        mylib.run.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p]
        mylib.run.restype  = None

        tag_file  = os.path.normpath(os.path.join(script_dir, "..", "tags", "tags.txt"))
        code_file = os.path.normpath(os.path.join(script_dir, "..", "tags", "code_tags.txt"))

        for p in [target_dir, tag_file, code_file]:
            if not os.path.exists(p):
                raise FileNotFoundError(f"Required path missing: {p}")

        mylib.run(target_dir.encode("utf-8"),
                  tag_file.encode("utf-8"),
                  code_file.encode("utf-8"))

        # 5. Verify results
        out_json = os.path.join(reports_dir, "code_summary_results.json")
        if os.path.exists(out_json):
            _fc_print(f"[InitSorter] Done. Wrote reports\\code_summary_results.json ({os.path.getsize(out_json)} bytes)")
        else:
            _fc_print("[InitSorter] Finished, but results JSON not found in reports/.", error=True)

    except Exception as e:
        _fc_print(f"[InitSorter] Failed: {e}", error=True)
        raise


if __name__ == "__main__":
    run_sorter_from_button()



