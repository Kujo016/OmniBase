import subprocess
print("\n[INFO] Checking GPU processes with nvidia-smi...\n")
subprocess.run(["nvidia-smi"])

import os
import sys
import importlib.util

print("[INFO] Python sys.path:", sys.path)
print("[INFO] llama_cpp available:", importlib.util.find_spec("llama_cpp") is not None)

from llama_cpp import Llama
from llama_cpp.llama_cpp import llama_supports_gpu_offload

print("CUDA GPU Offload Support Available:", llama_supports_gpu_offload())

MODEL_DIR = os.path.join("RAG", "mistral")

# Find the first Mistral .gguf model in the folder
model_path = None
for file in os.listdir(MODEL_DIR):
    if file.lower().endswith(".gguf") and "mistral" in file.lower():
        model_path = os.path.join(MODEL_DIR, file)
        print(f"[INFO] Found model: {file}")
        break

if not model_path:
    print("[ERROR] No Mistral GGUF model found in:", MODEL_DIR)
    exit(1)

print("[INFO] Loading model with GPU offload enabled...")
try:
    llm = Llama(
        model_path=model_path,
        main_gpu=0,
        n_gpu_layers=-1,
        verbose=True
    )
except Exception as e:
    print(f"[ERROR] Failed to load model: {e}")
    exit(1)

if llama_supports_gpu_offload() and llm and callable(llm):
    # Run a simple test prompt
    output = llm("Q: What is 2 + 2?\nA:", max_tokens=8)
    print("Response:", output["choices"][0]["text"].strip())

    # Give user a hint to confirm GPU usage manually
    print("Test End\nGPU support enabled\nFishing Assistant is ready to use.")
else:
    print("[WARN] GPU offload not supported or LLM not loaded properly.\nGPU support is not enabled.")

