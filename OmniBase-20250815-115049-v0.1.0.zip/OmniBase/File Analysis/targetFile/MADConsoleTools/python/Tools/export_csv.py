import FreeCAD as App
import csv

# FreeCAD 1.0 ships with PySide6
try:
    from PySide6 import QtWidgets
except ImportError:  # fallback if someone runs this on older stacks
    from PySide2 import QtWidgets

# --------- Config (tune if your sheets are huge) ----------
MAX_ROWS_SCAN  = 5000     # upper bound for row scan
MAX_COLS_SCAN  = 52       # scan A..AZ (26*2) by default
EMPTY_ROW_RUN  = 50       # stop after this many consecutive empty rows

# --------- Helpers ----------
def _col_to_label(n: int) -> str:
    """1 -> 'A', 26 -> 'Z', 27 -> 'AA', ..."""
    label = ""
    while n > 0:
        n, r = divmod(n - 1, 26)
        label = chr(65 + r) + label
    return label

def _get_cell(sheet, addr: str) -> str:
    """Try to read cell contents (prefer contents; fallback to value)."""
    try:
        v = sheet.getContents(addr)
    except Exception:
        try:
            v = sheet.get(addr)
        except Exception:
            v = ""
    return "" if v is None else str(v)

def _find_spreadsheet(doc):
    """Find a Spreadsheet object even if it isn't named 'Spreadsheet'."""
    sheet = doc.getObject("Spreadsheet")
    if sheet:
        return sheet
    for obj in doc.Objects:
        if getattr(obj, "TypeId", "") == "Spreadsheet::Sheet":
            return obj
    return None

def _detect_used_range(sheet):
    """Detect last used row/column by scanning with early exits."""
    last_row = 0
    last_col = 0

    empty_streak = 0
    for r in range(1, MAX_ROWS_SCAN + 1):
        row_has_data = False
        row_last_col = 0
        for c in range(1, MAX_COLS_SCAN + 1):
            addr = f"{_col_to_label(c)}{r}"
            val = _get_cell(sheet, addr)
            if val.strip():
                row_has_data = True
                row_last_col = c
                if c > last_col:
                    last_col = c
        if row_has_data:
            last_row = r
            empty_streak = 0
        else:
            empty_streak += 1
            if empty_streak >= EMPTY_ROW_RUN:
                break

    return last_row, last_col

# --------- Main export ----------
def exportCSV():
    """Export spreadsheet data to CSV, FreeCAD 1.0 / PySide6-safe."""
    doc = App.ActiveDocument
    if not doc:
        App.Console.PrintError("No active document.\n")
        return

    sheet = _find_spreadsheet(doc)
    if not sheet:
        App.Console.PrintError("No spreadsheet found in the active document.\n")
        return

    # Ask user for file path
    file_path, _ = QtWidgets.QFileDialog.getSaveFileName(
        None,
        "Save CSV",
        "",
        "CSV Files (*.csv)"
    )
    if not file_path:
        return
    if not file_path.lower().endswith(".csv"):
        file_path += ".csv"

    # Detect used range
    last_row, last_col = _detect_used_range(sheet)
    if last_row == 0 or last_col == 0:
        App.Console.PrintMessage("Spreadsheet is empty—nothing to export.\n")
        return

    # Write CSV (Windows-safe newlines, UTF-8)
    try:
        with open(file_path, "w", newline="", encoding="utf-8") as csvfile:
            writer = csv.writer(csvfile)
            for r in range(1, last_row + 1):
                row_data = []
                for c in range(1, last_col + 1):
                    addr = f"{_col_to_label(c)}{r}"
                    row_data.append(_get_cell(sheet, addr))
                writer.writerow(row_data)
        App.Console.PrintMessage(f"CSV exported to {file_path}\n")
    except Exception as ex:
        App.Console.PrintError(f"CSV export failed: {ex}\n")
