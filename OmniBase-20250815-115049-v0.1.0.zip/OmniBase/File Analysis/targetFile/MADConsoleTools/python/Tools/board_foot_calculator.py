import FreeCAD
import re
from fractions import Fraction

# ---------- Safer numeric parsing ----------
def extract_numeric(value):
    if value is None:
        return 0.0
    s = str(value).strip().lower()
    if not s:
        return 0.0
    # Remove common units and quotes
    s = s.replace('inches', '').replace('inch', '').replace('in', '')
    s = s.replace('"', '').replace("'", '').strip()
    # Handle "=formula" prefix
    if s.startswith('='):
        s = s[1:].strip()

    # Convert mixed numbers like "1 1/2" → "1+1/2"
    s = re.sub(r'(\d+)\s+(\d+/\d+)', r'\1+\2', s)

    # Build a safe expression: replace fractions a/b with Fraction(a,b)
    tokens = []
    for tok in s.split():
        if re.fullmatch(r"\d+/\d+", tok):
            a, b = tok.split('/')
            tokens.append(f"Fraction({a},{b})")
        else:
            tokens.append(tok)

    try:
        val = eval(" ".join(tokens), {"Fraction": Fraction}, {})
        return float(val)
    except Exception:
        return 0.0

# ---------- Board Feet Calculator ----------
def calculate_board_feet():
    doc = FreeCAD.ActiveDocument
    if not doc:
        print("No active FreeCAD document.")
        return

    spreadsheet = doc.getObject("Spreadsheet")
    if not spreadsheet:
        for obj in doc.Objects:
            if getattr(obj, "TypeId", "") == "Spreadsheet::Sheet":
                spreadsheet = obj
                break
    if not spreadsheet:
        print("No spreadsheet found in active document.")
        return

    row = 2
    total_board_feet = 0.0

    while True:
        length_cell = spreadsheet.getContents(f"C{row}")
        if not length_cell.strip():
            print(f"Stopping at row {row}: empty length cell.")
            break

        try:
            quantity = extract_numeric(spreadsheet.getContents(f"B{row}"))  # Column B
            length = extract_numeric(spreadsheet.getContents(f"E{row}"))    # Column E
            width = extract_numeric(spreadsheet.getContents(f"F{row}"))     # Column F
            height = extract_numeric(spreadsheet.getContents(f"G{row}"))    # Column G

            if quantity <= 0 or length <= 0 or width <= 0 or height <= 0:
                print(f"Skipping row {row}: values must be > 0.")
                row += 1
                continue

            board_feet = (quantity * length * width * height) / 144
            spreadsheet.set(f"H{row}", str(round(board_feet, 2)))
            print(f"Row {row}: Q={quantity}, L={length}, W={width}, H={height} → {round(board_feet, 2)} bf")

            total_board_feet += board_feet

        except Exception as ex:
            print(f"Error in row {row}: {ex}")

        row += 1

    # Write total at bottom
    spreadsheet.set(f"G{row}", "Total Board Feet:")
    spreadsheet.set(f"H{row}", str(round(total_board_feet, 2)))

    doc.recompute()
    print(f"Board feet calculations completed. Total: {round(total_board_feet, 2)} bf")
