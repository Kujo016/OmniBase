# populate_spreadsheet.py  — FreeCAD 1.0 safe

import FreeCAD as App

def get_column_letter(n: int) -> str:
    """0 -> 'A', 25 -> 'Z', 26 -> 'AA', etc."""
    result = ''
    while n >= 0:
        result = chr(65 + (n % 26)) + result
        n = n // 26 - 1
    return result

def _get_or_create_spreadsheet(doc, name: str = "Spreadsheet"):
    """Return a Spreadsheet::Sheet named `name` (create if missing).
       If `name` is taken by something else, create a unique name."""
    sheet = doc.getObject(name)
    if sheet and getattr(sheet, "TypeId", "") == "Spreadsheet::Sheet":
        return sheet

    # If the name exists but isn't a sheet, or no object at all—create unique
    base = name
    idx = 1
    while True:
        candidate = base if idx == 1 else f"{base}{idx:03d}"
        if doc.getObject(candidate) is None:
            sheet = doc.addObject("Spreadsheet::Sheet", candidate)
            return sheet
        obj = doc.getObject(candidate)
        if getattr(obj, "TypeId", "") == "Spreadsheet::Sheet":
            return obj
        idx += 1

def run():
    # Ensure we have a document
    doc = App.ActiveDocument
    if doc is None:
        doc = App.newDocument()

    sheet = _get_or_create_spreadsheet(doc, "Spreadsheet")

    # De-duplicated, structured headers (A1..)
    headers = [
        "Category", "Quantity", "Part_Name", "Body_Name",
        "Length", "Width", "Height", "Board_Foot", "Diameter",
        "Alt_Length", "Alt_Width", "Alt_Height", "Arc_Radius",
        "Cubic_Inches", "Cubic_Feet",
        "Wood_Type", "Grain_Direction",
        "Kerf_Loss", "Saw_Blade_Thickness",
        "Edge_Radius", "Chamfer", "Fillet_Radius",
        "Offset_X", "Offset_Y", "Offset_Z",
        "Rotation_Angle", "Coincidence_Index",
        "Glue_Joint_Type",
        "Dado_Depth", "Rabbet_Depth", "Mortise_Depth", "Tenon_Length",
        "Spline_Thickness",
        "Dowel_Diameter", "Dowel_Spacing",
        "Plywood_Veneer_Thickness", "Finish_Coats",
    ]

    # Populate headers into row 1
    for col, header in enumerate(headers):
        cell = f"{get_column_letter(col)}1"
        sheet.set(cell, header)

    doc.recompute()
    App.Console.PrintMessage("Spreadsheet populated with headers successfully.\n")

# Allow running from the console:
if __name__ == "__main__":
    run()
