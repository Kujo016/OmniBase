# loadToolbar.py
# Organizes tools into logical toolbars for KujoWorkbench.
import _loadTools

def getItems(iType):
    parts = []
    if iType == "MADWorkbench - Layout and Visualization":
        parts = ["board_layout_macro"]
    
    if iType == "MADWorkbench - Spreadsheet Tools":
        parts = ["populate_spreadsheet", "board_foot_calculator", "export_csv"]
        
    if iType == "MADWorkbench - MADCON Tools":
        parts = ["run_madcon_console", "run_init_sorter_bot"]


    return parts

