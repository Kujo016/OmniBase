# Mod/MADConsoleTools/__Init__.py
# Registers console commands for gears + export utilities.
# Bare commands, App.<name>(), and App.mad.<group>.<name>() are provided.
# Gears group:  App.mad.gears
# Export group: App.mad.export

import os, sys, importlib, importlib.util, builtins

# FreeCAD-safe import (allows import-time errors to print nicely)
try:
    import FreeCAD as App
except Exception:
    class _Stub:
        class Console:
            @staticmethod
            def PrintMessage(m): print(m, end="")
            @staticmethod
            def PrintError(m): print(m, end="")
    App = _Stub()

HERE = os.path.dirname(__file__)

# Where scripts live (reflects your repo layout)
SEARCH_DIRS = [
    HERE,
    os.path.join(HERE, "scripts"),
    os.path.join(HERE, "scripts", "gears"),
    os.path.join(HERE, "scripts", "data_console", "scripts"),
    os.path.join(HERE, "scripts", "data_console", "export"),
]

for p in SEARCH_DIRS:
    if os.path.isdir(p) and p not in sys.path:
        sys.path.append(p)

# Optional convenience: preload geometry cache
try:
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), "python", "data_console", "scripts"))
    import mad_geom_cache as mc
    setattr(App, "mc", mc)
except Exception as e:
    App.Console.PrintMessage(f"[MADConsoleTools] mad_geom_cache not preloaded: {e}\n")
    # provide a convenient alias

# ---- Command registry (grouped) ----
GROUPS = {
    "gears": {
        "calc_axle_size": ("calc_axle_size", "main"),
        "calc_compound_involute_axle": ("calc_compound_involute_axle", "main"),
        "calc_involute_axle": ("calc_involute_axle", "main"),
        "calc_involute_tooth_count": ("calc_involute_tooth_count", "main"),
        "calc_mass": ("calc_mass", "main"),
        "calc_volume": ("calc_volume", "main"),
    },
    "export": {
        "xport_bodies": ("xport_bodies", "main_entry"),
        "xport_objects": ("xport_objects", "main_entry"),
        "xport_parts": ("xport_parts", "main_entry"),
        "xport_parts_bodies": ("xport_parts_bodies", "main_entry"),
        "xport_parts_bodies_to_spreadsheet": ("xport_parts_bodies_to_spreadsheet", "main_entry"),
        # Alias for the CAM job exporter:
        "xport_cam_jobs": ("xport_job_operation_body", "main_entry"),
        "xport_job_operation_body": ("xport_job_operation_body", "main_entry"),
    },
    "cuda": {
    "cuda_help": ("cuda_py_commands", "cuda_help"),
    "cuda_wizard": ("cuda_py_commands", "cuda_wizard"),
    "cuda_export": ("cuda_py_commands", "cuda_export"),
    "cuda_check_fast": ("cuda_py_commands", "cuda_check_fast"),
    "cuda_check_ratio": ("cuda_py_commands", "cuda_check_ratio"),
    "cuda_phase_sweep": ("cuda_py_commands", "cuda_phase_sweep"),
    },

}

# ---- Import helpers ----
def _find_module_path(module_name: str):
    filename = module_name + ".py"
    for base in SEARCH_DIRS:
        for root, _dirs, files in os.walk(base):
            if filename in files:
                return os.path.join(root, filename)
    return None

def _import_module(module_name: str):
    try:
        return importlib.import_module(module_name)
    except Exception:
        path = _find_module_path(module_name)
        if not path:
            raise ImportError(f"Could not locate module '{module_name}' under {SEARCH_DIRS}.")
        spec = importlib.util.spec_from_file_location(module_name, path)
        if not spec or not spec.loader:
            raise ImportError(f"Failed to load spec for '{module_name}' at '{path}'.")
        mod = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = mod
        spec.loader.exec_module(mod)
        return mod

def _make_runner(module_name: str, func_name: str, reload_on_call: bool = True):
    def _runner(*args, **kwargs):
        mod = _import_module(module_name)
        if reload_on_call:
            try:
                mod = importlib.reload(mod)
            except Exception:
                mod = _import_module(module_name)
        func = getattr(mod, func_name, None)
        if func is None:
            raise AttributeError(f"Function '{func_name}' not found in module '{module_name}'.")
        return func(*args, **kwargs)
    _runner.__name__ = f"{module_name}.{func_name}"
    _runner.__doc__ = f"Runs {module_name}.{func_name}() (auto-reloads on each call)."
    return _runner

# ---- Namespaces ----
def _ensure_namespaces():
    if not hasattr(App, "mad"):
        class _MAD: pass
        App.mad = _MAD()
    for group in GROUPS.keys():
        if not hasattr(App.mad, group):
            class _NS: pass
            setattr(App.mad, group, _NS())

# ---- Registration ----
def _register_all():
    _ensure_namespaces()
    banners = []
    for group, reg in GROUPS.items():
        names = []
        for public_name, (module_name, func_name) in reg.items():
            runner = _make_runner(module_name, func_name)
            # 1) Bare function
            setattr(builtins, public_name, runner)
            # 2) App.<name>()
            setattr(App, public_name, runner)
            # 3) App.mad.<group>.<name>()
            getattr(App.mad, group).__setattr__(public_name, runner)
            names.append(public_name)
        banners.append(f"{group}: " + ", ".join(sorted(names)))
    for banner in banners:
        App.Console.PrintMessage(f"[MADConsoleTools] Console commands ready -> {banner}\n")
    App.Console.PrintMessage("Try: calc_involute_tooth_count()  |  xport_cam_jobs()\n")

def reload_mad_console():
    """Rebind all console commands (use after editing modules)."""
    _register_all()
    App.Console.PrintMessage("[MADConsoleTools] Commands reloaded.\n")

setattr(App, "reload_mad_console", reload_mad_console)

# Initial registration
try:
    _register_all()
except Exception as e:
    App.Console.PrintError(f"[MADConsoleTools] Registration failed: {e}\n")
