﻿// Prevent Windows headers from defining min/max macros
#ifndef NOMINMAX
#define NOMINMAX
#endif


#include <algorithm>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>
#include <unordered_set>
#include <vector>
#include <cstdlib>   // std::system
#include <atomic>
#include <thread>
#include <windows.h>

#include "tag_dir.h"

#ifdef _WIN32
#include <windows.h>
static void enable_console_utf8() {
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
}
#endif



static inline std::string utf8(const std::filesystem::path& p) {
#if defined(_MSC_VER)
    return p.u8string();   // UTF-8 on Windows, no ACP conversion
#else
    return p.string();
#endif
}


static std::atomic<bool> g_list_running{false};

static void list_worker(std::string script_cmd) noexcept {
    try {
        get_list_directory_full(script_cmd);  // single place that runs and logs
    } catch (...) {
        std::cerr << "[ERROR] list_worker(): unhandled exception\n";
    }
    g_list_running = false;
}

bool start_list_async(const fs::path& mod_root) {
	HMODULE hMod = nullptr;
    if (!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS |
                            GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                            reinterpret_cast<LPCWSTR>(&start_list_async), &hMod)) {
        return false;
    }
    wchar_t dllPathW[MAX_PATH];
    DWORD n = GetModuleFileNameW(hMod, dllPathW, MAX_PATH);
    if (n == 0 || n == MAX_PATH) return false;

    fs::path tool_root = fs::path(dllPathW).parent_path().parent_path();

    // Python (FreeCAD bundled) + script (tool-local)
    fs::path py     = LR"(C:\Program Files\FreeCAD 1.0\bin\python.exe)";
    fs::path script = tool_root / "python" / "list_directory_full.py";

    
    if (!fs::exists(py) || !fs::exists(script)) return false;

    // Build quoted command and spawn with CWD = project root
    std::wstring cmd = L"\"" + py.wstring() + L"\" \"" + script.wstring() + L"\" \"" + mod_root.wstring() + L"\"";

    STARTUPINFOW si{}; si.cb = sizeof(si);
    PROCESS_INFORMATION pi{};
    BOOL ok = CreateProcessW(nullptr, cmd.data(), nullptr, nullptr, FALSE,
                             CREATE_NO_WINDOW | DETACHED_PROCESS,
                             nullptr, mod_root.wstring().c_str(), &si, &pi);
    
	if (!ok) {
        return false;
    }

    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);
 
    return true;
}




// --- your existing helpers (same as before) ---

// Only valid extensions
static const std::unordered_set<std::string> kValidExt = {
    ".txt",".cpp",".c",".h",".hpp",".cu",".cuh",
    ".py",".java",".js",".jsx",".ts",".tsx",
    ".cs",".go",".swift",".rs",".kt",".kts",
    ".html",".htm",".css",".sh",".bash",".bat",".cmd"
};

static std::string to_lower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), ::tolower);
    return s;
}

std::string preprocess_docx_text(const std::string& text) {
    std::string out = text;
    out.erase(std::remove(out.begin(), out.end(), '\r'), out.end());
    std::transform(out.begin(), out.end(), out.begin(), ::tolower);
    return out;
}

json build_json_summary(const std::vector<int>& counts,
                        const std::vector<std::vector<int>>& positions,
                        const std::vector<std::string>& tags) {
    json summary;
    for (size_t i = 0; i < tags.size(); ++i) {
        if (i < counts.size() && counts[i] > 0) summary[tags[i]] = positions[i];
    }
    return summary;
}

static json process_one_file(const fs::path& p,
                             const std::vector<std::string>& tags) {
    auto lines = read_txt(utf8(p));

    std::string file_content;
    file_content.reserve(lines.size() * 96);

    // Strip CR so "\r" never becomes a fake “tag”
    for (std::string s : lines) {
        if (!s.empty() && s.back() == '\r') s.pop_back();
        file_content += s;
        file_content.push_back('\n');
    }

    // CUDA counts
    std::vector<int> counts(tags.size(), 0);
    process_text_with_cuda(file_content, const_cast<std::vector<std::string>&>(tags), counts);

    // Build counts object
    json counts_json;
    for (size_t i = 0; i < tags.size(); ++i)
        if (counts[i] > 0) counts_json[tags[i]] = counts[i];

    // Per-line hits
    std::unordered_map<std::string, std::vector<std::string>> tag_map;
    tag_map.reserve(tags.size());
    for (const auto& t : tags) tag_map[t].push_back(t);

    json lines_json = process_text_files(p, tag_map);

    json file_result;
    file_result["counts"] = counts_json;
    file_result["lines"]  = (lines_json.contains("summary") ? lines_json["summary"] : json::object());
    return file_result;
}


void get_list_directory_full(const std::string& command) {
    int rc = std::system(command.c_str());
    if (rc == -1) {
        std::cerr << "[ERROR] System command execution failed!\n";
    } else if (rc != 0) {
        std::cerr << "[ERROR] Python script failed with exit code " << rc << "\n";
    } else {
        std::cout << "[INFO] Python script executed successfully.\n";
    }
}

void process_directory_code(const std::string& directory,
                            const std::string& tag_file,
                            const std::string& code_file) {
    const fs::path root = directory;
    if (!fs::exists(root) || !fs::is_directory(root)) {
        std::cerr << "[ERROR] Invalid directory: " << root << "\n"; return;
    }

    auto tags = read_txt(tag_file);
    { auto more = read_txt(code_file); tags.insert(tags.end(), more.begin(), more.end()); }
    for (auto& t : tags) t = to_lower(t);

    json results;
    std::error_code ec;
    for (fs::recursive_directory_iterator it(root, fs::directory_options::skip_permission_denied, ec), end;
         it != end; it.increment(ec)) {
        if (!fs::is_regular_file(*it)) continue;

        std::string ext = to_lower(it->path().extension().string());
        if (kValidExt.find(ext) == kValidExt.end()) continue;

        json fr = process_one_file(it->path(), tags);
        if (!fr["counts"].empty() || !fr["lines"].empty()) {
			std::error_code ec2;
			fs::path canon = fs::weakly_canonical(it->path(), ec2);
			const std::string key = ec2 ? utf8(it->path()) : utf8(canon);
			results[key] = std::move(fr);
		}


    }

    fs::path base = fs::path(directory);
	fs::path out_dir = (fs::path(directory) / "reports");



	fs::create_directories(out_dir, ec);

	fs::path out = out_dir / "code_summary_results.json";
    std::ofstream ofs(out);
    if (!ofs) { std::cerr << "[ERROR] Cannot open output file: " << out << "\n"; return; }
    ofs << results.dump(4);
    std::cout << "Results saved to " << out << "\n";
}

extern "C" {
__declspec(dllexport) void __stdcall run(const char* dir,
                                         const char* tag_file,
                                         const char* code_file) {
    enable_console_utf8();
	try {
        
		try {
            start_list_async(std::filesystem::path(dir));
        } catch (const std::exception& e) {
            std::cerr << "[ERROR] start_list_async(): " << e.what() << "\n";
        } catch (...) {
            std::cerr << "[ERROR] start_list_async(): unknown/SEH exception.\n";
        }
		
		const std::string directory = (dir ? dir : "");
        process_directory_code(directory,
                               (tag_file ? tag_file : ""),
                               (code_file ? code_file : ""));
							   
        
		
        std::cout << "[INFO] Program executed successfully.\n";
    } catch (const std::exception& e) {
        std::cerr << "[ERROR] run(): " << e.what() << "\n";
    } catch (...) {
        std::cerr << "[ERROR] run(): unknown/SEH exception.\n";
    }
}
}
