C:\\Program Files\\NVIDIA GPU Computing Toolkit\\CUDA\\v12.8\\bin

MADConsoleTools/
cuda/
gears\_cuda.cu           # CUDA kernel + C ABI exports
build\_gearcuda.bat      # NVCC → gearcuda.dll
bin/
gearcuda.dll            # build output (created by the script)
scripts/
export\_selected\_gears\_to\_cuda\_bin.py  # FreeCAD exporter
gearcuda.py             # Python wrapper (ctypes)

NVCC x64 Native Tools
cd "C:\\Program Files\\FreeCAD 1.0\\Mod\\MADConsoleTools\\cuda"
build\_gearcuda.bat

if you cant find cudart64\_\*.dll at runtime, add to PATH:
C:\\Program Files\\NVIDIA GPU Computing Toolkit\\CUDA\\v12.8\\bin
Then restart FreeCAD.









from MADConsoleTools.scripts.gearcuda import check\_mesh\_ratio

T0, T1 = 60, 20   # tooth counts in the SAME order you selected

hits = check\_mesh\_ratio(out\_path, degrees\_step=0.5, teeth0=40, teeth1=16, phase1\_deg=0.0)

print("steps:", len(hits), "collisions:", sum(hits))



