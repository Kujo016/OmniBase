// gears_cuda.h
#include <cstdint>

struct GearHeader {
    uint32_t num_vertices;
    uint32_t num_triangles;
    float axle_origin[3];
    float axle_axis[3];
    float M0[16]; // row-major
};

struct FileHeader {
    char magic[8];
    uint32_t version;
    uint32_t num_gears;
};

// Simple float3/uint3
struct float3 { float x,y,z; };
struct uint3 { uint32_t x,y,z; };

// ---- math helpers ----
__device__ __forceinline__ float3 make_float3(float x,float y,float z){ return {x,y,z}; }

__device__ float3 cross3(const float3&a,const float3&b){
    return make_float3(a.y*b.z-a.z*b.y, a.z*b.x-a.x*b.z, a.x*b.y-a.y*b.x);
}
__device__ float dot3(const float3&a,const float3&b){ return a.x*b.x+a.y*b.y+a.z*b.z; }

__device__ float3 axang_rotate(const float3& p, const float3& origin, const float3& axis_n, float theta){
    // Rodrigues
    float3 v = {p.x - origin.x, p.y - origin.y, p.z - origin.z};
    float c = cosf(theta), s = sinf(theta);
    float3 k = axis_n;
    float3 kv = cross3(k, v);
    float kd = make_float3(k.x*dot3(k,v), k.y*dot3(k,v), k.z*dot3(k,v));
    float3 vrot = { v.x*c + kv.x*s + kd.x*(1.f-c),
                    v.y*c + kv.y*s + kd.y*(1.f-c),
                    v.z*c + kv.z*s + kd.z*(1.f-c) };
    return make_float3(origin.x+vrot.x, origin.y+vrot.y, origin.z+vrot.z);
}

// TODO: plug in your favorite tri-tri overlap (e.g., SAT or Möller’s)
__device__ bool tri_tri_overlap(const float3 A0,const float3 A1,const float3 A2,
                                const float3 B0,const float3 B1,const float3 B2);

// ---- kernel: sample angles, early-out on any collision ----
__global__ void check_mesh_intersections(
    const f3* __restrict__ V0, const u3* __restrict__ T0, uint32_t nt0,
    const f3* __restrict__ V1, const u3* __restrict__ T1, uint32_t nt1,
    f3 origin0, f3 axis0, f3 origin1, f3 axis1,
    const float* __restrict__ angles0, const float* __restrict__ angles1,
    int K, unsigned char* __restrict__ out_any_collision_per_k)
{
    int k = blockIdx.x * blockDim.x + threadIdx.x;
    if (k >= K) return;
    float t0 = angles0[k];
    float t1 = angles1[k];

    bool hit = false;

    // Brute-force triangle pairs (optimize next pass with BVH)
    for (uint32_t i = 0; i < nt0 && !hit; ++i){
        u3 a = T0[i];
        f3 A0 = axang_rotate(V0[a.x], origin0, axis0, t0);
        f3 A1 = axang_rotate(V0[a.y], origin0, axis0, t0);
        f3 A2 = axang_rotate(V0[a.z], origin0, axis0, t0);
        for (uint32_t j = 0; j < nt1 && !hit; ++j){
            u3 b = T1[j];
            f3 B0 = axang_rotate(V1[b.x], origin1, axis1, t1);
            f3 B1 = axang_rotate(V1[b.y], origin1, axis1, t1);
            f3 B2 = axang_rotate(V1[b.z], origin1, axis1, t1);
            if (tri_tri_overlap(A0,A1,A2,B0,B1,B2)) hit = true;
        }
    }
    out_any_collision_per_k[k] = hit ? 1 : 0;
}