# InitGui.py
# Initializes KujoWorkbench in FreeCAD.
import FreeCAD, FreeCADGui
import sys, os

class KujoWorkbench(FreeCADGui.Workbench):
    
    translate = FreeCAD.Qt.translate
    def QT_TRANSLATE_NOOP(context, text):
        return text
    import __Init__
    path = os.path.dirname(__Init__.__file__)
    iconPath = os.path.join(path,"Icons")
    translationsPath = os.path.join(path, "translations")

    MenuText = QT_TRANSLATE_NOOP("KujoWorkbench", "MADWorkbench")
    ToolTip = QT_TRANSLATE_NOOP("KujoWorkbench", "Workbench for full stack design.")
    Icon = os.path.join(iconPath, "console_icon.png")
    def Initialize(self):
        import _loadTools
        import _loadToolbar
        import _loadMenu
        FreeCADGui.addLanguagePath(self.translationsPath)

        self.appendToolbar("MADWorkbench - Layout and Visualization",
                       _loadToolbar.getItems("MADWorkbench - Layout and Visualization"))
        self.appendToolbar("MADWorkbench - Spreadsheet Tools",
                       _loadToolbar.getItems("MADWorkbench - Spreadsheet Tools")) 
        self.appendToolbar("MADWorkbench - MADCON Tools",
                       _loadToolbar.getItems("MADWorkbench - MADCON Tools"))

        self.appendMenu("MADWorkbench", _loadMenu.getItems())
        FreeCAD.Console.PrintMessage("MADWorkbench initialized\n")

    def Activated(self):
        FreeCAD.Console.PrintMessage("MADWorkbench activated\n")
        return

    def Deactivated(self):
        FreeCAD.Console.PrintMessage("MADWorkbench deactivated\n")
        return
    def ContextMenu(self, recipient):
        return
    def GetClassName(self):
        return "Gui::PythonWorkbench"


if "KujoWorkbench" not in FreeCADGui.listWorkbenches():
    FreeCADGui.addWorkbench(KujoWorkbench())
