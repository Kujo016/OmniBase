import os, ctypes

def run_cpp_function():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    dll_path   = os.path.join(script_dir, "bin", "mylib_cud.dll")
    print(f"Looking for DLL at: {dll_path}")
    if not os.path.exists(dll_path):
        raise FileNotFoundError(f"DLL file not found: {dll_path}")

    # Guard these so missing CUDA/VCPKG dirs don’t crash the loader
    for p in [
        r"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12.8\bin",
        r"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12.8\lib\x64",
        r"C:\vcpkg\installed\x64-windows\lib",
        r"C:\vcpkg\installed\x64-windows\bin",
    ]:
        if os.path.isdir(p):
            os.add_dll_directory(p)

    mylib = ctypes.WinDLL(dll_path)

    if not hasattr(mylib, "run"):
        raise AttributeError("Function 'run' not found in the DLL.")

    mylib.run.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p]
    mylib.run.restype  = None

    directory = os.path.join(script_dir, "targetFile")
    tag_file  = os.path.join(script_dir, "tags", "tags.txt")
    code_file = os.path.join(script_dir, "tags", "code_tags.txt")

    for p in [directory, tag_file, code_file]:
        if not os.path.exists(p):
            raise FileNotFoundError(f"Required path missing: {p}")

    mylib.run(directory.encode("utf-8"),
              tag_file.encode("utf-8"),
              code_file.encode("utf-8"))

if __name__ == "__main__":
    run_cpp_function()


