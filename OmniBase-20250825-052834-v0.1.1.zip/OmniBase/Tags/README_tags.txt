book_tags.txt - 905 bytes
cad-code_tags.txt - 13132 bytes
cad_tags.txt - 2381 bytes
code_tags.txt - 10749 bytes
old_tags.txt - 905 bytes
project_tags.txt - 1811 bytes
trimmed_tags.txt - 5835 bytes


change 1 to tags.txt to allow system to read the tag list