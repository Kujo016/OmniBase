﻿#pragma once
#define _CRT_SECURE_NO_WARNINGS

#include <string>
#include <vector>
#include <unordered_map>

// Neutralize CUDA attrs when not compiling with NVCC
#ifndef __CUDACC__
  #ifndef __host__
  #define __host__
  #endif
  #ifndef __device__
  #define __device__
  #endif
  #ifndef __global__
  #define __global__
  #endif
#endif

#include "kernel.cuh"  // must typedef/using alias: using json = nlohmann::json;



// API
// was: void get_list_directory_full();
void get_list_directory_full(const std::string& cmd);

std::string preprocess_docx_text(const std::string& text);

json build_json_summary(const std::vector<int>& counts,
                        const std::vector<std::vector<int>>& positions,
                        const std::vector<std::string>& tags);

#include <filesystem>
namespace fs = std::filesystem;

// 1) Declaration that matches the definition in kernel.cu
json process_text_files(const std::string& filepath,
                        const std::unordered_map<std::string, std::vector<std::string>>& tags);

// 2) Inline wrapper so callers can pass fs::path safely
inline json process_text_files(const fs::path& filepath,
                               const std::unordered_map<std::string, std::vector<std::string>>& tags) {
    return process_text_files(filepath.u8string(), tags);
}


void process_directory_code(const std::string& directory,
                            const std::string& tag_file,
                            const std::string& code_file);


// tag_dir.h
#include <filesystem>
#include <vector>
#include <string>

namespace fs = std::filesystem;

// primary (defined in a .cpp)
std::vector<std::string> read_txt(const fs::path& path);

// inline shim so any std::string callers still link
inline std::vector<std::string> read_txt(const std::string& filepath) {
    return read_txt(fs::path(filepath));
}


